
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_InsertUpdate_In_Proc_Glb_TransferValuePosting]') AND type in (N'P', N'PC'))
DROP PROC SP_InsertUpdate_In_Proc_Glb_TransferValuePosting
GO

/****** Object:  StoredProcedure [dbo].[SP_InsertUpdate_In_Proc_Glb_TransferValuePosting]    Script Date: 06/20/2013 02:40:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_InsertUpdate_In_Proc_Glb_TransferValuePosting]    
(
       @TransferId AS numeric(18,0)
      ,@TransferNoExist as nvarchar(50)
      ,@TransferDate as datetime
      ,@Year as nvarchar(50)
      ,@Type as nvarchar(50)
      ,@RequestedBy as nvarchar(50)
      ,@ApprovedBy as nvarchar(50)
      ,@TypeofTransferIn as nvarchar(50)
      ,@TypeofTransferOut as nvarchar(50)
      ,@ActiveStatus AS bit
      ,@CreatedBy AS numeric(18,0)
      ,@ModifiedBy AS numeric(18,0)
      ,@dtLineitems AS Proc_Glb_StorageLocationMovement_Details_Trans readonly      
      ,@ErrorStatus as nvarchar(100) OUTPUT   
      ,@NewTransferNo as nvarchar(50) OUTPUT)
     
AS

BEGIN TRANSACTION

   SET NOCOUNT ON;
   
   Declare @LineItems Integer
   SET @LineItems =10
   
   IF(@TransferId=0)
   BEGIN
   DECLARE @NewTransferId as numeric(18,0)
   declare @TransferNo varchar(50)
   declare @Series as numeric(18,0)
   set @Series= (select  MAX([Series]) from Proc_Glb_TransferValuePosting_Header where [Year]=@Year)+1
   if(@Series is not null)
                  begin
                  set @TransferNo= 'TVP'+@Year+cast(REPLACE(STR(@Series, 5), SPACE(1), '0') as varchar(50))   
                  end
                  else
                  begin
                  set @TransferNo= 'TVP'+@Year+'00001'
                  set @Series=1
                  end
                  
    INSERT INTO [Proc_Glb_TransferValuePosting_Header]
           ([Series]
           ,[TransferNo]
           ,[TransferDate]
           ,[Year]
           ,[Type]
           ,[RequestedBy]
           ,[ApprovedBy]
           ,[ActiveStatus]
           ,[CreatedBy]
           ,[CreatedOn]
           ,TypeofTransferIn
           ,TypeofTransferOut)
     VALUES
           (@Series
           ,@TransferNo
           ,@TransferDate
           ,@Year
           ,@Type
           ,@RequestedBy
           ,@ApprovedBy
           ,@ActiveStatus
           ,@CreatedBy
           ,GETDATE()
           ,@TypeofTransferIn
           ,@TypeofTransferOut
           )   
           
           IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
  
     DECLARE  
                        @AutoId numeric(18, 0) ,
                        @LineNo nvarchar(50) ,                    
                        @MaterialCode nvarchar(50) ,
                        @UOM nvarchar(50) ,
                        @ValuationType nvarchar(50) ,                   
                        @Plant nvarchar(50) ,
                        @StorageLocation nvarchar(50) ,
                        @Quantity numeric(18, 4) ,
                        @BatchNo nvarchar(50) ,
                        @Value numeric(18, 2)  
       DECLARE My_cursor CURSOR FAST_FORWARD FOR SELECT 
                        AutoId,
                        [LineNo],
                        MaterialCode  ,
                        UOM  ,
                        ValuationType ,                     
                        Plant ,
                        StorageLocation ,
                        Quantity ,
                        BatchNo,
                        Value
                        from @dtLineitems
                        
         Open My_cursor
         
         FETCH NEXT FROM My_cursor INTO                     
                  @AutoId  ,        
                  @LineNo  ,
                  @MaterialCode  ,
                  @UOM  ,
                  @ValuationType ,              
                  @Plant ,
                  @StorageLocation ,
                  @Quantity ,
                  @BatchNo,
                  @Value
                 
         WHILE @@FETCH_STATUS=0
               
         BEGIN
                
         -----------------------Insert Line Item details------------------------
         INSERT INTO [Proc_Glb_StorageLocationMovement_Details_Trans]
           ([TransferNo]
           ,[LineNo]
           ,[MaterialCode]
           ,[UOM]
           ,[ValuationType]
           ,[Plant]
           ,[StorageLocation]
           ,[Quantity]
           ,[BatchNo]
           ,[Value]
           ,[ActiveStatus]
           ,[CreatedBy]
           ,[CreatedOn])
     VALUES
           (@TransferNo
           ,@LineNo
           ,@MaterialCode
           ,@UOM
           ,@ValuationType
           ,@Plant
           ,@StorageLocation
           ,@Quantity
           ,@BatchNo
           ,@Value
           ,@ActiveStatus
           ,@CreatedBy
           ,GETDATE())
           
           IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
         
           ------------------------------------------------Update in Valuation Stock Table -----------------------------------
           
            declare @QualityInd bit
            Declare @MaterialId numeric(18,0)
            Set @MaterialId =(select AutoId from Proc_MaterialMaster where MaterialCode =@MaterialCode)
            
            Declare @MasterValuationStkAutoId numeric(18,0)      
            Set @MasterValuationStkAutoId = 0
            Set @MasterValuationStkAutoId = IsNull((Select Top 1 AutoID From Proc_MasterValuationStk Where MaterialCodeID = @MaterialId 
                  And Plant = @Plant And ValuationType = @ValuationType and StorageLocationID=@StorageLocation),0)
            If @MasterValuationStkAutoId > 0
            --=======If Record exist in Stock table=====================================================
                        Begin
                              if @Type = 'TO'
                                    Begin
                                    Update Proc_MasterValuationStk Set ValuatedQuantity -= @Quantity, ValuatedValue -= @Value
                                    Where AutoId = @MasterValuationStkAutoId
                                     
                                    End
                              Else if @Type = 'TI'
                                    Begin
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    if(@QualityInd =1)
                                    begin
                                       Update Proc_MasterValuationStk Set QtyUnderInsp += @Quantity, ValuatedValue += @Value
                                       Where AutoId = @MasterValuationStkAutoId
                                     
                                    end
                                    else
                                    begin
                                       Update Proc_MasterValuationStk Set ValuatedQuantity += @Quantity, ValuatedValue += @Value
                                       Where AutoId = @MasterValuationStkAutoId  
                                      
                                    end
                                    End
                        End
                  Else
                  --=======If Record does not exist in Stock table=====================================================
                        Begin
                              if @Type = 'TI'
                                    Begin
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    if(@QualityInd =1)
                                    INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,QtyUnderInsp
                                       ,StorageLocationID
                                       ,[ValuatedValue]
                                       ,[Aflag])
                                     VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@Quantity
                                       ,@StorageLocation
                                       ,@Value
                                       ,1)
                                    else
                                    INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,StorageLocationID
                                       ,[ValuatedQuantity]
                                       ,[ValuatedValue]
                                       ,[Aflag])
                              VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@StorageLocation
                                       ,@Quantity
                                       ,@Value
                                       ,1)
                                    
                                    End
                        End
                        
             
             IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END  
               
            --======================================Insert in JournalVoucher Header==============================================         
               
              DECLARE @RecCount INT   
              SET @RecCount=0   
              
              Set @RecCount = (select Count(VoucherNumber) from FA_Glb_JournalVoucher_Header_trans where [VoucherNumber] = @TransferNo)
                                       
            if @RecCount = 0
            begin						
            Insert Into FA_Glb_JournalVoucher_Header_trans (VoucherType, VoucherSeries, Voucher_Year, Vouchernumber,VoucherDate,MarkReversal,CreatedBy,Active,CreatedDate)
            Values ('TR', 'TR', @Year, @TransferNo,@TransferDate,0,@CreatedBy,1,GETDATE())
            IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
            
            end
          
          --======================================Insert in JournalVoucher Detail==============================================
          
                Declare @GlDs as nVarChar(150)		
				Declare @Debit_GLID Nvarchar(20)
				Declare @Credit_GLID Nvarchar(20)			
				Declare @CostCenterCode NVarchar(50)
				Declare @ProfitCenterCode NVarchar(50)				
				Declare @VendorAccGroupID Integer
				Declare @TransactionEvent NVarchar(10)			
				DECLARE @MaterialType NVARCHAR(50)				
                  
                Set @GlDs = 'Transfer Posting # ' +@TransferNo
                SET @MaterialType =(SELECT Type FROM Proc_MaterialMaster WHERE MaterialCode =@MaterialCode)	
				
				IF(@Type='TI')
				begin
				  IF(@TypeofTransferIn ='SCRAP')
				  begin
				    Set @TransactionEvent = 'TISCR'
				  end
				  ELSE IF(@TypeofTransferIn ='Upload')
				  begin
				    Set @TransactionEvent = 'TIUPD'
				  end
				  ELSE IF(@TypeofTransferIn ='PRODUCED')
				  begin
				    Set @TransactionEvent = 'PROD'
				  end
				end
				ELSE IF(@Type='TO')
				begin
				  IF(@TypeofTransferIn ='TO-SCR')
				  begin
				    Set @TransactionEvent = 'TOSCR'
				  end
				  ELSE IF(@TypeofTransferIn ='TO-WO')
				  begin
				    Set @TransactionEvent = 'TOWOF'
				  end
				end		        
		                               
				Set @VendorAccGroupID =  (Select top 1 VendorAccGroupID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND TransactionEvent = @TransactionEvent)
								
				Set @Debit_GLID = (Select top 1 Debit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Credit_GLID = (Select top 1 Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Debit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Debit_GLID)
				Set @Credit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Credit_GLID)
				
				Set @ProfitCenterCode = (Select ProfitCenter from Proc_MaterialMst2 where MaterialCode=@MaterialId)
				--SET @CostCenterCode = (select top 1 CostCenterCode from FA_Glb_CostCenterMaster_Mst where ProfitCenter =@ProfitCenterCode)
				SET @CostCenterCode=''

				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],
				[DebitAmount],[CreditAmount],[LineNo],CreatedDate,LastChangeDate,
				CostCenter,ProfitCenter,Currency,ExchangeRate) 
				Values(@TransferNo,'TR', @GlDs,@Debit_GLID,'',@Value,0,@LineItems,GETDATE(),
				GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 
				Set @LineItems =  @LineItems + 10
				
				IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
				
				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],[DebitAmount],
				[CreditAmount],[LineNo],CreatedDate,LastChangeDate,CostCenter,ProfitCenter,Currency,ExchangeRate ) 
				Values(@TransferNo,'TR', @GlDs,@Credit_GLID,'',0,@Value,@LineItems,GETDATE(),GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 	
				Set @LineItems =  @LineItems + 10
                  
                IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END                  
                  
                ----------------------------------------------------------------------
                
                FETCH NEXT FROM My_cursor INTO                    
                  @AutoId  ,  
                  @LineNo  ,
                  @MaterialCode  ,
                  @UOM  ,
                  @ValuationType ,              
                  @Plant ,
                  @StorageLocation ,
                  @Quantity ,
                  @BatchNo,
                  @Value
              
              IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END                
    End
    
    CLOSE My_cursor
    DEALLOCATE My_cursor 
            
       IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
                  ELSE
                 BEGIN   
                  SET @ErrorStatus =@@ERROR 
                  SET @NewTransferNo =@TransferNo
                  COMMIT TRANSACTION
                END
    
    End
    
         
 --==========================================Update All TVP Records=========================================================================

ELSE IF(@TransferId > 0)
   BEGIN
         UPDATE [Proc_Glb_TransferValuePosting_Header]
               SET [TransferDate] = @TransferDate      
                    ,[Type] = @Type
                    ,[RequestedBy] = @RequestedBy
                    ,[ApprovedBy] = @ApprovedBy      
                    ,[ModifiedBy] = @ModifiedBy
                    ,[ModifiedOn] = getDate()
                    ,TypeofTransferIn=@TypeofTransferIn
                    ,TypeofTransferOut=@TypeofTransferOut
            WHERE AutoId =@TransferId
         IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
      
      
       ---====HERE FIRST DELETE ALL THE PREVIOUS RECORDS FROM JV DETAILS TABLES ACCORDING TO THE TRANSFER NO================
   		   
		   DELETE FA_Glb_JournalVoucher_Details_trans where [VoucherNo] = @TransferNoExist
		   IF @@ERROR <> 0 
			   BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
                 
     ----==========================Insert/Update in Detail Tables===========================================================
            
       DECLARE My_cursor CURSOR FAST_FORWARD FOR SELECT 
                        AutoId,
                        [LineNo],
                        MaterialCode  ,
                        UOM  ,
                        ValuationType ,                     
                        Plant ,
                        StorageLocation ,
                        Quantity ,
                        BatchNo,
                        Value
                        from @dtLineitems
       Open My_cursor
       
       FETCH NEXT FROM My_cursor INTO                     
                  @AutoId  ,        
                  @LineNo  ,
                  @MaterialCode  ,
                  @UOM  ,
                  @ValuationType ,              
                  @Plant ,
                  @StorageLocation ,
                  @Quantity ,
                  @BatchNo,
                  @Value
                  
       WHILE @@FETCH_STATUS=0
               
                BEGIN
                
                --ADDED BY SATISH ON 19 JUN-13
                Update FA_Glb_JournalVoucher_Header_trans set VoucherDate =@TransferDate where VoucherNumber =@TransferNoExist
                IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
                 -----------------------------------------
                ---------------------Insert Line Item details------------------------
                
                IF(@AutoId = 0)
                BEGIN             
                 INSERT INTO [Proc_Glb_StorageLocationMovement_Details_Trans]
                           ([TransferNo]
                           ,[LineNo]
                           ,[MaterialCode]
                           ,[UOM]
                           ,[ValuationType]
                           ,[Plant]
                           ,[StorageLocation]
                           ,[Quantity]
                           ,[BatchNo]
                           ,[Value]
                           ,[ActiveStatus]
                           ,[CreatedBy]
                           ,[CreatedOn])
                  VALUES
                           (@TransferNoExist
                           ,@LineNo
                           ,@MaterialCode
                           ,@UOM
                           ,@ValuationType
                           ,@Plant
                           ,@StorageLocation
                           ,@Quantity
                           ,@BatchNo
                           ,@Value
                           ,@ActiveStatus
                           ,@CreatedBy
                           ,GETDATE())
                           
                  IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
           
           ----------------------------------------------Update in Valuation Stock Table -----------------------------------
                      
            Set @MaterialId =(select AutoId from Proc_MaterialMaster where MaterialCode =@MaterialCode)
               
                 -- Set @MasterValuationStkAutoId = 0
                   --COMMENTED BY SATISH ON 30 APR-13
                  --Set @MasterValuationStkAutoId = IsNull((Select Top 1 AutoID From Proc_MasterValuationStk Where MaterialCodeID = @MaterialId 
                  --And Plant = @Plant And ValuationType = @ValuationType),0)
                  
                  Set @MasterValuationStkAutoId = IsNull((Select Top 1 AutoID From Proc_MasterValuationStk Where MaterialCodeID = @MaterialId 
                  And Plant = @Plant And ValuationType = @ValuationType  and StorageLocationID=@StorageLocation),0)
                  
                  If @MasterValuationStkAutoId > 0
                   --=======If Record exist in Stock table=====================================================
                        Begin
                              if @Type = 'TO'
                                    Begin
                                    --COMMENTED BY SATISH ON 30 APR-13
                                          --Update Proc_MasterValuationStk Set ValuatedQuantity -= @Quantity, ValuatedValue -= @Value
                                          -- Where AutoId = @MasterValuationStkAutoId  and Plant=@Plant and StorageLocationID=@StorageLocation 
                                          -- and ValuationType=@ValuationType
                                          
                                          Update Proc_MasterValuationStk Set ValuatedQuantity -= @Quantity, ValuatedValue -= @Value
                                           Where AutoId = @MasterValuationStkAutoId
                                    End
                              Else if @Type = 'TI'
                                    Begin
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    
                                    if(@QualityInd =1)
                                    begin
                                    --COMMENTED BY SATISH ON 30 APR-13
                                       --Update Proc_MasterValuationStk Set QtyUnderInsp += @Quantity, ValuatedValue += @Value
                                       --Where AutoId = @MasterValuationStkAutoId
                                       --and Plant=@Plant and StorageLocationID=@StorageLocation and ValuationType=@ValuationType
                                       
                                       Update Proc_MasterValuationStk Set QtyUnderInsp += @Quantity, ValuatedValue += @Value
                                       Where AutoId = @MasterValuationStkAutoId
                                    end
                                    else
                                    begin
                                    --COMMENTED BY SATISH ON 30 APR-13
                                       --Update Proc_MasterValuationStk Set ValuatedQuantity += @Quantity, ValuatedValue += @Value 
                                       --Where AutoId = @MasterValuationStkAutoId
                                       --and Plant=@Plant and StorageLocationID=@StorageLocation and ValuationType=@ValuationType
                                       
                                       Update Proc_MasterValuationStk Set ValuatedQuantity += @Quantity, ValuatedValue += @Value 
                                       Where AutoId = @MasterValuationStkAutoId
                                    end 
                                    
                                          
                                    End
                        End
                  Else
                  --=======If Record does not exist in Stock table=====================================================
                        Begin
                              if @Type = 'TI'
                              
                              Begin
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    if(@QualityInd =1)
                                    begin
                                      INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,StorageLocationID
                                       ,QtyUnderInsp
                                       ,[ValuatedValue]
                                       ,[Aflag])
                              VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@StorageLocation
                                       ,@Quantity
                                       ,@Value
                                       ,1)
                                    end
                                    else
                                    begin
                                    
                                   INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,StorageLocationID
                                       ,[ValuatedQuantity]
                                       ,[ValuatedValue]
                                       ,[Aflag])
                              VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@StorageLocation
                                       ,@Quantity
                                       ,@Value
                                       ,1)      
                                   end
                                       
                                       IF @@ERROR <> 0 
										 BEGIN   
											 SET @ErrorStatus =@@ERROR  
											 SET @NewTransferNo =''   
											 ROLLBACK TRANSACTION
										 END                              
                                    End
                        End  
                        
                  --==========================Insert Record in JV Details Table====================================================           
                  
                Set @GlDs = 'Transfer Posting # ' +@TransferNoExist
                SET @MaterialType =(SELECT Type FROM Proc_MaterialMaster WHERE MaterialCode =@MaterialCode)	
				
				IF(@Type='TI')
				begin
				  IF(@TypeofTransferIn ='SCRAP')
				  begin
				    Set @TransactionEvent = 'TISCR'
				  end
				  ELSE IF(@TypeofTransferIn ='Upload')
				  begin
				    Set @TransactionEvent = 'TIUPD'
				  end
				  ELSE IF(@TypeofTransferIn ='PRODUCED')
				  begin
				    Set @TransactionEvent = 'PROD'
				  end
				end
				ELSE IF(@Type='TO')
				begin
				  IF(@TypeofTransferIn ='TO-SCR')
				  begin
				    Set @TransactionEvent = 'TOSCR'
				  end
				  ELSE IF(@TypeofTransferIn ='TO-WO')
				  begin
				    Set @TransactionEvent = 'TOWOF'
				  end
				end		        
		                               
				Set @VendorAccGroupID =  (Select top 1 VendorAccGroupID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND TransactionEvent = @TransactionEvent)
								
				Set @Debit_GLID = (Select top 1 Debit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Credit_GLID = (Select top 1 Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Debit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Debit_GLID)
				Set @Credit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Credit_GLID)
				
				Set @ProfitCenterCode = (Select ProfitCenter from Proc_MaterialMst2 where MaterialCode=@MaterialId)
				--SET @CostCenterCode = (select top 1 CostCenterCode from FA_Glb_CostCenterMaster_Mst where ProfitCenter =@ProfitCenterCode)
				SET @CostCenterCode=''

				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],
				[DebitAmount],[CreditAmount],[LineNo],CreatedDate,LastChangeDate,
				CostCenter,ProfitCenter,Currency,ExchangeRate) 
				Values(@TransferNoExist,'TR', @GlDs,@Debit_GLID,'',@Value,0,@LineItems,GETDATE(),
				GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 
				Set @LineItems =  @LineItems + 10
				
				IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
				
				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],[DebitAmount],
				[CreditAmount],[LineNo],CreatedDate,LastChangeDate,CostCenter,ProfitCenter,Currency,ExchangeRate ) 
				Values(@TransferNoExist,'TR', @GlDs,@Credit_GLID,'',0,@Value,@LineItems,GETDATE(),GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 	
				Set @LineItems =  @LineItems + 10
                  
                IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END 
                                  
          --=========================================================================================
                                              
                END
               IF(@AutoId > 0)
               --=======Update the existing transfer value posting record of lineitem in stock table=====================================================
               BEGIN
                    
                    --ADDED BY SATISH ON 30 APR-13
                    DECLARE @PreQuantity numeric(18,4)
                    DECLARE @PreValue numeric(18,4)
                    DECLARE @ValuatedValue numeric(18,4)
                    
                    set @PreQuantity=(select Quantity from Proc_Glb_StorageLocationMovement_Details_Trans where AutoId =@AutoId)
                    set @PreValue=(select Value from Proc_Glb_StorageLocationMovement_Details_Trans where AutoId =@AutoId)
                    
                    --===============================================================
                    
                    UPDATE [Proc_Glb_StorageLocationMovement_Details_Trans]
              SET [MaterialCode] = @MaterialCode
                    ,[UOM] = @UOM
                    ,[ValuationType] = @ValuationType      
                    ,[Quantity] = @Quantity     
                    ,[Value] = @Value      
                    ,[ModifiedBy] = @ModifiedBy
                    ,[ModifiedOn] = GETDATE()
            WHERE AutoId =@AutoId     
            
            
            IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
                  
               -- END    
                  
                     ----------------------------------------------Update in Valuation Stock Table -----------------------------------
                      
            Set @MaterialId =(select AutoId from Proc_MaterialMaster where MaterialCode =@MaterialCode)
               
                  Set @MasterValuationStkAutoId = 0
                  --COMMENTED BY SATISH ON 30 APR-13
                  --Set @MasterValuationStkAutoId = IsNull((Select Top 1 AutoID From Proc_MasterValuationStk Where MaterialCodeID = @MaterialId 
                  --And Plant = @Plant And ValuationType = @ValuationType),0)
                  
                  Set @MasterValuationStkAutoId = IsNull((Select Top 1 AutoID From Proc_MasterValuationStk Where MaterialCodeID = @MaterialId 
                  And Plant = @Plant And ValuationType = @ValuationType and StorageLocationID=@StorageLocation),0)
                  
                  If @MasterValuationStkAutoId > 0
                        Begin
                              if @Type = 'TO'
                                    Begin
                                    --COMMENTED BY SATISH ON 30 APR-13
                                          --Update Proc_MasterValuationStk Set ValuatedQuantity -= @Quantity, ValuatedValue -= @Value
                                          -- Where AutoId = @MasterValuationStkAutoId  and Plant=@Plant and StorageLocationID=@StorageLocation 
                                          -- and ValuationType=@ValuationType
                                          
                                          Update Proc_MasterValuationStk Set ValuatedQuantity -= @Quantity, ValuatedValue -= @Value
                                           Where AutoId = @MasterValuationStkAutoId
                                           
                                    End
                              Else if @Type = 'TI'
                                    Begin                            
                                    
                                    SET @ValuatedValue = @Value-@PreValue
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    if(@QualityInd =1)
                                    begin
                                    
	                                   DECLARE @QtyUnderInsp as numeric(18,4)
                                       SET @QtyUnderInsp =@Quantity	- @PreQuantity                               
                                       
                                       --COMMENTED BY SATISH ON 30 APR-13
                                       --Update Proc_MasterValuationStk Set QtyUnderInsp += @Quantity, ValuatedValue += @Value
                                       --Where AutoId = @MasterValuationStkAutoId
                                       --and Plant=@Plant and StorageLocationID=@StorageLocation and ValuationType=@ValuationType
                                       
                                       Update Proc_MasterValuationStk Set QtyUnderInsp += @QtyUnderInsp, ValuatedValue += @ValuatedValue
                                       Where AutoId = @MasterValuationStkAutoId
                                       
                                    end
                                    else
                                    begin
                                    
                                       DECLARE @ValuatedQuantity as numeric(18,4)
                                       SET @ValuatedQuantity =@Quantity - @PreQuantity 
                                       
                                       --COMMENTED BY SATISH ON 30 APR-13
                                       --Update Proc_MasterValuationStk Set ValuatedQuantity += @Quantity, ValuatedValue += @Value 
                                       --Where AutoId = @MasterValuationStkAutoId
                                       --and Plant=@Plant and StorageLocationID=@StorageLocation and ValuationType=@ValuationType
                                       
                                       Update Proc_MasterValuationStk Set ValuatedQuantity += @ValuatedQuantity, ValuatedValue += @ValuatedValue 
                                       Where AutoId = @MasterValuationStkAutoId
                                       
                                    end
                                          
                                    End
                                    
                                    IF @@ERROR <> 0 
											 BEGIN   
												 SET @ErrorStatus =@@ERROR  
												 SET @NewTransferNo =''   
												 ROLLBACK TRANSACTION
											 END 
                        End
                  Else
                        Begin
                              if @Type = 'TI'
                              
                              Begin
                                    
                                    set @QualityInd =(select QualityInd from Proc_MaterialMaster where AutoId =@MaterialId)
                                    if(@QualityInd =1)
                                    begin
                                      INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,StorageLocationID
                                       ,QtyUnderInsp
                                       ,[ValuatedValue]
                                       ,[Aflag])
                              VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@StorageLocation
                                       ,@Quantity
                                       ,@Value
                                       ,1)
                                    end
                                    else
                                    begin
                                    
                                   INSERT INTO [Proc_MasterValuationStk]
                                       ([MaterialCodeID]
                                       ,[MaterialCode]
                                       ,[Plant]
                                       ,[ValuationType]
                                       ,StorageLocationID
                                       ,[ValuatedQuantity]
                                       ,[ValuatedValue]
                                       ,[Aflag])
                              VALUES
                                       (@MaterialId
                                       ,@MaterialCode
                                       ,@Plant
                                       ,@ValuationType
                                       ,@StorageLocation
                                       ,@Quantity
                                       ,@Value
                                       ,1)      
                                   end
                                   
                                   IF @@ERROR <> 0 
											 BEGIN   
												 SET @ErrorStatus =@@ERROR  
												 SET @NewTransferNo =''   
												 ROLLBACK TRANSACTION
											 END 
                              End
                      End
                      
                  --==========================Insert Record in JV Details Table====================================================           
                  
                Set @GlDs = 'Transfer Posting # ' +@TransferNoExist
                SET @MaterialType =(SELECT Type FROM Proc_MaterialMaster WHERE MaterialCode =@MaterialCode)	
				
				IF(@Type='TI')
				begin
				  IF(@TypeofTransferIn ='SCRAP')
				  begin
				    Set @TransactionEvent = 'TISCR'
				  end
				  ELSE IF(@TypeofTransferIn ='Upload')
				  begin
				    Set @TransactionEvent = 'TIUPD'
				  end
				  ELSE IF(@TypeofTransferIn ='PRODUCED')
				  begin
				    Set @TransactionEvent = 'PROD'
				  end
				end
				ELSE IF(@Type='TO')
				begin
				  IF(@TypeofTransferIn ='TO-SCR')
				  begin
				    Set @TransactionEvent = 'TOSCR'
				  end
				  ELSE IF(@TypeofTransferIn ='TO-WO')
				  begin
				    Set @TransactionEvent = 'TOWOF'
				  end
				end		        
		                               
				Set @VendorAccGroupID =  (Select top 1 VendorAccGroupID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND TransactionEvent = @TransactionEvent)
								
				Set @Debit_GLID = (Select top 1 Debit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Credit_GLID = (Select top 1 Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = @MaterialType
					AND ValuationTypeID = @ValuationType AND VendorAccGroupID = @VendorAccGroupID AND TransactionEvent = @TransactionEvent)

				Set @Debit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Debit_GLID)
				Set @Credit_GLID = (Select top 1  GeneralLedgerCode from FA_Glb_GLMaster_Mst where autoid = @Credit_GLID)
				
				Set @ProfitCenterCode = (Select ProfitCenter from Proc_MaterialMst2 where MaterialCode=@MaterialId)
				--SET @CostCenterCode = (select top 1 CostCenterCode from FA_Glb_CostCenterMaster_Mst where ProfitCenter =@ProfitCenterCode)
				SET @CostCenterCode = ''

				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],
				[DebitAmount],[CreditAmount],[LineNo],CreatedDate,LastChangeDate,
				CostCenter,ProfitCenter,Currency,ExchangeRate) 
				Values(@TransferNoExist,'TR', @GlDs,@Debit_GLID,'',@Value,0,@LineItems,GETDATE(),
				GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 
				Set @LineItems =  @LineItems + 10
				
				IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
				
				Insert Into FA_Glb_JournalVoucher_Details_trans 
				([VoucherNo],VoucherType,[VoucherDescr],[GLCode],[SubGLCode],[DebitAmount],
				[CreditAmount],[LineNo],CreatedDate,LastChangeDate,CostCenter,ProfitCenter,Currency,ExchangeRate ) 
				Values(@TransferNoExist,'TR', @GlDs,@Credit_GLID,'',0,@Value,@LineItems,GETDATE(),GETDATE(),@CostCenterCode,@ProfitCenterCode,1,1 ) 	
				Set @LineItems =  @LineItems + 10
                  
                IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END 
					    
			  --=========================================================================================
                
                END 
                 --------------------------------------------------------------------
                
                FETCH NEXT FROM My_cursor INTO                    
                  @AutoId  ,        
                  @LineNo  ,
                  @MaterialCode  ,
                  @UOM  ,
                  @ValuationType ,              
                  @Plant ,
                  @StorageLocation ,
                  @Quantity ,
                  @BatchNo,
                  @Value  
                  
                   IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END 
                  
               END
               
       CLOSE My_cursor
       DEALLOCATE My_cursor 
       IF @@ERROR <> 0 
                 BEGIN   
                     SET @ErrorStatus =@@ERROR  
                     SET @NewTransferNo =''   
                     ROLLBACK TRANSACTION
                 END
                  ELSE
                BEGIN   
                  SET @ErrorStatus =@@ERROR 
                  SET @NewTransferNo ='0'
                  COMMIT TRANSACTION
                END             
              
   
 end
GO