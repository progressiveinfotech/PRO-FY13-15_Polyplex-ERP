
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_InsertUpdate_In_ChipsBagging]') AND type in (N'P', N'PC'))
DROP PROC SP_InsertUpdate_In_ChipsBagging
GO

/****** Object:  UserDefinedTableType [dbo].[Chips_ChipsBagging_LineItems_Trans]    Script Date: 06/18/2013 00:16:09 ******/
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'Chips_ChipsBagging_LineItems_Trans' AND ss.name = N'dbo')
DROP TYPE [dbo].[Chips_ChipsBagging_LineItems_Trans]
GO



/****** Object:  UserDefinedTableType [dbo].[Chips_ChipsBagging_LineItems_Trans]    Script Date: 06/18/2013 00:16:09 ******/
CREATE TYPE [dbo].[Chips_ChipsBagging_LineItems_Trans] AS TABLE(
	[AutoId] [bigint] NULL,
	[LnNo] [int] NULL,
	[BagNo] [bigint] NULL,
	[PlantId] [numeric](18, 0) NULL,
	[StorageLocationIssue] [bigint] NULL,
	[StorageLocationRec] [bigint] NULL,
	[MaterialId] [bigint] NULL,
	[BUOM] [int] NULL,
	[ValuationTypeId] [bigint] NULL,
	[BatchCode] [nvarchar](8) NULL,
	[ChipsBags] [numeric](18, 2) NULL,
	[Quantity] [numeric](18, 2) NULL,
	[Aflag] [bit] NULL
)
GO


