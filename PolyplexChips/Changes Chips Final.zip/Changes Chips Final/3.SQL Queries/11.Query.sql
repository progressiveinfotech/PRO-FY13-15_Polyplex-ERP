INSERT [dbo].[Com_Auto_GL_Determination_Mst]
([MaterialTypeID], [ValuationTypeID], [VendorAccGroupID], [TransactionEvent], [Debit_GLID], [Credit_GLID], [RoundOff_GLID], [DeliveryCost_GLID], [PriceDiff_GLID], [ExchDiff_GLID], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [Freight_GLID], [Insurance_GLID], [SalesTax_GLID])
VALUES
(8, 15, 1, N'PROD', 57, 10, NULL, NULL, NULL, NULL, NULL, CAST(0x0000A12300D04116 AS DateTime), NULL, CAST(0x0000A12300D04116 AS DateTime), 1, NULL, NULL, NULL)
GO