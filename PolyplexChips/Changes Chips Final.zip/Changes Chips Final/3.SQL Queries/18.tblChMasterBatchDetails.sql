

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_tblChMasterBatchDetails_BatchCode]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[tblChMasterBatchDetails] DROP CONSTRAINT [DF_tblChMasterBatchDetails_BatchCode]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_tblChMasterBatchDetails_CreatedOn]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[tblChMasterBatchDetails] DROP CONSTRAINT [DF_tblChMasterBatchDetails_CreatedOn]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_tblChMasterBatchDetails_ModifiedOn]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[tblChMasterBatchDetails] DROP CONSTRAINT [DF_tblChMasterBatchDetails_ModifiedOn]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_tblChMasterBatchDetails_AFlag]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[tblChMasterBatchDetails] DROP CONSTRAINT [DF_tblChMasterBatchDetails_AFlag]
END

GO



/****** Object:  Table [dbo].[tblChMasterBatchDetails]    Script Date: 06/29/2013 02:05:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblChMasterBatchDetails]') AND type in (N'U'))
DROP TABLE [dbo].[tblChMasterBatchDetails]
GO



/****** Object:  Table [dbo].[tblChMasterBatchDetails]    Script Date: 06/29/2013 02:05:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblChMasterBatchDetails](
	[AutoId] [bigint] IDENTITY(1,1) NOT NULL,
	[DocAutoId] [bigint] NOT NULL,
	[LineNo] [numeric](18, 0) NOT NULL,
	[MaterialCodeID] [bigint] NOT NULL,
	[ValuationTypeId] [int] NOT NULL,
	[BatchCode] [bigint] NOT NULL,
	[StorageLocationId] [int] NOT NULL,
	[PlantId] [numeric](18, 0) NOT NULL,
	[Quantity] [decimal](12, 2) NOT NULL,
	[Value] [decimal](18, 2) NOT NULL,
	[PreparationDilution] [nvarchar](1) NOT NULL,
	[Category] [nvarchar](8) NOT NULL,
	[TnfGILineItemId] [bigint] NULL,
	[CreatedBy] [numeric](18, 0) NOT NULL,
	[CreatedOn] [datetime] NULL,
	[ModifiedBy] [numeric](18, 0) NOT NULL,
	[ModifiedOn] [datetime] NULL,
	[AFlag] [bit] NOT NULL,
 CONSTRAINT [PK_tblChMasterBatchDetails] PRIMARY KEY CLUSTERED 
(
	[AutoId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[tblChMasterBatchDetails] ADD  CONSTRAINT [DF_tblChMasterBatchDetails_BatchCode]  DEFAULT ('') FOR [BatchCode]
GO

ALTER TABLE [dbo].[tblChMasterBatchDetails] ADD  CONSTRAINT [DF_tblChMasterBatchDetails_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[tblChMasterBatchDetails] ADD  CONSTRAINT [DF_tblChMasterBatchDetails_ModifiedOn]  DEFAULT (getdate()) FOR [ModifiedOn]
GO

ALTER TABLE [dbo].[tblChMasterBatchDetails] ADD  CONSTRAINT [DF_tblChMasterBatchDetails_AFlag]  DEFAULT ((1)) FOR [AFlag]
GO


