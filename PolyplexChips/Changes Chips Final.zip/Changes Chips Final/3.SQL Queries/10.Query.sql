
update Proc_Glb_StorageLocationMovement_Header set Type ='SLM' where Type =''
go