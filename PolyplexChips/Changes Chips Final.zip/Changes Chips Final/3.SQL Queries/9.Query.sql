
alter table Proc_Glb_StorageLocationMovement_Header add PostingDate datetime
go