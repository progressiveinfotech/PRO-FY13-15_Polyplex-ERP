
ALTER TABLE Proc_MasterValuationStk ADD StandardPrice decimal(18, 4)
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Proc_MasterValuationStk_StandardPrice]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Proc_MasterValuationStk] DROP CONSTRAINT [DF_Proc_MasterValuationStk_StandardPrice]
END



ALTER TABLE [dbo].[Proc_MasterValuationStk] ADD  CONSTRAINT [DF_Proc_MasterValuationStk_StandardPrice]  DEFAULT ((0)) FOR [StandardPrice]
GO