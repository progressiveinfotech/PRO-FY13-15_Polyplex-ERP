
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR04 - PTA Analysis', N'ChipsProduction/Reports/PTAAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR05 - MEG Analysis', N'ChipsProduction/Reports/MEGAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR06 - CP Chips Quality', N'ChipsProduction/Reports/CPChipsQuality.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR07 - Sample Entry', N'ChipsProduction/Reports/SampleEntry.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR08 - PTA Slurry Analysis', N'ChipsProduction/Reports/PTASlurryAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR09 - Monomer', N'ChipsProduction/Reports/Monomer.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR10 - Column (Top & Bottom)', N'ChipsProduction/Reports/ColumnTopAndBottom.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR11 - Hot Well Finisher', N'ChipsProduction/Reports/HotWellFinisher.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR12 - Polymer Sample', N'ChipsProduction/Reports/PolymerSample.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR13 - Erema', N'ChipsProduction/Reports/Erema.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR14 - Outside Chips', N'ChipsProduction/Reports/OutsideChips.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR15 - MEG From Process', N'ChipsProduction/Reports/MEGFromProcess.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR16 - ATO Test Result', N'ChipsProduction/Reports/ATOTestResult.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR17 - Prepolymer', N'ChipsProduction/Reports/Prepolymer.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Reports', N'CPR18 - Samples', N'ChipsProduction/Reports/Samples.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
GO

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR04 - PTA Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR05 - MEG Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR06 - CP Chips Quality'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR07 - Sample Entry'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR08 - PTA Slurry Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR09 - Monomer'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR10 - Column (Top & Bottom)'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR11 - Hot Well Finisher'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR12 - Polymer Sample'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR13 - Erema'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR14 - Outside Chips'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR15 - MEG From Process'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR16 - ATO Test Result'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR17 - Prepolymer'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR18 - Samples'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO

