
update Proc_MasterValuationStk set StandardPrice =0
go