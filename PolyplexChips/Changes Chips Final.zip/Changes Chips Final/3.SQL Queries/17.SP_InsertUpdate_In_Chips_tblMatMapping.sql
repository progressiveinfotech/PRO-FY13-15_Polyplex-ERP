
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_InsertUpdate_In_Chips_tblMatMapping]') AND type in (N'P', N'PC'))
DROP PROC SP_InsertUpdate_In_Chips_tblMatMapping
GO

/****** Object:  StoredProcedure [dbo].[SP_InsertUpdate_In_Chips_tblChMasterBatch]    Script Date: 06/21/2013 23:38:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SP_InsertUpdate_In_Chips_tblMatMapping]    

	 @AutoId AS bigint
	,@BatchId as bigint
	,@MaterialId as bigint
	,@Category as nvarchar(8)
	,@CreatedBy as  numeric(18,0)
	,@ModifiedBy as  numeric(18,0)
	,@AFlag as  bit
    ,@ErrorStatus as nvarchar(100) OUTPUT
 
AS

BEGIN TRANSACTION

	SET NOCOUNT ON;
		
   IF(@AutoId=0)
	     BEGIN
	     
	        --========INSERT SECTION================================================================================
	        
	        INSERT INTO [tblMatMapping]
           ([BatchId]
           ,[MaterialId]
           ,[Category]
           ,[CreatedBy]
           ,[CreatedOn]
           ,[ModifiedBy]
           ,[AFlag])
     VALUES
           (@BatchId
           ,@MaterialId
           ,@Category
           ,@CreatedBy
           ,GETDATE ()
           ,@ModifiedBy
           ,@AFlag)
     END      
	ELSE IF(@AutoId>0)
	BEGIN
	--========UPDATE SECTION================================================================================
	   UPDATE [tblMatMapping]
	   SET [BatchId] = @BatchId
		  ,[MaterialId] = @MaterialId
		  ,[Category] = @Category
		  ,[ModifiedBy] = @ModifiedBy
		  ,[ModifiedOn] = GETDATE ()
		  ,[AFlag] = @AFlag
		WHERE AutoId =@AutoId
	END	
	
	IF @@ERROR <> 0 
		    BEGIN
			  SET @ErrorStatus=@@ERROR 
			  ROLLBACK TRANSACTION
		    END
			ELSE
		    BEGIN	
		      SET @ErrorStatus =@@ERROR		            
		      COMMIT TRANSACTION
		    END
GO