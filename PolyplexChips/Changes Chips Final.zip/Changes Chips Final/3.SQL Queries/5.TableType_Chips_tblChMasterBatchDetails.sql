
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_InsertUpdate_In_Chips_tblChMasterBatch]') AND type in (N'P', N'PC'))
DROP PROC SP_InsertUpdate_In_Chips_tblChMasterBatch
GO
/****** Object:  UserDefinedTableType [dbo].[Chips_tblChMasterBatchDetails]    Script Date: 06/29/2013 02:08:29 ******/
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'Chips_tblChMasterBatchDetails' AND ss.name = N'dbo')
DROP TYPE [dbo].[Chips_tblChMasterBatchDetails]
GO


/****** Object:  UserDefinedTableType [dbo].[Chips_tblChMasterBatchDetails]    Script Date: 06/29/2013 02:08:29 ******/
CREATE TYPE [dbo].[Chips_tblChMasterBatchDetails] AS TABLE(
	[AutoId] [bigint] NULL,
	[LineNo] [numeric](18, 0) NULL,
	[MaterialCodeID] [bigint] NULL,
	[MaterialCode] [nvarchar](50) NULL,
	[ValuationTypeId] [int] NULL,
	[ValuationTypeName] [nvarchar](50) NULL,
	[BatchCode] [bigint] NULL,
	[StorageLocationId] [int] NULL,
	[StorageLocationCode] [nvarchar](50) NULL,
	[PlantId] [numeric](18, 0) NULL,
	[Quantity] [decimal](12, 2) NULL,
	[Value] [decimal](18, 2) NULL,
	[PreparationDilution] [nvarchar](1) NULL,
	[AFlag] [bit] NULL
)
GO


