
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT01 - Master Batch', N'ChipsProduction/MasterBatch.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT02 - CP Entry', N'ChipsProduction/CPEntry.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT03 - Chips Movement', N'ChipsProduction/ChipsMovement.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT04 - Chips Bagging', N'ChipsProduction/ChipsBagging.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT05 - PTA Analysis', N'ChipsProduction/PTAAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT06 - MEG Analysis', N'ChipsProduction/MEGAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT07 - CP Chips Quality', N'ChipsProduction/CPChipsQuality.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Transaction', N'CPT08 - Sample Entry', N'ChipsProduction/SampleEntry.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)

INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Reports', N'CPR01 - Chips Daily Production', N'ChipsProduction/Reports/ChipsDailyProduction.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Reports', N'CPR02 - Input Output Listing', N'ChipsProduction/Reports/InputOutputListing.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ( [ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES ( N'ChipsProduction', N'Reports', N'CPR03 - Chips Bag Label', N'ChipsProduction/Reports/ChipsBagLabel.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)

INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT09 - PTA Slurry Analysis', N'ChipsProduction/PTASlurryAnalysis.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT10 - Monomer', N'ChipsProduction/Monomer.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT11 - Column (Top & Bottom)', N'ChipsProduction/ColumnTopAndBottom.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT12 - Hot Well Finisher', N'ChipsProduction/HotWellFinisher.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT13 - Polymer Sample', N'ChipsProduction/PolymerSample.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT14 - Erema', N'ChipsProduction/Erema.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT15 - Outside Chips', N'ChipsProduction/OutsideChips.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT16 - MEG From Process', N'ChipsProduction/MEGFromProcess.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT17 - ATO Test Result', N'ChipsProduction/ATOTestResult.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT18 - Prepolymer', N'ChipsProduction/Prepolymer.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
INSERT [dbo].[Com_Module_Mst] ([ModuleName], [SubModuleName], [FormName], [FormURL], [AccessLevel], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [ActiveStatus], [LocationID]) VALUES (N'ChipsProduction', N'Transaction', N'CPT19 - Samples', N'ChipsProduction/Samples.aspx', N'Local', CAST(1 AS Numeric(18, 0)), NULL, NULL, NULL, 1, NULL)
GO

GO


INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT01 - Master Batch'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT02 - CP Entry'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT03 - Chips Movement'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT04 - Chips Bagging'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES 
( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT05 - PTA Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT06 - MEG Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT07 - CP Chips Quality'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)),(select ModuleFormID from Com_Module_Mst where FormName ='CPT08 - Sample Entry'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR01 - Chips Daily Production'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES 
( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR02 - Input Output Listing'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPR03 - Chips Bag Label'), 1, 1, 1, NULL, NULL, NULL, NULL)


INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn])
 VALUES ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT09 - PTA Slurry Analysis'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT10 - Monomer'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT11 - Column (Top & Bottom)'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT12 - Hot Well Finisher'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES 
( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT13 - Polymer Sample'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT14 - Erema'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT15 - Outside Chips'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)),(select ModuleFormID from Com_Module_Mst where FormName ='CPT16 - MEG From Process'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT17 - ATO Test Result'), 1, 1, 1, NULL, NULL, NULL, NULL)
 
INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES 
( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT18 - Prepolymer'), 1, 1, 1, NULL, NULL, NULL, NULL)

INSERT [dbo].[Com_Group_Module_Mapping] ( [GroupId], [ModuleFormID], [Read], [Write], [Modify], [CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn]) VALUES
 ( CAST(1 AS Numeric(18, 0)), (select ModuleFormID from Com_Module_Mst where FormName ='CPT19 - Samples'), 1, 1, 1, NULL, NULL, NULL, NULL)
GO
