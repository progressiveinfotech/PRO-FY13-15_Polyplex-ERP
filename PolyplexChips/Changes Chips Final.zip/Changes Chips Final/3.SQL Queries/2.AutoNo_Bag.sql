



insert into Com_Series_Master(Year,FormID,CriteriaID,CriteriaValue,FromRange,ToRange,createdby,CreatedOn,Status)
Values('13-14',(Select ModuleFormID from Com_Module_Mst where FormURL='ChipsProduction/ChipsBagging.aspx')
,0,0,31000000,31999999,1,GETDATE(),0)


--exec Sp_GetNumberSeries_ForCriteria '327','13-14','',''