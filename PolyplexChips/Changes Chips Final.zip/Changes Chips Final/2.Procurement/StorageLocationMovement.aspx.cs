﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region********************************************Variables ************************************************

    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();    
    Common com = new Common();
    Proc_StorageLocationMovement objstoragelocation = new Proc_StorageLocationMovement();

    Connection objConnectionClass = new Connection();
    string ErrorStatus, RecordNo;
    

    #endregion

    #region************************************************Events**********************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //Code to disable the save btn to avoid double click
            ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
            
            //========================================

            if (!IsPostBack)
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "Storage Location Movement";

                TxtTransferDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                FillFinancialYear();

                #region Bind Masters

                BindSearchList();
                //changed by lalit 20Feb 2013
                //BindUOM();
                //end
                #endregion

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";
                //added by lalit 20feb 2013
                BindPlant(DdlPlantFrom);
                BindPlant(DdlPlantTo);                
                //end
                #region Change Color of Readonly Fields

                TxtTransferNo.Attributes.Add("style", "background:lightgray");
                TxtTransferDate.Attributes.Add("style", "background:lightgray");
                TxtYear.Attributes.Add("style", "background:lightgray");
               // txtPlantFrom.Attributes.Add("style", "background:lightgray");
               // txtPlantTo.Attributes.Add("style", "background:lightgray");
                txtStorageLocationFrom.Attributes.Add("style", "background:lightgray");
                txtStorageLocationTo.Attributes.Add("style", "background:lightgray");
                TxtRequestedBy.Attributes.Add("style", "background:lightgray");
                TxtApprovedBy.Attributes.Add("style", "background:lightgray");
                TxtMaterialCode.Attributes.Add("style", "background:lightgray");
                //TxtBatch.Attributes.Add("style", "background:lightgray");
                TxtValue.Attributes.Add("style", "background:lightgray");
                //added by lalit 4march 2013
                TxtAvailablestock.Attributes.Add("style", "background:lightgray");
                //end
                //added by lalit 9march 2013
                TxtBatch.Attributes.Add("readonly", "true");
                TxtBatch.Attributes.Add("style", "background:lightgray");
                //end
                #endregion

                #region Readonly Fields

                TxtTransferNo.Attributes.Add("readonly", "true");
                TxtTransferDate.Attributes.Add("readonly", "true");
                TxtYear.Attributes.Add("readonly", "true");
               // txtPlantFrom.Attributes.Add("readonly", "true");
               // txtPlantTo.Attributes.Add("readonly", "true");
                txtStorageLocationFrom.Attributes.Add("readonly", "true");
                txtStorageLocationTo.Attributes.Add("readonly", "true");
                TxtRequestedBy.Attributes.Add("readonly", "true");
                TxtApprovedBy.Attributes.Add("readonly", "true");
                TxtMaterialCode.Attributes.Add("readonly", "true");
               // TxtBatch.Attributes.Add("readonly", "true");
                TxtValue.Attributes.Add("readonly", "true");

                //added by lalit 4march 2013
                TxtAvailablestock.Attributes.Add("readonly", "true");
                //end
                #endregion

                #region Blank Grid

                gvStorageLocationMovement.DataSource = "";
                gvStorageLocationMovement.DataBind();
                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                #endregion

                TxtTransferNo.Text = AutogenerateNo(TxtYear.Text);
            }

            ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
            btnAdd.CausesValidation = false;
            btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

            ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
            imgbtnSearch.CausesValidation = false;
            imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);
        }
        catch (Exception ex) { }        
    }    

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        ClearHeader();
        ClearLineItems();
        GetProc_Glb_StorageLocationMovement_Details_Trans("0");
        DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
        TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
        ddlSearch.SelectedIndex = 0;
        txtSearch.Text = "";
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";
            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
        }
        catch (Exception ex) { }

        ModalPopupExtender1.Show();
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";
                //added by lalit 4march 2013
                ClearLineItems();
                //end
                hidTransferId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderAndGridRecords(hidTransferId.Value);
            }
        }
        catch (Exception ex) { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch (Exception ex) { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            txtSearchList.Focus();
        }
        catch (Exception ex) { }

        ModalPopupExtender1.Show();
    }

    protected void imgPlantFrom_Click(object sender, ImageClickEventArgs e)
    {
        txtSearchFromPopup.Text = "";
        HidPopUpType.Value = "PlantFrom";
        lPopUpHeader.Text = "Plant Master";
        lSearch.Text = "Search By Plant: ";
        FillAllPlantMaster("");
        ModalPopupExtender2.Show();
    }

    protected void imgBtnPlantTo_Click(object sender, ImageClickEventArgs e)
    {
        txtSearchFromPopup.Text = "";
        HidPopUpType.Value = "PlantTo";
        lPopUpHeader.Text = "Plant Master";
        lSearch.Text = "Search By Plant: ";
        FillAllPlantMaster("");
        ModalPopupExtender2.Show();
    }

    protected void imgBtnStorageLocationFrom_Click(object sender, ImageClickEventArgs e)
    {
        if (DdlPlantFrom.SelectedValue != "")
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationFrom";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Storage Location: ";
            BindStorageLocation("",DdlPlantFrom.SelectedValue);
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the plant from first.", 125, 300);
        }
    }

    protected void imgBtnStorageLocationTo_Click(object sender, ImageClickEventArgs e)
    {
        if (DdlPlantTo.SelectedValue != "")
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationTo";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Storage Location: ";
            BindToStorageLocation("", DdlPlantTo.SelectedValue);
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the plant to first.", 125, 300);
        }
    }    

    protected void ImgBtnRequestedBy_Click(object sender, ImageClickEventArgs e)
    {
        txtSearchFromPopup.Text = "";
        HidPopUpType.Value = "RequestBy";
        lPopUpHeader.Text = "Request By";
        lSearch.Text = "Search By Request By: ";
        BindEmployee("");
        ModalPopupExtender2.Show();
    }

    protected void ImgBtnApprovedBy_Click(object sender, ImageClickEventArgs e)
    {
        txtSearchFromPopup.Text = "";
        HidPopUpType.Value = "ApprovedBy";
        lPopUpHeader.Text = "Approved By";
        lSearch.Text = "Search By Approved By: ";
        BindEmployee("");
        ModalPopupExtender2.Show();
    }

    protected void ImgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        //added by lalit on 26 April 2013
        if (IsSameStroageLoc(DdlPlantFrom.SelectedValue, DdlPlantTo.SelectedValue, HidStorageLocFromId.Value, HidStorageLocToId.Value))
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material can not be moved in same storage location of same plant.", 125, 300);
            return;
        }
        //end
        if (txtStorageLocationFrom.Text != "")
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Material";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code/Name: ";
            FillAllMaterial("");
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the Storage Location first.", 125, 300);
        }
    }    

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (HidPopUpType.Value != "RequestBy" && HidPopUpType.Value != "ApprovedBy" && HidPopUpType.Value!="BatchNo")
                {
                    e.Row.Cells[1].Style.Add("display", "none");
                }

                if (HidPopUpType.Value == "Material")
                {
                    e.Row.Cells[4].Style.Add("display", "none");
                }
            }
        }
        catch (Exception ex) { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "PlantFrom")
                {
                    HidPlantFromId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    
                    //changed by lalit 19Feb 2013
                    //txtPlantFrom.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text + ")";
                    //end

                    //changed by lalit 20feb 2013
                    DdlPlantFrom.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    //end
                    HidMaterialId.Value = "";
                    HidValuationType.Value = "";
                    TxtMaterialCode.Text = "";
                    DdlValuationType.Items.Clear();
                    TxtBatch.Text = "";
                    TxtQuantity.Text = "";
                    TxtValue.Text = "";
                }
                else if (HidPopUpType.Value == "PlantTo")
                {
                    HidPlantToId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    DdlPlantTo.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    //changed by lalit 19Feb 2013
                    //txtPlantTo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text + ")";
                    //end
                }
                else if (HidPopUpType.Value == "StorageLocationFrom")
                {
                    HidStorageLocFromId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtStorageLocationFrom.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    HidMaterialId.Value = "";
                    HidValuationType.Value = "";
                    TxtMaterialCode.Text = "";
                    DdlValuationType.Items.Clear();
                    TxtBatch.Text = "";
                    TxtQuantity.Text = "";
                    TxtValue.Text = "";
                }
                else if (HidPopUpType.Value == "StorageLocationTo")
                {
                    HidStorageLocToId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtStorageLocationTo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                }
                else if (HidPopUpType.Value == "RequestBy")
                {
                    //changed by lalit 19Feb 2013
                    TxtRequestedBy.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    HidRequestByCode.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    //end
                }
                else if (HidPopUpType.Value == "ApprovedBy")
                {
                    //changed by lalit 19Feb 2013
                    TxtApprovedBy.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    HidApprovedByCode.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    //end
                }
                else if (HidPopUpType.Value == "Material")
                {
                    HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    LblMaterialName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    HidValuationType.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text;
                    FillAllValuationTypeMaster();
                    //added by lalit 20Feb 2013
                    fillAlterUnit(int.Parse(HidMaterialId.Value), gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text, gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text);
                    //end
                    TxtAvailablestock.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocFromId.Value, DdlValuationType.SelectedValue, DdlPlantFrom.SelectedValue).ToString();
                    DataTable dt = new DataTable();
                    if (HidMaterialId.Value != "" && HidStorageLocFromId.Value != "" && DdlPlantFrom.SelectedValue != "")
                    {
//                        string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
//                     From Proc_GoodsReceipt_OtherDetails_Trans as G inner join  Proc_GoodsReceipt_DetailsLineItems_Trans as P 
//                     on G.GRItemsId = P.POLineItemNo where P.MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
//                     where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocFromId.Value + ") And Plant = " + HidPlantFromId.Value + "";

                        string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocFromId.Value + ") And Plant = " + DdlPlantFrom.SelectedValue + "";

                        dt = com.executeSqlQry(sql);

                        if (dt.Rows.Count > 0)
                        {
                            TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                        }
                        else
                        {
                            TxtBatch.Text = "";
                        }
                    }
                    else
                    {
                        TxtBatch.Text = "";
                    }
                    //added by lalit 9march 2013
                    if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                    {
                        ImgBathcode.Visible = false;
                    }
                    else
                    {
                        ImgBathcode.Visible = true;
                    }
                    //end
                }
                else if (HidPopUpType.Value == "BatchNo")
                {
                    TxtBatch.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
            }
        }
        catch (Exception ex) { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvPopUpGrid.PageIndex = e.NewPageIndex;

        if (HidPopUpType.Value == "PlantFrom" || HidPopUpType.Value == "PlantTo")
        {
            FillAllPlantMaster(txtSearchFromPopup.Text.Trim());
        }
        else if (HidPopUpType.Value == "StorageLocationFrom")
        {
           //BindStorageLocation(txtSearchFromPopup.Text.Trim(), HidPlantFromId.Value);
            BindStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlantFrom.SelectedValue);
        }
        else if (HidPopUpType.Value == "StorageLocationTo")
        {
            //BindToStorageLocation(txtSearchFromPopup.Text.Trim(), HidPlantToId.Value);
            BindToStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlantTo.SelectedValue);
        }
        else if (HidPopUpType.Value == "RequestBy" || HidPopUpType.Value == "ApprovedBy")
        {
            BindEmployee(txtSearchFromPopup.Text.Trim());
        }
        else if (HidPopUpType.Value == "Material")
        {
            FillAllMaterial(txtSearchFromPopup.Text.Trim());
        }
        else if (HidPopUpType.Value == "BatchNo")
        {
            BindBatch("", DdlPlantFrom.SelectedValue, HidStorageLocFromId.Value, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
        }


        txtSearchFromPopup.Focus();
        ModalPopupExtender2.Show();
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        if (HidPopUpType.Value == "PlantFrom" || HidPopUpType.Value == "PlantTo")
        {
            FillAllPlantMaster(txtSearchFromPopup.Text.Trim());
        }
        else if (HidPopUpType.Value == "StorageLocationFrom")
        {
            BindStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlantFrom.SelectedValue);
        }
        else if (HidPopUpType.Value == "StorageLocationTo")
        {
            BindToStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlantTo.SelectedValue);
        }
        else if (HidPopUpType.Value == "RequestBy" || HidPopUpType.Value == "ApprovedBy")
        {
            BindEmployee(txtSearchFromPopup.Text.Trim());
        }
        else if (HidPopUpType.Value == "Material")
        {
            FillAllMaterial(txtSearchFromPopup.Text.Trim());
        }
        txtSearchFromPopup.Focus();
        ModalPopupExtender2.Show();
    }

    protected void TxtQuantity_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (Hidstockflag.Value != "")
            {
                if (hidTransferId.Value != "")
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(TxtAvailablestock.Text) + com.STRToDBL(HidQuantity.Value)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                        return;
                    }
                }
                else
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(TxtAvailablestock.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                        return;
                    }
                }

            }
            else 
            {

                if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(TxtAvailablestock.Text)))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                    return;
                }

                //added by lalit 5march 2013
                DataTable dt =(DataTable)ViewState["LineItem"];
                double Quantity = 0.00, AddedQuantity = 0.00;
                if(dt!=null && dt.Rows.Count>0)
                {
                foreach (DataRow row in dt.Select("MaterialCode=" + TxtMaterialCode.Text + " AND Plant=" + DdlPlantFrom.SelectedValue + " AND StorageLocation=" + HidStorageLocFromId.Value)) 
                {
                    Quantity = com.STRToDBL(row["Quantity"].ToString());
                    AddedQuantity = Quantity + AddedQuantity;
                }
                }
                if (!IsQuantityValid(com.STRToDBL(TxtAvailablestock.Text), com.STRToDBL(TxtQuantity.Text), AddedQuantity))
                 {
                     MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                     return;
                 }
               }
              //end
            if (TxtQuantity.Text != "" && HidMaterialId.Value != "" && DdlPlantFrom.SelectedValue != "" && DdlValuationType.Items.Count > 0)
            {
//                DataTable dt = new DataTable();
//                string sql = @"Select ValuatedQuantity, ValuatedValue from Proc_MasterValuationStk Where 
//                              MaterialCode = '" + TxtMaterialCode.Text.Trim () + "' And AFlag = 1 And Plant = '" + DdlPlantFrom.SelectedValue + "' And ValuationType = '" + DdlValuationType.SelectedValue + "'";
//                dt = com.executeSqlQry(sql);
//                if (dt.Rows.Count > 0)
//                {
//                    double Value = Convert.ToDouble(dt.Rows[0]["ValuatedValue"]) / Convert.ToDouble(dt.Rows[0]["ValuatedQuantity"]);
//                    TxtValue.Text = Convert.ToString(Math.Round(Value * Convert.ToDouble(TxtQuantity.Text.Trim()), 2));
//                }
//                dt = null;
                //added by lalit 9march 2013
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string Query = @"select dbo.mm_get_valuated_wa_price( '" + TxtMaterialCode.Text + "','" + DdlPlantFrom.SelectedValue + "','" + DdlValuationType.SelectedValue + "','" + TxtTransferDate.Text + "') as MaterialRate";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(Query);
                if (dtValStk.Rows.Count > 0)
                {
                    MaterialRate = Convert.ToDouble(dtValStk.Rows[0]["MaterialRate"].ToString());
                }
                MaterialValue = Math.Round((Convert.ToDouble(TxtQuantity.Text.Trim()) * MaterialRate), 2);
                TxtValue.Text = Convert.ToString(MaterialValue); 
                //end
            }
        }
        catch (Exception ex) { }
    }
    
    protected void gvStorageLocationMovement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                //changed by lalit 19Feb 2013
                //e.Row.Cells[0].Style.Add("display", "none");
                if (hidTransferId.Value != "")
                {
                    e.Row.Cells[9].Style.Add("display", "none");
                }
                //end
                e.Row.Cells[10].Style.Add("display", "none");
                e.Row.Cells[11].Style.Add("display", "none");
            }
        }
        catch (Exception ex) { }
    }

    protected void gvStorageLocationMovement_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItem"];
            DataTable dtForDelete = (DataTable)ViewState["ForDelete"];
            DataRow drForDelete = dtForDelete.NewRow();
            drForDelete["AutoId"] = dtLineItem.Rows[e.RowIndex]["AutoId"].ToString();
            dtForDelete.Rows.Add(drForDelete);
            dtForDelete.AcceptChanges();
            ViewState["ForDelete"] = dtForDelete;
            
            int PreviousLineNo = Convert.ToInt32(dtLineItem.Rows[e.RowIndex]["LineNo"]);
            int PreviousLineItemId = Convert.ToInt32(dtLineItem.Rows[e.RowIndex]["AutoId"]);
            dtLineItem.Rows[e.RowIndex].Delete();
            if (PreviousLineItemId == 0)
            {
                HidLineNo.Value = Convert.ToString(PreviousLineNo);
            }
            else
            {
                int TotalRows = dtLineItem.Rows.Count;
                try
                {
                    HidLineNo.Value = (Convert.ToInt32(dtLineItem.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
                }
                catch (Exception ex) { }
            }
            dtLineItem.AcceptChanges();
            ViewState["LineItem"] = dtLineItem;

            gvStorageLocationMovement.DataSource = (DataTable)ViewState["LineItem"];
            gvStorageLocationMovement.DataBind();
        }
        catch (Exception ex) { }
    }    

    protected void gvStorageLocationMovement_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridView gvLineItems = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvLineItems.SelectedIndex = row.RowIndex + 1;

            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvLineItems.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (objdtLineItem.Rows.Count > 0)
                {
                    if (hidTransferId.Value != "")
                    {
                        Hidstockflag.Value = "1";
                    }
                    else
                    {
                        Hidstockflag.Value = "0";
                    }
                    hidRowIndex.Value = Convert.ToString(row.RowIndex);
                    hidLineItemId.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["AutoId"].ToString();
                    HidUpdateGridRecord.Value = "Yes";
                    HidLineNo.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["LineNo"].ToString();

                    TxtMaterialCode.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["MaterialCode"].ToString();
                    LblMaterialName.Text = GetMaterialName(TxtMaterialCode.Text);

                    fillAlterUnit(com.STRToInt(GetMaterialId(TxtMaterialCode.Text.Trim())), "", "");
                    com.SetDropDownValues(DdlUOM, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["UOM"].ToString());
                    HidMaterialId.Value = GetMaterialId(TxtMaterialCode.Text);
                    FillAllValuationTypeMaster();
                    com.SetDropDownValues(DdlValuationType, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationType"].ToString());
                    TxtBatch.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["BatchNo"].ToString();
                    TxtQuantity.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();

                    //added by lalit 5march 2013
                    HidQuantity.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();
                    //end
                    TxtValue.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Value"].ToString();
                    //added by lalit 4march 2013
                    TxtAvailablestock.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocFromId.Value, DdlValuationType.SelectedValue, DdlPlantFrom.SelectedValue).ToString();
                    //end
                }
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void DdlPlantFrom_SelectedIndexChanged(object sender, EventArgs e)
    {
        HidPlantFromId.Value = DdlPlantFrom.SelectedValue;
    }
    //added by lalit 4march 2013
    protected void ImgBathcode_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNo";
            lPopUpHeader.Text = "Batch";
            lSearch.Text = "Search By BatchNo.: ";
            BindBatch("", DdlPlantFrom.SelectedValue, HidStorageLocFromId.Value, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
            ModalPopupExtender2.Show();
        }
        catch (Exception ex) { }
    }

    protected void btnAddLine_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (IsNotBatchIndicator(TxtMaterialCode.Text) && TxtBatch.Text=="")
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info,"Please enter BatchNo.", 125, 300);
                return;
            }
            //added by lalit 4march 2013
            if (Hidstockflag.Value != "")
            {
                if ((com.STRToDBL(TxtAvailablestock.Text) + com.STRToDBL(HidQuantity.Value)) < com.STRToDBL(TxtQuantity.Text))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                    return;
                }
            }
          
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (HidUpdateGridRecord.Value == "") //For Insert new record
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdrLineItem["MaterialCode"] = TxtMaterialCode.Text.Trim();

                objdrLineItem["UOM"] = DdlUOM.SelectedValue;
                objdrLineItem["UOMName"] = DdlUOM.SelectedItem.Text;


                objdrLineItem["ValuationType"] = DdlValuationType.SelectedValue;
                objdrLineItem["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                objdrLineItem["Plant"] = DdlPlantTo.SelectedValue;
                objdrLineItem["StorageLocation"] = HidStorageLocFromId.Value;
                if (TxtQuantity.Text != "")
                {
                    objdrLineItem["Quantity"] = Convert.ToDouble(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdrLineItem["Quantity"] = 0;
                }
                objdrLineItem["BatchNo"] = TxtBatch.Text.Trim();
                if (TxtValue.Text != "")
                {
                    objdrLineItem["Value"] = Convert.ToDouble(TxtValue.Text.Trim());
                }
                else
                {
                    objdrLineItem["Value"] = 0;
                }
                objdrLineItem["IsUpdated"] = "No";
                objdtLineItem.Rows.Add(objdrLineItem);
            }
            else if (HidUpdateGridRecord.Value == "Yes") //For Update record
            {
                if (hidLineItemId.Value != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = com.STRToNum(hidLineItemId.Value);
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = 0;
                }

               
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["MaterialCode"] = TxtMaterialCode.Text.Trim();

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOM"] = DdlUOM.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOMName"] = DdlUOM.SelectedItem.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationType"] = DdlValuationType.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Plant"] = DdlPlantTo.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["StorageLocation"] = HidStorageLocFromId.Value;

                if (TxtQuantity.Text != "")
                {

                  objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = com.STRToDBL(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = 0;
                }
                //added by lalit 5march 2013
                if (HidQuantity.Value != TxtQuantity.Text)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["IsUpdated"] = "Yes";
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["IsUpdated"] = "No";
                }
                //end

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["BatchNo"] = TxtBatch.Text.Trim();
                if (TxtValue.Text != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = com.STRToDBL(TxtValue.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = 0;
                }
               
                objdtLineItem.AcceptChanges();
            }
            ViewState["LineItem"] = objdtLineItem;
            int LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[0]["LineNo"].ToString());
            for (int i = 1; i < objdtLineItem.Rows.Count; i++)
            {
                if (Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                {
                    LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString());
                }
            }
            HidLineNo.Value = (LineNoInGrid + 10).ToString();
            gvStorageLocationMovement.DataSource = objdtLineItem;
            gvStorageLocationMovement.DataBind();
            ClearLineItems();
            Hidstockflag.Value = "";
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.ErrorToLineItem, 125, 300);
        }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            #region Line Item Records

            DataTable dt = new DataTable();
            dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.AddLineItem, 125, 300);
                return;
            }

            #region MonthClosed for Storage Location**************************************************************
            //Added by satish on 30 may-13
            //This will help to check for month closed for material in storage location or not.

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string StorageLocationCode = "";
                string query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dt.Rows[0]["StorageLocation"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dt.Rows[i]["Plant"].ToString();
                    string VoucherDate = TxtTransferDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + dt.Rows[i]["LineNo"] + " for the selected storage location.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }

            #endregion***********************************************************************************            

            //added by lalit 9March 2013
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double totalQuantity = 0.0;
                string TotalStockQty = "0";
                DataTable dtvalue = new DataTable();
                string sql1 = @"select ValuatedQuantity from Proc_MasterValuationStk where MaterialCode='" + dt.Rows[i]["MaterialCode"].ToString() + "' and";
                sql1 += " Plant ='" + dt.Rows[i]["Plant"].ToString() + "' and ValuationType ='" + dt.Rows[i]["ValuationType"].ToString() + "' and";
                sql1 += " StorageLocationID ='" + dt.Rows[i]["StorageLocation"].ToString() + "'";

                dtvalue = com.executeSqlQry(sql1);
                if (dtvalue.Rows.Count > 0)
                {
                    TotalStockQty = dtvalue.Rows[0]["ValuatedQuantity"].ToString();
                }
                dtvalue = null;

                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    if ((dt.Rows[i]["MaterialCode"].ToString() == dt.Rows[j]["MaterialCode"].ToString()) &&
                        (dt.Rows[i]["Plant"].ToString() == dt.Rows[j]["Plant"].ToString()) &&
                        (dt.Rows[i]["ValuationType"].ToString() == dt.Rows[j]["ValuationType"].ToString()) &&
                        (dt.Rows[i]["StorageLocation"].ToString() == dt.Rows[j]["StorageLocation"].ToString()))
                    {
                        totalQuantity = totalQuantity + Convert.ToDouble(dt.Rows[j]["Quantity"].ToString());
                    }
                }
                if (totalQuantity > com.STRToDBL(TotalStockQty))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Total Stock quantity of material code: " + dt.Rows[i]["MaterialCode"].ToString() + " is:" + TotalStockQty + ". You have total entered:" + totalQuantity + ". Please reduce the quantity for this material.", 155, 300);
                    return;
                }
            }
            //end

            //DataTable dtForDelete = new DataTable();
            //dtForDelete = (DataTable)ViewState["ForDelete"];
            #endregion

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region Insert Header Records

            if (hidTransferId.Value == "")
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = Convert.ToInt32(hidTransferId.Value);
            }
            cmd.Parameters.Add("@TransferNoExist", SqlDbType.VarChar).Value = TxtTransferNo.Text.Trim();
            
            //Added by satish on 13 jun-13
            if (TxtTransferDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DateTime.ParseExact(TxtTransferDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(TxtTransferDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DBNull.Value;
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }            
            cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = "SLM";
            //-----------------------------------

            cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = TxtYear.Text.Trim();
            cmd.Parameters.Add("@PlantFrom", SqlDbType.VarChar).Value = DdlPlantFrom.SelectedValue;
            cmd.Parameters.Add("@PlantTo", SqlDbType.VarChar).Value = DdlPlantTo.SelectedValue;
            cmd.Parameters.Add("@FromStorageLocation", SqlDbType.VarChar).Value = HidStorageLocFromId.Value;
            cmd.Parameters.Add("@ToStorageLocation", SqlDbType.VarChar).Value = HidStorageLocToId.Value;
            cmd.Parameters.Add("@RequestedBy", SqlDbType.VarChar).Value = HidRequestByCode.Value;
            cmd.Parameters.Add("@ApprovedBy", SqlDbType.VarChar).Value = HidApprovedByCode.Value;

            cmd.Parameters.Add("@ActiveStatus", SqlDbType.Bit).Value = true;
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());

            #region Table Parameter

            cmd.Parameters.AddWithValue("@dtLineitems", dt);
            //cmd.Parameters.AddWithValue("@dtLineitemsForDelete", dtForDelete);

            #endregion

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewTransferNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewTransferNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Proc_Glb_StorageLocationMovement";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewTransferNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Transfer No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();
                ClearLineItems();
                gvStorageLocationMovement.DataSource = "";
                gvStorageLocationMovement.DataBind();
                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
                return;
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch (Exception ex) { }
    }

    #endregion

    #region*******************************************Functions****************************************************

    protected void BindSearchList()
    {
        try
        {
            DataTable dt = new DataTable();
            string FormIdProcStorageLocation = ConfigurationManager.AppSettings["FormIdProcStorageLocation"].ToString();

            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            dt = objCommon_mst.Get_SearchCriteria(FormIdProcStorageLocation);

            ddlSearch.DataTextField = "Options";
            ddlSearch.DataValueField = "Value";
            ddlSearch.DataSource = dt;
            if (dt.Rows.Count > 0)
            {
                ddlSearch.DataBind();
            }
        }
        catch (Exception ex) { }
    }

    protected void FillFinancialYear()
    {
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    TxtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    TxtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch (Exception ex) { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "SLM" + financialYear + inv_series.ToString().PadLeft(5, '0');
        }
        catch (Exception ex)
        {

        }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        int piseries = 1;
        try
        {

            string sql = "select  MAX([Series]) from Proc_Glb_StorageLocationMovement_Header where [Year]='" + fin_yr + "' and Type ='SLM'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch (Exception ex)
        {

        }

        return piseries;
    }

    protected void ResetCombo(DropDownList ddList)
    {
        try
        {
            if (ddList.Items.Count <= 0)
            {
                //do nothing
            }
            else if (ddList.Items.Count > 0)
            {
                ddList.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
        }

    }

    protected void BindUOM()
    {
        try
        {
            DataTable dt = com.executeProcedure("SP_Prod_GetUOM_mst");
            DdlUOM.DataSource = dt;
            DdlUOM.DataTextField = "Description";
            DdlUOM.DataValueField = "AutoId";
            DdlUOM.DataBind();
            ResetCombo(DdlUOM);
        }
        catch (Exception ex) { }
    }

    private void FillAllPlantMaster(string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            dt = objCommon_mst.FillAllPlantMaster(Searchtext);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                //added by lalit 19Feb 2013
                if (dt.Columns.Contains("PLANTCODE"))
                {
                    dt.Columns["PLANTCODE"].ColumnName = "Plant Code";

                }
                if (dt.Columns.Contains("PLANTNAME"))
                {
                    dt.Columns["PLANTNAME"].ColumnName = "Plant Name";
                }
                //end
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void BindStorageLocation(string Searchtext, string Plant)
    {
        try
        {
            DataTable dt = new DataTable();
            //string sql = @"Select distinct S.autoid,StorageLocCode, (StorageLocCode+' ('+Location+')') as StorageLocationName from Prod_StorageLocation_Mst as S inner 
            //join Proc_MaterialMst3 as P on S.autoid = P.StorageLocation COLLATE SQL_Latin1_General_CP1_CI_AS and P.Plant =" + Plant + "";
            //changed by lalit 19Feb 2013
            string sql = @" Select distinct S.autoid,StorageLocCode as [Storage Location Code], (StorageLocCode+' ('+Location+')')
                            as [Storage Location Name] from Prod_StorageLocation_Mst as S inner 
                            join Proc_MasterValuationStk as P on S.autoid = P.StorageLocationID  and P.Plant='" + Plant + "' and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void BindToStorageLocation(string Searchtext, string Plant)
    {
        try
        {
            DataTable dt = new DataTable();
            //string sql = @"Select distinct S.autoid,StorageLocCode, (StorageLocCode+' ('+Location+')') as StorageLocationName from Prod_StorageLocation_Mst as S inner 
            //join Proc_MaterialMst3 as P on S.autoid = P.StorageLocation COLLATE SQL_Latin1_General_CP1_CI_AS and P.Plant =" + Plant + "";
            //changed by lalit 19Feb 2013
            string sql = @" Select distinct S.autoid,StorageLocCode as [Storage Location Code], (StorageLocCode+' ('+Location+')')
                            as [Storage Location Name] from Prod_StorageLocation_Mst as S Where
                            PlantId =" + Plant + " and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void BindEmployee(string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            dt = com.GetVal("@search", Searchtext, "SP_Prod_GetEmployeemster_mst");

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void FillAllMaterial(string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            //            string sql = @"select distinct P.AutoId,P.MaterialCode,P.MaterialDesc from Proc_MaterialMaster as P inner join Proc_MaterialMst3 as M on
            //                          P.AutoId = M.MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS where M.StorageLocation ='" + HidStorageLocFromId.Value + "' and (P.MaterialCode like '%" + Searchtext + "%' or P.MaterialDesc like '%" + Searchtext + "%')";
            //changed by lalit 19Feb 2013
            string sql = @"select distinct P.AutoId,P.MaterialCode as [Material Code],P.MaterialDesc as [Description],UOMId
	                      ,(select Description from Proc_UOM_Master where AutoId =P.UOMId) as UOM
                           from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                          P.AutoId = M.MaterialCodeID where M.StorageLocationID ='" + HidStorageLocFromId.Value + "' and (P.MaterialCode like '%" + Searchtext + "%' or P.MaterialDesc like '%" + Searchtext + "%')";
            //end
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private string GetMaterialId(string matericalcode)
    {
        string str = @"select distinct P.AutoId from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                       P.AutoId = M.MaterialCodeID where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["AutoId"].ToString();
        }
        return "0.0";
    }

    private string GetMaterialName(string matericalcode)
    {
        string str = @"select MaterialDesc from Proc_MaterialMaster as P where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["MaterialDesc"].ToString();
        }
        return "";
    }

    private void FillAllValuationTypeMaster()
    {
        try
        {
            DataTable dt = new DataTable();
            //changed by LJ 19Feb2013
            string sql = @"Select distinct V.AutoId, V.ValuationType from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
                           on V.AutoId =P.ValuationType where P.MaterialCodeID ='" + HidMaterialId.Value + "' and aflag=1";
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                DdlValuationType.DataTextField = "ValuationType";
                DdlValuationType.DataValueField = "AutoId";
                DdlValuationType.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    DdlValuationType.DataBind();
                }
                ResetCombo(DdlValuationType);
            }
            else
            {
                DdlValuationType.Items.Clear();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void ClearHeader()
    {
        try
        {
            hidTransferId.Value = "";
            FillFinancialYear();
            TxtTransferDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            TxtTransferNo.Text = AutogenerateNo(TxtYear.Text);
            //txtPlantFrom.Text = "";
            // txtPlantTo.Text = "";
            txtStorageLocationFrom.Text = "";
            txtStorageLocationTo.Text = "";
            TxtRequestedBy.Text = "";
            TxtApprovedBy.Text = "";

            // imgPlantFrom.Enabled = true;
            // imgBtnPlantTo.Enabled = true;
            imgBtnStorageLocationFrom.Enabled = true;
            imgBtnStorageLocationTo.Enabled = true;
            ImgBtnRequestedBy.Enabled = true;
            ImgBtnApprovedBy.Enabled = true;
            //added by lalit 19Feb 2013
            HidRequestByCode.Value = "";
            HidApprovedByCode.Value = "";
            //end
            //added by lalit 20Feb 2013
            DdlPlantFrom.SelectedValue = "";
            DdlPlantTo.SelectedValue = "";
            //end
        }
        catch (Exception ex) { }
    }

    private void ClearLineItems()
    {
        try
        {
            TxtMaterialCode.Text = "";
            //DdlUOM.SelectedIndex = 0;
            DdlValuationType.Items.Clear();
            TxtBatch.Text = "";
            TxtQuantity.Text = "";
            TxtValue.Text = "";
            HidUpdateGridRecord.Value = "";
            //added by lalit 20feb 2013
            LblMaterialName.Text = "";
            DdlUOM.Items.Clear();
            TxtAvailablestock.Text = "";
            //end
        }
        catch (Exception ex) { }
    }

    protected void GetProc_Glb_StorageLocationMovement_Details_Trans(string TransferNo)
    {
        try
        {
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement_Details_Trans";
            objSqlCommand.Parameters.AddWithValue("@TransferNo", TransferNo);

            SqlDataProvider db = new SqlDataProvider();
            DataTable dt = new DataTable();
            dt = db.GetDataTableWithProc(objSqlCommand);

            if (dt.Rows.Count > 0)
            {
                int TotalRows = dt.Rows.Count;
                HidLineNo.Value = (Convert.ToInt32(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
            }
            else
            {
                HidLineNo.Value = "10";
            }
            ViewState["LineItem"] = dt;
            gvStorageLocationMovement.DataSource = dt;
            gvStorageLocationMovement.DataBind();
            dt = null;

            string sql = "select AutoId from [Proc_Glb_StorageLocationMovement_Details_Trans] where AutoId=0";
            dt = com.executeSqlQry(sql);
            ViewState["ForDelete"] = dt;
            dt = null;
        }
        catch (Exception ex) { }
    }

    public DataTable Get_AllStorageLocationMovement(string SearchType, string SearchText)
    {
        SqlCommand objSqlCommand = new SqlCommand();
        objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement";
        objSqlCommand.Parameters.AddWithValue("@SearchType", SearchType);
        objSqlCommand.Parameters.AddWithValue("@SearchText", SearchText);
        objSqlCommand.Parameters.AddWithValue("@Type", "SLM");

        SqlDataProvider db = new SqlDataProvider();
        return db.GetDataTableWithProc(objSqlCommand);
    }

    private void BindHeaderAndGridRecords(string TransferId)
    {
        try
        {
            DataTable dt = new DataTable();
            dt = Get_Proc_Glb_StorageLocationMovement_Header_ById(TransferId);
            if (dt.Rows.Count > 0)
            {
                TxtTransferNo.Text = dt.Rows[0]["TransferNo"].ToString();
                TxtYear.Text = dt.Rows[0]["Year"].ToString();
                TxtTransferDate.Text = dt.Rows[0]["TransferDate"].ToString();
                HidPlantFromId.Value = dt.Rows[0]["PlantFrom"].ToString();
                //changed by lalit 20Feb 2013
                DdlPlantFrom.SelectedValue = dt.Rows[0]["PlantFrom"].ToString();
                // txtPlantFrom.Text = dt.Rows[0]["PlantFromDesc"].ToString();
                HidPlantToId.Value = dt.Rows[0]["PlantTo"].ToString();
                DdlPlantTo.SelectedValue = dt.Rows[0]["PlantTo"].ToString();
                // txtPlantTo.Text = dt.Rows[0]["PlantToDesc"].ToString();
                //end
                HidStorageLocFromId.Value = dt.Rows[0]["FromStorageLocation"].ToString();
                //added by LJ 19Feb 2013
                txtStorageLocationFrom.Text = dt.Rows[0]["FromStorageDesc"].ToString();
                HidStorageLocToId.Value = dt.Rows[0]["ToStorageLocation"].ToString();
                txtStorageLocationTo.Text = dt.Rows[0]["ToStorageDesc"].ToString();
                HidRequestByCode.Value = dt.Rows[0]["RequestedBy"].ToString();
                HidApprovedByCode.Value = dt.Rows[0]["ApprovedBy"].ToString();
                TxtRequestedBy.Text = dt.Rows[0]["RequestByDesc"].ToString();
                TxtApprovedBy.Text = dt.Rows[0]["ApprovedByDesc"].ToString();
                //end

                //imgPlantFrom.Enabled = false;
                // imgBtnPlantTo.Enabled = false;
                imgBtnStorageLocationFrom.Enabled = false;
                imgBtnStorageLocationTo.Enabled = false;
                ImgBtnRequestedBy.Enabled = false;
                ImgBtnApprovedBy.Enabled = false;

                #region Bind Line Items

                GetProc_Glb_StorageLocationMovement_Details_Trans(TxtTransferNo.Text.Trim());

                #endregion

                dt = null;
            }
        }
        catch (Exception ex) { }
    }

    public DataTable Get_Proc_Glb_StorageLocationMovement_Header_ById(string TransferId)
    {
        SqlCommand objSqlCommand = new SqlCommand();
        objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement_Header_ById";
        objSqlCommand.Parameters.AddWithValue("@TransferId", TransferId);

        SqlDataProvider db = new SqlDataProvider();
        return db.GetDataTableWithProc(objSqlCommand);
    }

    public void BindBatch(string searchtext, string plant, string storagelocation, string valuationtype, string materialcode)
    {
        try
        {
            try
            {
                DataTable dt = new DataTable();
                string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans
                               where Plant='" + plant + "' and StorageLocation='" + GetStorageLocationCodeById(storagelocation) + "' and MaterialCode='"
                                             + materialcode + "' and ValuationType='" + valuationtype
                                             + "' and activestatus=1 and (BatchNo like '%" + searchtext + "%' or BatchNo like '%" + searchtext + "%')";
                dt = com.executeSqlQry(sql);
                if (dt.Rows.Count > 0)
                {
                    lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
                    gvPopUpGrid.AutoGenerateColumns = true;
                    gvPopUpGrid.AllowPaging = true;
                    gvPopUpGrid.DataSource = dt;
                    if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                    {
                        gvPopUpGrid.SetPageIndex(0);
                    }
                    gvPopUpGrid.DataBind();
                }
                else
                {
                    lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                    gvPopUpGrid.AllowPaging = false;
                    gvPopUpGrid.DataSource = "";
                    gvPopUpGrid.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex) { }
    }

    public string GetStorageLocationCodeById(string id)
    {
        try
        {
            string str = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid='" + id + "'";
            DataTable dtstr = com.executeSqlQry(str);
            if (dtstr != null && dtstr.Rows.Count > 0)
            {
                return dtstr.Rows[0]["StorageLocCode"].ToString();
            }
        }
        catch (Exception ex) { }
        return "";
    }

    protected void fillAlterUnit(int matid, string UOMText, string matuomid)
    {
        string sql = @"SELECT distinct A.AutoId, A.Code, A.Description FROM Proc_UOM_Master as A left outer join  Prod_AlterUOM
                       on Prod_AlterUOM.auomid= A.AutoId where Prod_AlterUOM.materialid='" + matid + "' or A.AutoId in(select UOMId from Proc_MaterialMaster where autoid='" + matid + "')";
        DataTable dt = com.executeSqlQry(sql);
        DdlUOM.Items.Clear();
        //removed by lalit 20feb 2013
        // DdlUOM.Items.Add(new ListItem(UOMText, matuomid));
        //end
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                DdlUOM.Items.Add(new ListItem(row["Code"].ToString() + " (" + row["Description"].ToString() + ")", row["AutoId"].ToString()));
            }
        }
        else
        {
            //removed by lalit 20feb 2013
            // DdlUOM.Items.Add(new ListItem(UOMText, matuomid));
            //end
        }
    }

    private bool IsSameStroageLoc(string plantfrom, string plantto, string StorageFrom, string StorageTo)
    {
        if (plantfrom == plantto)
        {
            if (StorageFrom == StorageTo)
            {
                return true;
            }
        }
        return false;
    }

    protected void BindPlant(DropDownList ddl)
    {
        string str = "SELECT autoid,(PLANTCODE+'('+PLANTNAME+')') as [Plant] FROM COM_PLANT_MST WHERE ACTIVESTATUS =1";
        DataTable dt = com.executeSqlQry(str);
        ddl.Items.Add(new ListItem("--Select--", ""));
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                ddl.Items.Add(new ListItem(row["Plant"].ToString(), row["AutoId"].ToString()));
            }
        }

    }

    private bool IsNotBatchIndicator(string materialcode)
    {
        string str = "select BatchIndicator from Proc_MaterialMaster where MaterialCode='" + materialcode + "'";
        bool IsBatchIndicator = false;
        DataTable dtstr = com.executeSqlQry(str);
        if (dtstr != null && dtstr.Rows.Count > 0)
        {
            if (dtstr.Rows[0]["BatchIndicator"].ToString() == "True")
            {
                IsBatchIndicator = true;
            }
        }
        return IsBatchIndicator;
    }

    public bool IsQuantityValid(double availablequantity, double inputquantity, double AddedQuantity)
    {
        //double Quantity = 0.00, AddedQuantity=0.00;
        //foreach (GridViewRow row in gvStorageLocationMovement.Rows)
        //{
        //    Quantity = com.STRToDBL(((Label)row.FindControl("LblQuantity")).Text);
        //    AddedQuantity = Quantity + AddedQuantity;

        //}
        if ((inputquantity + AddedQuantity) > availablequantity)
            return false;
        else return true;
    }

    //added by lalit 22feb 2013
    private double CheckForQuantity_InStock(string materialid, string storagelocationid, string ValTypeId,string plant)
    {
        double TotalQuantityOnStock = 0.0;
        string str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
                        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and ValuationType='" + ValTypeId + "' and Plant='" + plant + "' and Aflag=1";
        DataTable dtquantity = com.executeSqlQry(str);
        if (dtquantity != null && dtquantity.Rows.Count > 0)
        {
            TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
        }
        return TotalQuantityOnStock;
    }
    //end

    #endregion    
    
    protected void DdlValuationType_SelectedIndexChanged(object sender, EventArgs e)
    {
        TxtAvailablestock.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocFromId.Value, DdlValuationType.SelectedValue, DdlPlantFrom.SelectedValue).ToString();
    }
}