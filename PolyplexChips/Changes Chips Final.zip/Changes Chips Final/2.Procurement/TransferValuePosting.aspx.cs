﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region********************************************Variables ************************************************

    string logmessage = "";
    Common_mst objCommon_mst = new Common_mst();
    Common_Message commessage = new Common_Message();
    Proc_TransferValuePosting objtransfervalueposting = new Proc_TransferValuePosting();
    Proc_IssueReservation objProc_IssueReservation = new Proc_IssueReservation();
    Common com = new Common();
    Connection objConnectionClass = new Connection();
    string ErrorStatus, RecordNo;

    

    #endregion

    #region************************************************Events**********************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {               
                BindSearchDropDown("70");

                #region Blank Grid

                gvStorageLocationMovement.DataSource = "";
                gvStorageLocationMovement.DataBind();
                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                #endregion

                TxtTransferDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
               // Log.GetLog().FillFinancialYear(TxtYear);
                TxtYear.Text = com.FillFinancialYear();
                Log.PageHeading(this, "Transfer Value Posting");
                //added by lalit 21feb 2013
                BindPlant(DdlPlant);
                //end
                TxtTransferNo.Text = AutogenerateNo(TxtYear.Text);

                trTypeTnfIn.Attributes.Add("style", "display:block");
                trTypeTnfOut.Attributes.Add("style", "display:none");
                //added by lalit 9march 2013
                txtStockQuantity.Attributes.Add("readonly", "true");
                txtStockQuantity.Attributes.Add("style", "background:lightgray");
                TxtBatch.Attributes.Add("readonly", "true");
                TxtBatch.Attributes.Add("style", "background:lightgray");
                //end
                TxtYear.Attributes.Add("readonly", "true");
                TxtYear.Attributes.Add("style", "background:lightgray");
                TxtTransferNo.Attributes.Add("readonly", "true");
                TxtTransferNo.Attributes.Add("style", "background:lightgray");
                TxtTransferDate.Attributes.Add("readonly", "true");
                TxtTransferDate.Attributes.Add("style", "background:lightgray");

               // txtPlant.Attributes.Add("readonly", "true");
               // txtPlant.Attributes.Add("style", "background:lightgray");
                //txtValuationType.Attributes.Add("readonly", "true");
                //txtValuationType.Attributes.Add("style", "background:lightgray");

                

                //txtUOM.Attributes.Add("readonly", "true");
                //txtUOM.Attributes.Add("style", "background:lightgray");


                //Changed by lalit 30 May 2013
                //TxtStorageLocation.Attributes.Add("readonly", "true");
                //TxtStorageLocation.Attributes.Add("style", "background:lightgray");
                //TxtMaterialCode.Attributes.Add("readonly", "true");
                //TxtMaterialCode.Attributes.Add("style", "background:lightgray");
                //End

                //changed by lalit 21Feb 2013
                // TxtBatch.Attributes.Add("readonly", "true");
                //end

                TxtRequestedBy.Attributes.Add("readonly", "true");
                TxtRequestedBy.Attributes.Add("style", "background:lightgray");

                TxtApprovedBy.Attributes.Add("readonly", "true");
                TxtApprovedBy.Attributes.Add("style", "background:lightgray");

                //changed by lalit 21Feb 2013  User can input value of material.
                //TxtValue.Attributes.Add("readonly", "true");
                //TxtValue.Attributes.Add("style", "background:lightgray");
                // TxtBatch.Attributes.Add("style", "background:lightgray");
                //end
            }

            //Added by lalit 30May 2013
             btnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(btnSave, null) + ";");
            //End
            
            ImageButton btn_add = (ImageButton)Master.FindControl("btnAdd");
            btn_add.Click += new ImageClickEventHandler(btn_add_Click);
            btn_add.CausesValidation = false;

            ImageButton btn_search = (ImageButton)Master.FindControl("imgbtnSearch");
            btn_search.CausesValidation = false;
            btn_search.Click += new ImageClickEventHandler(btn_search_Click);
        }
        catch (Exception ex) { }
    }

    //protected void BindAllPlant()
    //{
    //    DataTable dt = new DataTable();
    //    string sql = @"SELECT C.autoid,(PLANTCODE + ' '+PLANTNAME) as Descr FROM COM_PLANT_MST as C    ";
    //    dt = com.executeSqlQry(sql);

    //    DdlPlant.DataSource = dt;
    //    DdlPlant.DataTextField = "PlantCode";
    //    DdlPlant.DataValueField = "autoid";
    //    DdlPlant.DataBind();
    //    ResetCombo(DdlPlant);
    //}

    private void btn_search_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";
            DataTable dt = new DataTable();
            dt = Get_AllTransferValuePosting(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = commessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch (Exception ex) { }

        
    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        try
        {
            ClearHeader();
            ClearLineItems();
            GetProc_Glb_StorageLocationMovement_Details_Trans("0");
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
            trTypeTnfIn.Attributes.Add("style", "display:block");
            trTypeTnfOut.Attributes.Add("style", "display:none");
            DdlType.Enabled = true;
        }
        catch (Exception ex)
        {
            logmessage = "Transfer value posting Form- btn_add_Click event -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");            
            DataTable dt = new DataTable();
            dt = Get_AllTransferValuePosting(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = commessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
        }
        catch (Exception ex) { }
        ModalPopupExtender1.Show();       
    }        

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            ClearLineItems();
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                HidTransferId.Value = Convert.ToString(e.CommandArgument);    
                BindHeaderAndGridRecords(HidTransferId.Value);
            }
        }
        catch (Exception ex) { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            DataTable dt = new DataTable();
            dt = Get_AllTransferValuePosting(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = commessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch (Exception ex) { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        try
        {
            if (HidPopUpType.Value == "requestedby" || HidPopUpType.Value == "approvedby")
            {
                BindEmployee(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "materialcode")
            {
                BindMaterial(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "storagelocation")
            {
                BindLocation(txtSearchFromPopup.Text.Trim());
            }
            if (HidPopUpType.Value == "ValuationType")
            {
                lSearchList.Text = "Search By Location Code";
                FillAllValuationTypeMaster("0", txtSearchFromPopup.Text.Trim());
            }
            if (HidPopUpType.Value == "Plant")
            {
                lSearchList.Text = "Search By Plant";
                FillAllPlantMaster("0", txtSearchFromPopup.Text.Trim());
            }
            if (HidPopUpType.Value == "storagelocation")
            {
                lSearchList.Text = "Search By Storage Location";
                FillAllStorageLocationByPlant("0", "0",DdlPlant.SelectedValue);
            }
            //added by lalit 2 april 2013
            if (HidPopUpType.Value == "BatchNo")
            {
               BindBatch(txtSearchFromPopup.Text.Trim(), HidPlantId.Value, HidStorageLocationId.Value, HidValuationTypeId.Value, HidMaterialCode.Value);
            }
            //end
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch (Exception ex) { }
    }

    protected void Gdvlookup_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;
            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";
                if (HidPopUpType.Value == "ValuationType")
                {
                    HidValuationTypeId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                   // txtValuationType.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    com.SetDropDownValues(DdlValuationType, gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text);
                }
                if (HidPopUpType.Value == "storagelocation")
                {
                    HidStorageLocationId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    string locationname = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    TxtStorageLocation.Text = locationname;

                    DataTable dt = new DataTable();
                    if (HidMaterialId.Value != "" && HidStorageLocationId.Value != "")
                    {
                        string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocationId.Value + ") And Plant = " + DdlPlant.SelectedValue + "";

                        dt = com.executeSqlQry(sql);

                        if (dt.Rows.Count > 0)
                        {
                            TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                        }
                        else
                        {
                            TxtBatch.Text = "";
                        }

                        //lPopUpHeader.Text = "Batch List";
                        //HidPopUpType.Value = "BatchNo";
                        //txtSearchFromPopup.Text = "";
                        //lSearchList.Text = "Search By BatchNo.: ";
                        //if (dt.Rows.Count > 0)
                        //{
                        //    lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                        //    Gdvlookup.AutoGenerateColumns = true;
                        //    Gdvlookup.AllowPaging = true;
                        //    Gdvlookup.DataSource = dt;
                        //    if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                        //    {
                        //        Gdvlookup.SetPageIndex(0);
                        //    }
                        //    Gdvlookup.DataBind();
                        //}
                        //else
                        //{
                        //    lblTotalRecordsPopUp.Text = commessage.TotalRecord + "";
                        //    Gdvlookup.AllowPaging = false;
                        //    Gdvlookup.DataSource = "";
                        //    Gdvlookup.DataBind();
                        //}
                        //ModalPopupExtender2.Show();
                    }
                    else
                    {
                        TxtBatch.Text = "";
                    }
                    //added by lalit 2 April 2013
                    txtStockQuantity.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocationId.Value, HidPlantId.Value, HidValuationTypeId.Value).ToString();
                    if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                    {
                        ImgBathcode.Visible = false;
                    }
                    else
                    {
                        ImgBathcode.Visible = true;
                    }
                    //end
                }
                if (HidPopUpType.Value == "requestedby")
                {
                    TxtRequestedBy.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    HidRequestBy.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    if (TxtRequestedBy.Text.Trim() == TxtApprovedBy.Text.Trim())
                    {
                        TxtRequestedBy.Text = "";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Request by cannot be same as approved by.", 125, 300);
                        return;
                    }                    
                }
                if (HidPopUpType.Value == "approvedby")
                {
                    HidApprovedBy.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtApprovedBy.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text + "(" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    if (TxtApprovedBy.Text.Trim() == TxtRequestedBy.Text.Trim())
                    {
                        TxtApprovedBy.Text = "";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Approved by cannot be same as request by.", 125, 300);
                        return;
                    }
                }
                if (HidPopUpType.Value == "materialcode")
                {
                    //HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    //TxtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    
                    //DdlUOM.Items.Clear();
                    //DdlUOM.Items.Insert(0,new ListItem(gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text,gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text));                    

                    //DdlValuationType.Items.Clear();
                    //DdlPlant.Items.Clear();
                    //HidStorageLocationId.Value = "";
                    //TxtStorageLocation.Text = "";
                    //TxtBatch.Text = "";
                    //TxtQuantity.Text = "";
                    //TxtValue.Text = "";

                    //BindPlant();
                    //BindValuation();                    
                    HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtMaterialCode.Text = HidMaterialCode.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    //TxtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text + " (" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    LblMaterialName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    string sMaterialCode = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    DataTable dtPlant = objProc_IssueReservation.GetPlantFromValuationStock(sMaterialCode);
                    if (dtPlant.Rows.Count > 0)
                    {
                        //txtPlant.Text = dtPlant.Rows[0]["PLANTNAME"].ToString() + " (" + dtPlant.Rows[0]["PLANTCODE"].ToString() + ")";
                        //added by lalit 21Feb 2013
                        DdlPlant.SelectedValue = dtPlant.Rows[0]["autoid"].ToString();
                        //end
                        HidPlantId.Value = dtPlant.Rows[0]["autoid"].ToString();
                        HidMaterialCode.Value = sMaterialCode;
                        //txtStockQuantity.Text = dtPlant.Rows[0]["ValuatedQuantity"].ToString();
                      
                        DataTable dtStorageLocationID = objProc_IssueReservation.GetStorageLocationValuationStock(dtPlant.Rows[0]["StorageLocationID"].ToString());
                        HidStorageLocationId.Value = dtPlant.Rows[0]["StorageLocationID"].ToString();
                        if (dtStorageLocationID.Rows.Count > 0)
                        {
                            TxtStorageLocation.Text = dtStorageLocationID.Rows[0]["Location"].ToString();
                        }

                        HidValuationTypeId.Value = dtPlant.Rows[0]["ValuationType"].ToString();
                      
                    }

                    DataTable dt = new DataTable();
                    if (HidMaterialId.Value != "" && HidStorageLocationId.Value != "")
                    {
                        string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocationId.Value + ") And Plant = " + DdlPlant.SelectedValue + "";

                        dt = com.executeSqlQry(sql);

                        if (dt.Rows.Count > 0)
                        {
                            TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                        }
                        else
                        {
                            TxtBatch.Text = "";
                        }
                    }
                    else
                    {
                        TxtBatch.Text = "";
                    }

                    //DataTable dtValuation = new DataTable();
                    //string query = "select ValuationType from Proc_ValuationClass_Master where AutoId =" + HidValuationTypeId.Value + "";
                    //dtValuation = com.executeSqlQry(query);
                    //if (dtValuation.Rows.Count > 0)
                    //{
                    //    txtValuationType.Text = dtValuation.Rows[0]["ValuationType"].ToString();
                    //}
                    FillAllValuationTypeMaster();
                    com.SetDropDownValues(DdlValuationType, HidValuationTypeId.Value);
                    //added by lalit 21Feb 2013
                    fillAlterUnit(int.Parse(HidMaterialId.Value), gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text, gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text);
                    //end
//                    if (HidMaterialCode.Value != "" && HidPlantId.Value != "" && HidStorageLocationId.Value != "" && HidValuationTypeId.Value != "")
//                    {
//                        string sql = "";
//                        sql = @"SELECT p.StorageLocationID,p.ValuatedQuantity,ValuationType FROM COM_PLANT_MST as C inner join Proc_MasterValuationStk as P 
//                        on C.AutoId =P.Plant where P.MaterialCode ='" + HidMaterialCode.Value + "' and ValuationType='" + HidValuationTypeId.Value + "' and C.autoid='" + HidPlantId.Value + "' and P.StorageLocationID='" + HidStorageLocationId.Value + "'";

//                        DataTable dtStock = new DataTable();
//                        dtStock = com.executeSqlQry(sql);
//                        if (dtStock.Rows.Count > 0)
//                        {
//                            txtStockQuantity.Text = dtStock.Rows[0]["ValuatedQuantity"].ToString();
//                        }
//                    }
                    
                    HidUOMId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text;
                    //com.SetDropDownValues(DdlUOM, gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text);
                    HidUOMName.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text;
                    //txtUOM.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text;

                    //added by lalit 9march
                    txtStockQuantity.Text = CheckForQuantity_InStock(HidMaterialId.Value,HidStorageLocationId.Value, HidPlantId.Value, HidValuationTypeId.Value).ToString();
                    if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                    {
                        ImgBathcode.Visible = false;
                    }
                    else
                    {
                        ImgBathcode.Visible = true;
                    }
                    //end
                  
                }

                if (HidPopUpType.Value == "Plant")
                {
                    HidPlantId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                   // txtPlant.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text + " (" + gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text + ")";
                    DdlPlant.SelectedValue = HidPlantId.Value;
                    string sql = @"select distinct S.autoid, (StorageLocCode+' ('+Location+')') as StorageLocationName,ValuationType from Prod_StorageLocation_Mst as S inner join COM_PLANT_MST as P
                         on S.PlantId =P.autoid inner join Proc_MasterValuationStk as V on P.AutoId =V.Plant
                         where S.Status=1 and V.MaterialCode ='" + HidMaterialCode.Value + "' and V.Plant ='" + DdlPlant.SelectedValue + "' and (S.StorageLocCode like '%%' or S.Location like '%%')";

                    DataTable dtStorage = new DataTable();
                    dtStorage = com.executeSqlQry(sql);

                    if (dtStorage!=null && dtStorage.Rows.Count > 0)
                    {
                        HidStorageLocationId.Value = dtStorage.Rows[0]["autoid"].ToString();
                        TxtStorageLocation.Text = dtStorage.Rows[0]["StorageLocationName"].ToString();
                        HidValuationTypeId.Value = dtStorage.Rows[0]["ValuationType"].ToString();
                    }
                    //changed by lalit 21feb 2013
                    //DataTable dtValuation = new DataTable();
                    //string query = "select ValuationType from Proc_ValuationClass_Master where AutoId =" + HidValuationTypeId.Value + "";
                    //dtValuation = com.executeSqlQry(query);
                    //if (dtValuation.Rows.Count > 0)
                    //{
                    //    txtValuationType.Text = dtValuation.Rows[0]["ValuationType"].ToString();
                    //}
                    com.SetDropDownValues(DdlValuationType, HidValuationTypeId.Value);
                    //end
//                    if (HidMaterialCode.Value != "" && HidPlantId.Value != "" && HidStorageLocationId.Value != "" && HidValuationTypeId.Value != "")
//                    {
//                        sql = "";
//                        sql = @"SELECT p.StorageLocationID,p.ValuatedQuantity,ValuationType FROM COM_PLANT_MST as C inner join Proc_MasterValuationStk as P 
//                        on C.AutoId =P.Plant where P.MaterialCode ='" + HidMaterialCode.Value + "' and ValuationType='" + HidValuationTypeId.Value + "' and C.autoid='" + HidPlantId.Value + "' and P.StorageLocationID='" + HidStorageLocationId.Value + "'";

//                        DataTable dtStock = new DataTable();
//                        dtStock = com.executeSqlQry(sql);
//                        if (dtStock.Rows.Count > 0)
//                        {
//                            txtStockQuantity.Text = dtStock.Rows[0]["ValuatedQuantity"].ToString();
//                        }
//                    }
//                    txtBatch.Text = "";
//                    txtQuantity.Text = "0";
                }
                if (HidPopUpType.Value == "BatchNo")
                {
                    string batchcode = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtBatch.Text = batchcode;
                }
            }
        }
        catch (Exception ex)
        {
            logmessage = "Transfer ValuePosting Form-Gdvlookup_RowCommand-Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }
    //added by lalit 21Feb 2013
    private void FillAllValuationTypeMaster()
    {
        try
        {
            DataTable dt = new DataTable();
            string sql = "";
            //changed by LJ 22Feb2013
            if (DdlType.SelectedValue == "TO")
            {
               sql = @"Select distinct V.AutoId, V.ValuationType from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
                           on V.AutoId =P.ValuationType where V.Status=1 and P.MaterialCodeID ='" + HidMaterialId.Value + "'";
            }
            else
            {
                sql = @"select AutoId,ValuationType from Proc_ValuationClass_Master as V where MaterialType in
                        (select Type from Proc_MaterialMaster where AutoId='" + HidMaterialId.Value + "') and V.Status=1";
            }
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                DdlValuationType.DataTextField = "ValuationType";
                DdlValuationType.DataValueField = "AutoId";
                DdlValuationType.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    DdlValuationType.DataBind();
                }
                ResetCombo(DdlValuationType);
            }
            else
            {
                DdlValuationType.Items.Clear();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
    }
    //end
    protected void Gdvlookup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                //changed by lalit 9march 2013
                if (HidPopUpType.Value != "requestedby" && HidPopUpType.Value != "approvedby" && HidPopUpType.Value != "BatchNo")
                {
                    e.Row.Cells[1].Style.Add("display", "none");
                }
                //end
                if (HidPopUpType.Value == "materialcode")
                {
                    e.Row.Cells[4].Style.Add("display", "none");
                }
            }
        }
        catch (Exception ex) { }
    }

    protected void Gdvlookup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            Gdvlookup.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "requestedby")
            {
                lSearchList.Text = "Search By Requested By";
                BindEmployee("");
            }
            if (HidPopUpType.Value == "approvedby")
            {
                lSearchList.Text = "Search By Approved By";
                BindEmployee("");
            }
            if (HidPopUpType.Value == "materialcode")
            {
                lSearchList.Text = "Search By Material Code";
                if (DdlType.SelectedValue == "TI")
                {
                    BindMaterial("");
                }
                else
                {
                    FillAllMaterial("");
                }
             }
            if (HidPopUpType.Value == "storagelocation")
            {
                lSearchList.Text = "Search By Location Code";
                BindLocation("");
            }
            if (HidPopUpType.Value == "ValuationType")
            {
                lSearchList.Text = "Search By Valuation Type Code";
                FillAllValuationTypeMaster("0", "");
            }
            if (HidPopUpType.Value == "Plant")
            {
                lSearchList.Text = "Search By Plant";
                FillAllPlantMaster("0", "");
            }
            if (HidPopUpType.Value == "storagelocation")
            {
                lSearchList.Text = "Search By Storage Location";
                FillAllStorageLocationByPlant("0", "0", DdlPlant.SelectedValue);
            }
            ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
            logmessage = "Transfer value posting Form- Gdvlookup_PageIndexChanging -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }

    protected void gvStorageLocationMovement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                //  e.Row.Cells[0].Style.Add("display", "none");
                //  e.Row.Cells[10].Style.Add("display", "none");
                e.Row.Cells[14].Style.Add("display", "none");
                e.Row.Cells[15].Style.Add("display", "none");

                //Added,Commented and modified by satish on 30 Apr-13
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField HidLineItemAutoId = (HiddenField)e.Row.FindControl("HidLineItemAutoId");
                    //if (HidTransferId.Value != "")
                    if (HidLineItemAutoId.Value != "0")
                    {
                        Control ctrl = e.Row.FindControl("ibtnDelete");
                        if (ctrl != null)
                        {
                            ImageButton img = (ImageButton)ctrl;
                            img.Visible = false;
                        }
                    }
                }
            }
        }
        catch (Exception ex) { }
    }

    protected void gvStorageLocationMovement_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItem"];
            DataTable dtForDelete = (DataTable)ViewState["ForDelete"];
            DataRow drForDelete = dtForDelete.NewRow();
            drForDelete["AutoId"] = dtLineItem.Rows[e.RowIndex]["AutoId"].ToString();
            dtForDelete.Rows.Add(drForDelete);
            dtForDelete.AcceptChanges();
            ViewState["ForDelete"] = dtForDelete;

            int PreviousLineNo = Convert.ToInt32(dtLineItem.Rows[e.RowIndex]["LineNo"]);
            int PreviousLineItemId = Convert.ToInt32(dtLineItem.Rows[e.RowIndex]["AutoId"]);
            dtLineItem.Rows[e.RowIndex].Delete();
            if (PreviousLineItemId == 0)
            {
                HidLineNo.Value = Convert.ToString(PreviousLineNo);
            }
            else
            {
                int TotalRows = dtLineItem.Rows.Count;
                try
                {
                    HidLineNo.Value = (Convert.ToInt32(dtLineItem.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
                }
                catch (Exception ex) { }
            }
            dtLineItem.AcceptChanges();
            ViewState["LineItem"] = dtLineItem;

            gvStorageLocationMovement.DataSource = (DataTable)ViewState["LineItem"];
            gvStorageLocationMovement.DataBind();
        }
        catch (Exception ex) { }
    }

    protected void ImgBtnRequestedBy_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            txtSearchFromPopup.Text = "";
            lPopUpHeader.Text = "Requested By";
            lSearchList.Text = "Search By Requested By";            
            HidPopUpType.Value = "requestedby";            
            BindEmployee("");
            ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
            logmessage = "Transfer value posting Form- ImgBtnRequestedBy_Click -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }

    protected void ImgBtnApprovedBy_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            lPopUpHeader.Text = "Approved By";
            lSearchList.Text = "Search By Approved By";
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "approvedby";
            
            BindEmployee("");
            ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
            logmessage = "Transfer value posting Form- ImgBtnApprovedBy_Click -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }
    //added by lalit 21Feb. UOM was changed from Text to Dropdown by Ajit
    protected void fillAlterUnit(int matid, string UOMText, string matuomid)
    {
        string sql = @"SELECT distinct A.AutoId, A.Code, A.Description FROM Proc_UOM_Master as A left outer join  Prod_AlterUOM
                       on Prod_AlterUOM.auomid= A.AutoId where Prod_AlterUOM.materialid='" + matid + "' or A.AutoId in(select UOMId from Proc_MaterialMaster where autoid='"+ matid +"')";
        DataTable dt = com.executeSqlQry(sql);
        DdlUOM.Items.Clear();
        //removed by lalit 20feb 2013
        // DdlUOM.Items.Add(new ListItem(UOMText, matuomid));
        //end
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                DdlUOM.Items.Add(new ListItem(row["Code"].ToString() + " (" + row["Description"].ToString() + ")", row["AutoId"].ToString()));
            }
        }
    }
    //end
    protected void ImgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        MaterialLookup();
    }

    protected void MaterialLookup()
    {
        try
        {
            HidMaterialId.Value = "";
            HidMaterialCode.Value = "";
            HidUOMId.Value = "";
            HidUOMName.Value = "";
            HidValuationTypeId.Value = "";
            HidPlantId.Value = "";
            HidStorageLocationId.Value = "";

            ClearLineItems();
            lPopUpHeader.Text = "Material Code";
            lSearchList.Text = "Search By Material Code";
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "materialcode";
            if (DdlType.SelectedValue == "TI")
            {
                BindMaterial("");
            }
            else
            {
                FillAllMaterial("");
            }
            ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
            logmessage = "Transfer value posting Form- ImgBtnMaterialCode_Click -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }


    private void FillAllMaterial(string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            //changed by lalit 19Feb 2013
            string sql = @"select distinct P.AutoId,P.MaterialCode as [Material Code],P.MaterialDesc as [Description],UOMId
	                      ,(select Description from Proc_UOM_Master where AutoId =P.UOMId) as UOM
                           from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                          P.AutoId = M.MaterialCodeID where P.Status=1 and (P.MaterialCode like '%" + Searchtext + "%' or P.MaterialDesc like '%" + Searchtext + "%')";
            //end
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                Gdvlookup.DataSource = dt;
                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
    }
    protected void ImgbtnStorageLocation_Click(object sender, ImageClickEventArgs e)
    {
        StorageLocLookup();
    }

    protected void StorageLocLookup()
    {
        if (DdlPlant.SelectedValue != "")
        {
            HidStorageLocationId.Value = "";
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "storagelocation";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Code/Location: ";
            FillAllStorageLocationByPlant("0", "0", DdlPlant.SelectedValue);
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the plant first.", 125, 300);
        }
    }



    private void FillAllStorageLocationByPlant(string materialcode,string Searchtext, string PlantId)
    {
        try
        {
            DataTable dt = new DataTable();
            string sql = "";
            //changed by Lalit 20Feb 2013
            if (materialcode == "0" && PlantId == "")
            {
                sql = @"select distinct S.autoid, (StorageLocCode+' ('+Location+')') as [Storage Location Name] from Prod_StorageLocation_Mst as S 
                        where (S.StorageLocCode like '%" + Searchtext + "%' or S.Location like '%" + Searchtext + "%') and Status=1";
            }
            if (materialcode == "0" && PlantId != "")
            {
                sql = @"select distinct S.autoid, (StorageLocCode+' ('+Location+')') as [Storage Location Name] from Prod_StorageLocation_Mst as S 
                        where (S.StorageLocCode like '%" + Searchtext + "%' or S.Location like '%" + Searchtext + "%') and Status=1 and s.PlantId='"+ PlantId +"'";
            }
            else
            {
                sql = @"select distinct S.autoid, (StorageLocCode+' ('+Location+')') as [Storage Location Name] from Prod_StorageLocation_Mst as S inner join COM_PLANT_MST as P
                         on S.PlantId =P.autoid inner join Proc_MasterValuationStk as V on P.AutoId =V.Plant
                         where S.Status=1 and V.MaterialCode ='" + materialcode + "' and V.Plant ='" + DdlPlant.SelectedValue + "' and (S.StorageLocCode like '%" + Searchtext + "%' or S.Location like '%" + Searchtext + "%')";
            }
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                
                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                Gdvlookup.DataSource = dt;

                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
    }
    protected void DdlPlant_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            TxtStorageLocation.Text = "";
            BindLocation("");

            DataTable dt = new DataTable();
            if (HidMaterialId.Value != "" && HidStorageLocationId.Value != "")
            {
                string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                     From Proc_GoodsReceipt_OtherDetails_Trans as G inner join  Proc_GoodsReceipt_DetailsLineItems_Trans as P 
                     on G.GRItemsId = P.POLineItemNo where P.MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                     where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocationId.Value + ") And Plant = " + DdlPlant.SelectedValue + "";
                dt = com.executeSqlQry(sql);

                if (dt.Rows.Count > 0)
                {
                    TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                }
                else
                {
                    TxtBatch.Text = "";
                }
            }
            else
            {
                TxtBatch.Text = "";
            }
        }
        catch (Exception ex) { }
    }

    protected void TxtQuantity_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (DdlType.SelectedValue == "TO")
            {
                if (CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocationId.Value, DdlPlant.SelectedValue) < com.STRToDBL(TxtQuantity.Text))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Enter Quantity less then available quantity in stock.", 125, 300);
                    return;
                }
                if (HidTransferId.Value == "")
                {
                    if (txtStockQuantity.Text != "" && txtStockQuantity.Text != "0")
                    {
                        if (Convert.ToDouble(TxtQuantity.Text.Trim()) > Convert.ToDouble(txtStockQuantity.Text))
                        {
                            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than stock quantity.", 125, 300);
                            TxtQuantity.Text = "0.00";
                            return;
                        }
                    }
                }
                else
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtStockQuantity.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                        return;
                    }
                }
            }
            if (TxtQuantity.Text != "")
            {
                //                DataTable dt = new DataTable();
                //                string sql = @"Select ValuatedQuantity, ValuatedValue from Proc_MasterValuationStk Where 
                //                              MaterialCode = '" + HidMaterialCode.Value + "' And AFlag = 1 And Plant = '" + DdlPlant.SelectedValue + "' And ValuationType = '" + HidValuationTypeId.Value + "'";
                //                dt = com.executeSqlQry(sql);
                //                if (dt.Rows.Count > 0)
                //                {
                //                    double Value = Convert.ToDouble(dt.Rows[0]["ValuatedValue"]) / Convert.ToDouble(dt.Rows[0]["ValuatedQuantity"]);
                //                    TxtValue.Text = Convert.ToString(Math.Round(Value * Convert.ToDouble(TxtQuantity.Text.Trim()), 2));
                //                }
                //                dt = null;

                //added by lalit 9march 2013
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string Query = @"select dbo.mm_get_valuated_wa_price( '" + HidMaterialCode.Value + "','" + DdlPlant.SelectedValue + "','" + HidValuationTypeId.Value + "','" + TxtTransferDate.Text + "') as MaterialRate";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(Query);
                if (dtValStk.Rows.Count > 0)
                {
                    MaterialRate = Convert.ToDouble(dtValStk.Rows[0]["MaterialRate"].ToString());
                }
                
                MaterialValue = Math.Round((Convert.ToDouble(TxtQuantity.Text.Trim()) * MaterialRate), 2);               
                TxtValue.Text = Convert.ToString(MaterialValue);
                //end
            }
        }
        catch (Exception ex) { }
    }
    //added by lalit 22feb 2013
    private double CheckForQuantity_InStock(string materialid, string storagelocationid,string plant)
    {
        double TotalQuantityOnStock = 0.0;
        string str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
                        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and Plant='" + plant + "'";
        DataTable dtquantity = com.executeSqlQry(str);
        if (dtquantity != null && dtquantity.Rows.Count > 0)
        {
            TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
        }
        return TotalQuantityOnStock;
    }
    //end
    //Added by lalit 21Feb 2013
    private bool IsNotBatchIndicator(string materialcode)
    {
        string str = "select BatchIndicator from Proc_MaterialMaster where MaterialCode='" + materialcode + "'";
        bool IsBatchIndicator = false;
        DataTable dtstr = com.executeSqlQry(str);
        if (dtstr != null && dtstr.Rows.Count > 0)
        {
            if (dtstr.Rows[0]["BatchIndicator"].ToString() == "True")
            {
                IsBatchIndicator = true;
            }
        }
        return IsBatchIndicator;
    }

    private string GetMaterialName(string matericalcode)
    {
        string str = @"select MaterialDesc from Proc_MaterialMaster as P where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["MaterialDesc"].ToString();
        }
        return "";
    }
    protected void BindPlant(DropDownList ddl)
    {
        string str = "SELECT autoid,(PLANTCODE+'('+PLANTNAME+')') as [Plant] FROM COM_PLANT_MST WHERE ACTIVESTATUS =1";
        DataTable dt = com.executeSqlQry(str);
        ddl.Items.Add(new ListItem("--Select--", ""));
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                ddl.Items.Add(new ListItem(row["Plant"].ToString(), row["AutoId"].ToString()));
            }
        }
    }
    //end

    //function to check if Monthclose or not
    protected bool IsMonthclose(string SLoc)
    {
        try
        {
            string str = @"Select * from Prod_StorageLocation_Mst where StorageLocCode=(Select StorageLocCode from Prod_StorageLocation_Mst where autoid='"+ SLoc 
                            +"') and fromdate<'" + TxtTransferDate.Text + "' and ToDate>'" + TxtTransferDate.Text + "'";
            DataTable dt = com.executeSqlQry(str);
            if (dt != null && dt.Rows.Count > 0)
            {
                return false;
            }
            return true;
        }
        catch (Exception ex) { };
        return true;
    }
    //end



    protected void btnAddLine_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
          
            //if (IsMonthclose(HidStorageLocationId.Value))
            //{
            //    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Month is closed.", 125, 300);
            //    return;
            //}
         if (DdlType.SelectedValue == "TO")
            {
                if (HidTransferId.Value == "")
                {
                    //if (txtStockQuantity.Text != "" && txtStockQuantity.Text != "0")  //commented by lalit
                    //{
                        if (Convert.ToDouble(TxtQuantity.Text.Trim()) > Convert.ToDouble(txtStockQuantity.Text))
                        {
                            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than stock quantity.", 125, 300);
                            TxtQuantity.Text = "0.00";
                            return;
                        }
                   // }
                }
                else
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtStockQuantity.Text) + com.STRToDBL(HidQuantity.Value)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this quantity.", 125, 300);
                        return;
                    }
                }
            }


            if (IsNotBatchIndicator(TxtMaterialCode.Text) && TxtBatch.Text == "")
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Please enter BatchNo.", 125, 300);
                return;
            }

            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (HidUpdateGridRecord.Value == "") //For Insert new record
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdrLineItem["MaterialCode"] = HidMaterialCode.Value;

                objdrLineItem["UOM"] = DdlUOM.SelectedValue;
                objdrLineItem["UOMName"] = DdlUOM.SelectedItem.Text;

                //changed by Lalit 21Feb UOM will come in Dropdown according to Ajit
                //objdrLineItem["UOM"] = HidUOMId.Value;
                //objdrLineItem["UOMName"] = txtUOM.Text;
                //end

                objdrLineItem["ValuationType"] = DdlValuationType.SelectedValue;
                objdrLineItem["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                //objdrLineItem["ValuationType"] = HidValuationTypeId.Value;
                //objdrLineItem["ValuationTypeName"] = txtValuationType.Text;

                objdrLineItem["Plant"] = DdlPlant.SelectedValue;
                objdrLineItem["PlantCode"] = DdlPlant.SelectedItem.Text;

                //objdrLineItem["Plant"] = HidPlantId.Value;
                //objdrLineItem["PlantCode"] =txtPlant.Text;

                objdrLineItem["StorageLocation"] = HidStorageLocationId.Value;
                objdrLineItem["StorageLocationCode"] = TxtStorageLocation.Text.Trim();

                if (TxtQuantity.Text != "")
                {
                    objdrLineItem["Quantity"] = Convert.ToDouble(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdrLineItem["Quantity"] = 0;
                }
                objdrLineItem["BatchNo"] = TxtBatch.Text.Trim();
                if (TxtValue.Text != "")
                {
                    objdrLineItem["Value"] = Convert.ToDouble(TxtValue.Text.Trim());
                }
                else
                {
                    objdrLineItem["Value"] = 0;
                }

                objdtLineItem.Rows.Add(objdrLineItem);
            }
            else if (HidUpdateGridRecord.Value == "Yes") //For Update record
            {
                //commented by lalit 21Feb 2013
                // objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = 0;
                //end
                //added by lalit 21Feb 2013
                if (hidLineItemId.Value != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = com.STRToNum(hidLineItemId.Value);
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = 0;
                }
                //end

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["MaterialCode"] = TxtMaterialCode.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOM"] = DdlUOM.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOMName"] = DdlUOM.SelectedItem.Text;

                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOM"] = HidUOMId.Value;
                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOMName"] = txtUOM.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationType"] = DdlValuationType.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationType"] = HidValuationTypeId.Value;
                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationTypeName"] = txtValuationType.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Plant"] = DdlPlant.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["PlantCode"] = DdlPlant.SelectedItem.Text;

                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Plant"] = HidPlantId.Value;
                //objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["PlantCode"] = txtPlant.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["StorageLocation"] = HidStorageLocationId.Value;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["StorageLocationCode"] = TxtStorageLocation.Text.Trim();

                if (TxtQuantity.Text != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = Convert.ToDouble(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = 0;
                }
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["BatchNo"] = TxtBatch.Text.Trim();
                if (TxtValue.Text != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = Convert.ToDouble(TxtValue.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = 0;
                }

                objdtLineItem.AcceptChanges();
            }
            ViewState["LineItem"] = objdtLineItem;
            int LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[0]["LineNo"].ToString());
            for (int i = 1; i < objdtLineItem.Rows.Count; i++)
            {
                if (Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                {
                    LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString());
                }
            }
            HidLineNo.Value = (LineNoInGrid + 10).ToString();

            gvStorageLocationMovement.DataSource = objdtLineItem;
            gvStorageLocationMovement.DataBind();
            ClearLineItems();

        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.ErrorToLineItem, 125, 300);
        }
    }
    
    //Added by lalit 30 May 2013
    protected string IsMaterialOfProfitCenter(DataTable dtMaterials)
    {
        if (dtMaterials != null && dtMaterials.Rows.Count > 0)
        {
            DataTable dtProfitC;
            for (int k = 0; k < dtMaterials.Rows.Count; k++)
            {
                string str = "Select ProfitCenter from Proc_MaterialMst2 where MaterialCode=(Select AutoId from Proc_MaterialMaster where MaterialCode='" + dtMaterials.Rows[k]["MaterialCode"].ToString() + "')";
                dtProfitC = new DataTable();
                dtProfitC=com.executeSqlQry(str);
                if (dtProfitC != null && dtProfitC.Rows.Count > 0)
                {
                    if (dtProfitC.Rows[0]["ProfitCenter"].ToString() == "0")
                    {
                        return dtMaterials.Rows[k]["MaterialCode"].ToString();
                    }
                }
            }
        }
        return "";
       
    }

    //End
    //Added by lalit 30May 2013
    protected string GetStorageLocCode_ById(string Id)
    {
        try
        {
            string str = "select * from Prod_StorageLocation_Mst where autoid='" + Id + "'";
            DataTable dt = com.executeSqlQry(str);
            if (dt != null && dt.Rows.Count > 0)
            {
                return dt.Rows[0]["StorageLocCode"].ToString();
            }

        }
        catch (Exception ex) { }
        return "";
    }
    //end
    protected void btnSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            #region Line Item Records

            DataTable dt = new DataTable();
            dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.AddLineItem, 125, 300);
                return;
            }

            if (dt.Columns.Contains("IsUpdated"))
            {
                dt.Columns.Remove("IsUpdated");
                dt.AcceptChanges();
            }


            #region Check Transaction event in determination table

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string MaterialType = "", TransactionEvent = ""; ;
                DataTable dt2 = new DataTable();
                string query2=@"select Type from Proc_MaterialMaster where MaterialCode ='"+dt.Rows[i]["MaterialCode"].ToString ()+"'";
                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    MaterialType = dt2.Rows[0]["Type"].ToString();
                }
                dt2 = null;

                if (DdlType.SelectedValue == "TI")
                {
                    if (ddlTypeofTransferIn.SelectedValue == "SCRAP")
                    {
                        TransactionEvent = "TISCR";
                    }
                    else if (ddlTypeofTransferIn.SelectedValue == "Upload")
                    {
                        TransactionEvent = "TIUPD";
                    }
                    else if (ddlTypeofTransferIn.SelectedValue == "PRODUCED")
                    {
                        TransactionEvent = "PROD";
                    }
                }
                else if (DdlType.SelectedValue == "TO")
                {
                    if (ddlTypeofTransferIn.SelectedValue == "TO-SCR")
                    {
                        TransactionEvent = "TOSCR";
                    }
                    else if (ddlTypeofTransferIn.SelectedValue == "TO-WO")
                    {
                        TransactionEvent = "TOWOF";
                    }
                }

                dt2 = new DataTable();
                query2 = "";
                query2 = @"Select top 1 Debit_GLID,Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = '" + MaterialType + "'";
                query2 += " AND ValuationTypeID = '" + dt.Rows[i]["ValuationType"].ToString() + "' AND VendorAccGroupID = 1 AND TransactionEvent = '" + TransactionEvent + "'";
                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    if (dt2.Rows[0]["Debit_GLID"].ToString() == "" || dt2.Rows[0]["Credit_GLID"].ToString() == "")
                    {
                        string msg = @"Either debit GL or credit GL is not defined in Line no: " + dt.Rows[i]["LineNo"] + ".";
                        msg += " Please contact the admin.";

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 130, 340);
                        return;
                    }
                }
                else
                {
                    string msg = @"Either debit GL or credit GL is not defined in Line no: " + dt.Rows[i]["LineNo"] + ".";
                    msg += " Please contact the admin.";

                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 130, 340);
                    return;
                }
                dt2 = null;
            }

            #endregion

            #region MonthClosed for Storage Location**************************************************************
            //Added by satish on 30 may-13
            //This will help to check for month closed for material in storage location or not.

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string StorageLocationCode = "";
                string query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dt.Rows[0]["StorageLocation"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dt.Rows[i]["Plant"].ToString();
                    string VoucherDate = TxtTransferDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + dt.Rows[i]["LineNo"] + " for the selected storage location.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }

            #endregion***********************************************************************************

            //Added by lalit 30 May 2013
            if (IsMaterialOfProfitCenter(dt) != "")
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material Code" + " " + IsMaterialOfProfitCenter(dt) + " " + "is not assigned Profit Center Please Contact Administrator", 175, 350);
                return;
            }
            //end
            
            //added by lalit 9March 2013
            if (DdlType.SelectedValue == "TO")
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    double totalQuantity = 0.0;
                    string TotalStockQty = "0";
                    DataTable dtvalue = new DataTable();
                    string sql1 = @"select ValuatedQuantity from Proc_MasterValuationStk where MaterialCode='" + dt.Rows[i]["MaterialCode"].ToString() + "' and";
                    sql1 += " Plant ='" + dt.Rows[i]["Plant"].ToString() + "' and ValuationType ='" + dt.Rows[i]["ValuationType"].ToString() + "' and";
                    sql1 += " StorageLocationID ='" + dt.Rows[i]["StorageLocation"].ToString() + "'";

                    dtvalue = com.executeSqlQry(sql1);
                    if (dtvalue.Rows.Count > 0)
                    {
                        TotalStockQty = dtvalue.Rows[0]["ValuatedQuantity"].ToString();
                    }
                    dtvalue = null;

                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        if ((dt.Rows[i]["MaterialCode"].ToString() == dt.Rows[j]["MaterialCode"].ToString()) &&
                            (dt.Rows[i]["Plant"].ToString() == dt.Rows[j]["Plant"].ToString()) &&
                            (dt.Rows[i]["ValuationType"].ToString() == dt.Rows[j]["ValuationType"].ToString()) &&
                            (dt.Rows[i]["StorageLocation"].ToString() == dt.Rows[j]["StorageLocation"].ToString()))
                        {
                            totalQuantity = totalQuantity + Convert.ToDouble(dt.Rows[j]["Quantity"].ToString());
                        }
                    }
                    if (totalQuantity > com.STRToDBL(TotalStockQty))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Total Stock quantity of material code: " + dt.Rows[i]["MaterialCode"].ToString() + " is:" + TotalStockQty + ". You have total entered:" + totalQuantity + ". Please reduce the quantity for this material.", 155, 300);
                        return;
                    }
                }
            }
            //end
            
            DataTable dtForDelete = new DataTable();
            dtForDelete = (DataTable)ViewState["ForDelete"];

            #endregion

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region Insert Header Records

            if (HidTransferId.Value == "")
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = Convert.ToInt32(HidTransferId.Value);
            }
            cmd.Parameters.Add("@TransferNoExist", SqlDbType.VarChar).Value = TxtTransferNo.Text.Trim();
            if (TxtTransferDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DateTime.ParseExact(TxtTransferDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = TxtYear.Text.Trim();
            cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = DdlType.SelectedValue;
            cmd.Parameters.Add("@RequestedBy", SqlDbType.VarChar).Value = HidRequestBy.Value;
            cmd.Parameters.Add("@ApprovedBy", SqlDbType.VarChar).Value = HidApprovedBy.Value;

            if (DdlType.SelectedValue == "TI")
            {
                cmd.Parameters.Add("@TypeofTransferIn", SqlDbType.VarChar).Value = ddlTypeofTransferIn.SelectedValue;                
            }
            else
            {
                cmd.Parameters.Add("@TypeofTransferIn", SqlDbType.VarChar).Value = "";
            }

            if (DdlType.SelectedValue == "TO")
            {
                cmd.Parameters.Add("@TypeofTransferOut", SqlDbType.VarChar).Value = ddlTypeofTransferOut.SelectedValue;
            }
            else
            {
                cmd.Parameters.Add("@TypeofTransferOut", SqlDbType.VarChar).Value = "";
            }

            cmd.Parameters.Add("@ActiveStatus", SqlDbType.Bit).Value = true;
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());

            #region Table Parameter

            cmd.Parameters.AddWithValue("@dtLineitems", dt);
            //commented by satish cmd.Parameters.AddWithValue("@dtLineitemsForDelete", dtForDelete);

            #endregion

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewTransferNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewTransferNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Proc_Glb_TransferValuePosting";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewTransferNo"].Value.ToString();
               
            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordSaved + ". Transfer No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();
                ClearLineItems();
                gvStorageLocationMovement.DataSource = "";
                gvStorageLocationMovement.DataBind();
                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordNotSaved, 125, 300);
                return;
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch  {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordNotSaved, 125, 300);
            return;
        }
    }

    #endregion

    #region*******************************************Functions****************************************************

    protected void ResetCombo(DropDownList ddList)
    {
        try
        {
            if (ddList.Items.Count <= 0)
            {
                //do nothing
            }
            else if (ddList.Items.Count > 0)
            {
                ddList.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
        }

    }

    private void BindSearchDropDown(string formid)
    {
        try
        {
            DropDownList ddl = (DropDownList)Master.FindControl("ddlSearch");
            DataTable dt = com.fillSearch(formid);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ddl.Items.Add(new ListItem(dt.Rows[i]["Options"].ToString(), dt.Rows[i]["Value"].ToString()));
                }
            }
        }
        catch (Exception ex)
        {
            logmessage = "Transfer Value Posting Form- BindSearchDropDown Method -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }

    protected string AutogenerateNo(string financialYear)
    {
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "TVP" + financialYear + inv_series.ToString().PadLeft(5, '0');
        }
        catch (Exception ex)
        {

        }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        int piseries = 1;
        try
        {

            string sql = "select  MAX([Series]) from Proc_Glb_TransferValuePosting_header where [Year]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch (Exception ex)
        {

        }

        return piseries;
    }

//    protected void BindValuation()
//    {
//        try
//        {           
//            DataTable dt = new DataTable();
//            string sql = @"Select V.AutoId, V.ValuationType from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
//                         on V.AutoId =P.ValuationType where P.MaterialCode ='" + HidMaterialId.Value + "'";
//            dt = com.executeSqlQry(sql);

//            DdlValuationType.DataSource = dt;
//            DdlValuationType.DataTextField = "ValuationType";
//            DdlValuationType.DataValueField = "AutoId";
//            DdlValuationType.DataBind();
//            ResetCombo(DdlValuationType);
//        }
//        catch (Exception ex)
//        {
//            logmessage = "Transfer Value Posting Form-BindValuation-Error-" + ex.ToString();
//            Log.GetLog().LogInformation(logmessage);
//        }
//    }    

//    protected void BindPlant()
//    {
//        try
//        {
//            //DataTable dt = com.executeProcedure("Sp_Get_Proc_Plant_Mst");
//            DataTable dt = new DataTable();
//            string sql = @"SELECT C.autoid,PLANTCODE,PLANTNAME FROM COM_PLANT_MST as C inner join Proc_MasterValuationStk as P on C.AutoId =P.Plant
//                         where P.MaterialCode ='" + HidMaterialId.Value + "'";
//            dt = com.executeSqlQry(sql);

//            DdlPlant.DataSource = dt;
//            DdlPlant.DataTextField = "PlantCode";
//            DdlPlant.DataValueField = "autoid";
//            DdlPlant.DataBind();
//            ResetCombo(DdlPlant);
//        }
//        catch (Exception ex)
//        {
//            logmessage = "Transfer Value Posting Form- BindPlant -Error-" + ex.ToString();
//            Log.GetLog().LogInformation(logmessage);
//        }
//    }

    private void BindEmployee(string searchwhat)
    {
        try
        {
            DataTable dtemployee = new DataTable();
            dtemployee = com.GetVal("@search", searchwhat, "SP_Prod_GetEmployeemster_mst");
            lblTotalRecordsPopUp.Text = commessage.TotalRecord + dtemployee.Rows.Count.ToString();
            Gdvlookup.DataSource = dtemployee;
            Gdvlookup.DataBind();
        }
        catch (Exception ex)
        {
            logmessage = "Transfer Value Posting Form- BindEmployee -Error-" + ex.ToString();
            Log.GetLog().LogInformation(logmessage);
        }
    }

    private void BindMaterial(string searchwhat)
    {
        try
        {
            DataTable dt = new DataTable();
            dt = objCommon_mst.FillAllMaterialMaster(searchwhat);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                //Added by Lalit 20Feb 2013
                if (dt.Columns.Contains("MaterialCode"))
                {
                    dt.Columns["MaterialCode"].ColumnName = "Material Code";
                }
                if (dt.Columns.Contains("MaterialDesc"))
                {
                    dt.Columns["MaterialDesc"].ColumnName = "Material Description";
                }
                //end

                Gdvlookup.DataSource = dt;

                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }       
    }        

    private void BindLocation(string searchwhat)
    {
        try
        {
            DataTable dt = new DataTable();
            string sql = @"Select distinct S.autoid, (StorageLocCode+' ('+Location+')') as StorageLocationName from Prod_StorageLocation_Mst as S inner 
                             join Proc_MaterialMst3 as P on S.StorageLocCode  = P.StorageLocation COLLATE SQL_Latin1_General_CP1_CI_AS and P.Plant =" + DdlPlant.SelectedValue + " and (S.StorageLocCode like '%" + searchwhat + "%' or S.StorageLocCode like '%" + searchwhat + "%')";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                Gdvlookup.DataSource = dt;

                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
        
    }    

    private void ClearHeader()
    {
        try
        {
            HidTransferId.Value = "";
            TxtYear.Text = com.FillFinancialYear();
            TxtTransferDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            TxtTransferNo.Text = AutogenerateNo(TxtYear.Text);
            DdlType.SelectedIndex = 0;
            TxtRequestedBy.Text = "";
            TxtApprovedBy.Text = "";            
            ImgBtnRequestedBy.Enabled = true;
            ImgBtnApprovedBy.Enabled = true;
            ddlTypeofTransferIn.SelectedIndex = 0;
            trTypeTnfIn.Attributes.Add("style", "display:block");
            trTypeTnfOut.Attributes.Add("style", "display:none");
        }
        catch (Exception ex) { }
    }

    private void ClearLineItems()
    {
        try
        {
            //Added by satish on 30 Apr-13
            HidUpdateGridRecord.Value = "";
            //--------------------------------
            HidMaterialId.Value = "";
            TxtMaterialCode.Text = "";
            // txtPlant.Text = "";
            // txtUOM.Text = "";
            //txtValuationType.Text = "";
            HidStorageLocationId.Value = "";
            TxtStorageLocation.Text = "";
            TxtBatch.Text = "";
            TxtQuantity.Text = "";
            TxtValue.Text = "";
            //Added by LJ 21Feb 2013
            LblMaterialName.Text = "";
            DdlPlant.SelectedValue = "";
            DdlUOM.Items.Clear();
            DdlValuationType.Items.Clear();

            //added by lalit 9march 2013
            txtStockQuantity.Text = "";
            btnAddLine.ImageUrl = "~/Images/btnAddLinegreen.png";
            btnAddLine.Enabled = true;
            //end
            //end
            //Added by lalit 30May 2013
            TxtMaterialCode.Enabled = true;
            //end
        }
        catch (Exception ex) { }
    }

    public DataTable Get_AllTransferValuePosting(string SearchType, string SearchText)
    {
        SqlCommand objSqlCommand = new SqlCommand();
        objSqlCommand.CommandText = "Sp_Get_Proc_Glb_TransferValuePosting";
        objSqlCommand.Parameters.AddWithValue("@SearchType", SearchType);
        objSqlCommand.Parameters.AddWithValue("@SearchText", SearchText);

        SqlDataProvider db = new SqlDataProvider();
        return db.GetDataTableWithProc(objSqlCommand);
    }
        
    protected void GetProc_Glb_StorageLocationMovement_Details_Trans(string TransferNo)
    {
        try
        {
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement_Details_Trans";
            objSqlCommand.Parameters.AddWithValue("@TransferNo", TransferNo);

            SqlDataProvider db = new SqlDataProvider();
            DataTable dt = new DataTable();
            dt = db.GetDataTableWithProc(objSqlCommand);

            if (dt.Rows.Count > 0)
            {
                int TotalRows = dt.Rows.Count;
                HidLineNo.Value = (Convert.ToInt32(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
            }
            else
            {
                HidLineNo.Value = "10";
            }
            ViewState["LineItem"] = dt;
            gvStorageLocationMovement.DataSource = dt;
            gvStorageLocationMovement.DataBind();
            dt = null;

            string sql = "select AutoId from [Proc_Glb_StorageLocationMovement_Details_Trans] where AutoId=0";
            dt = com.executeSqlQry(sql);
            ViewState["ForDelete"] = dt;
            dt = null;
        }
        catch (Exception ex) { }
    }

    private void BindHeaderAndGridRecords(string TransferId)
    {
        try
        {
            DataTable dt = new DataTable();
            dt = Get_Proc_Glb_TransferValuePosting_Header_ById(TransferId);
            if (dt.Rows.Count > 0)
            {
                TxtTransferNo.Text = dt.Rows[0]["TransferNo"].ToString();
                TxtYear.Text = dt.Rows[0]["Year"].ToString();
                TxtTransferDate.Text = dt.Rows[0]["TransferDate"].ToString();
                DdlType.SelectedValue = dt.Rows[0]["Type"].ToString();
                //Change by satish on 18 jun-13
                try
                {
                    ddlTypeofTransferIn.SelectedValue = dt.Rows[0]["TypeofTransferIn"].ToString();
                }
                catch { }

                try
                {
                    ddlTypeofTransferOut.SelectedValue = dt.Rows[0]["TypeofTransferOut"].ToString();
                }
                catch { }
                //-----------------------------
                TxtRequestedBy.Text = dt.Rows[0]["RequestedBy"].ToString();
                HidRequestBy.Value = dt.Rows[0]["RequestedBy"].ToString();
                TxtApprovedBy.Text = dt.Rows[0]["ApprovedBy"].ToString();
                HidApprovedBy.Value = dt.Rows[0]["ApprovedBy"].ToString();                

                ImgBtnRequestedBy.Enabled = false;
                ImgBtnApprovedBy.Enabled = false;

                if (DdlType.SelectedValue == "TI")
                {
                    trTypeTnfIn.Attributes.Add("style", "display:block");
                    trTypeTnfOut.Attributes.Add("style", "display:none");
                    
                    //Added by lalit 3 June 2013
                     ddlTypeofTransferIn.SelectedValue = dt.Rows[0]["TypeofTransferIn"].ToString().Trim();
                     DdlType.Enabled = false;
                    //end

                }
                else
                {
                    trTypeTnfIn.Attributes.Add("style", "display:none");
                    trTypeTnfOut.Attributes.Add("style", "display:block");
                }

                #region Bind Line Items

                GetProc_Glb_StorageLocationMovement_Details_Trans(TxtTransferNo.Text.Trim());

                #endregion

                dt = null;
            }
        }
        catch (Exception ex) { }
    }

    public DataTable Get_Proc_Glb_TransferValuePosting_Header_ById(string TransferId)
    {
        //Commented and modified by satish on 18 jun-13
        //SqlCommand objSqlCommand = new SqlCommand();
        //objSqlCommand.CommandText = "Sp_Get_Proc_Glb_TransferValuePosting_Header_ById";
        //objSqlCommand.Parameters.AddWithValue("@TransferId", TransferId);

        //SqlDataProvider db = new SqlDataProvider();
        //return db.GetDataTableWithProc(objSqlCommand);

        
        DataTable dt = new DataTable();
        try
        {
            string query = @"SELECT [AutoId]      
                          ,[TransferNo]
                          ,[Year]
                          ,replace(CONVERT(VARCHAR(11),[TransferDate] ,101),' ','/') AS [TransferDate]      
                          ,[Type]
                          ,[TypeofTransferIn]
                          ,[TypeofTransferOut]
                          ,[RequestedBy]
                          ,[ApprovedBy]      
                      FROM [Proc_Glb_TransferValuePosting_Header] where AutoId ='" + TransferId + "'";
            dt = com.executeSqlQry(query);
        }
        catch { }
        return dt;
    }

    #endregion

    protected void imgBtnValuationType_Click(object sender, ImageClickEventArgs e)
    {
        if (HidMaterialId.Value != "")
        {
            HidValuationTypeId.Value = "";
            HidPlantId.Value = "";
            HidStorageLocationId.Value = "";

            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "ValuationType";
            lPopUpHeader.Text = "Valuation Type Master";
            lSearch.Text = "Search By Valuation Type: ";
            FillAllValuationTypeMaster("0","");
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the material first.", 125, 300);
        }
    }
    private void FillAllValuationTypeMaster(string materialcode,string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            string sql="";
            //changed by Lalit 20Feb 2013
            if (materialcode == "0")
            {

                sql = @"Select V.AutoId, V.ValuationType as [Valuation Type],ValuationTypeDescription as [Valuation Type Description]
                      ,(select Description from Proc_MaterialType_Master where AutoId = V.AutoId) as [Material Type] from Proc_ValuationClass_Master as V
                      where V.ValuationType like '%" + Searchtext + "%' and V.Status=1";
            }
            else
            {
                sql = @" Select distinct V.AutoId, V.ValuationType as [Valuation Type],V.ValuationTypeDescription as [Valuation Type Description]
                         ,(select Description from Proc_MaterialType_Master where AutoId = V.AutoId) as MaterialType as [Material Type]
                          from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
                         on V.AutoId =P.ValuationType where P.MaterialCode ='" + materialcode + "' and V.ValuationType like '%" + Searchtext + "%' and V.Status=1";
            }
            //end

            dt = com.executeSqlQry(sql);
            
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                Gdvlookup.DataSource = dt;

                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
    }  
    protected void imgPlant_Click(object sender, ImageClickEventArgs e)
    {
        if (HidMaterialId.Value != "" || HidMaterialCode.Value != "")
        {
            HidPlantId.Value = "";
            HidStorageLocationId.Value = "";

            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Plant";
            lPopUpHeader.Text = "Plant Master";
            lSearch.Text = "Search By Code/Name: ";
            FillAllPlantMaster("0","");
            ModalPopupExtender2.Show();
        }
        else
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the material first.", 125, 300);
        }
    }
    private void FillAllPlantMaster(string materialcode,string Searchtext)
    {
        try
        {
            DataTable dt = new DataTable();
            string sql="";
            //updated by Lalit 20Feb 2013
            if (materialcode == "0")
            {                           
                sql = @"SELECT autoid,PLANTCODE as [Plant Code],PLANTNAME as [Plant Name] FROM COM_PLANT_MST  where (PLANTCODE like '%" + Searchtext + "%' or PlantName like '%" + Searchtext + "%') and ActiveStatus=1";
               
            }
            else
            {
                sql = @"SELECT C.autoid,PLANTCODE as [Plant Code],PLANTNAME as [Plant Name] FROM COM_PLANT_MST as C inner join Proc_MasterValuationStk as P on C.AutoId =P.Plant
                      where P.MaterialCode ='" + materialcode + "' and (C.PLANTCODE like '%" + Searchtext + "%' or C.PlantName like '%" + Searchtext + "%')";
            }
            //end
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                Gdvlookup.AutoGenerateColumns = true;
                Gdvlookup.AllowPaging = true;
                Gdvlookup.DataSource = dt;
                if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                {
                    Gdvlookup.SetPageIndex(0);
                }
                Gdvlookup.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                Gdvlookup.AllowPaging = false;
                Gdvlookup.DataSource = "";
                Gdvlookup.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            Gdvlookup.AllowPaging = false;
            Gdvlookup.DataSource = "";
            Gdvlookup.DataBind();
        }
    }
    protected void DdlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DdlType.SelectedValue == "TI")
            {
                trTypeTnfIn.Attributes.Add("style", "display:block");
                trTypeTnfOut.Attributes.Add("style", "display:none");
            }
            else
            {
                trTypeTnfIn.Attributes.Add("style", "display:none");
                trTypeTnfOut.Attributes.Add("style", "display:block");
            }
        }
        catch { }
    }

    //Added by lalit 27Feb 2013
    public bool IsMaterialQualityPassChecked(string materialid, string transferno, string plant, string storageloc, string valuationtype)
    {
        bool Materialchecked = false;
        string strquery = @"select TIQualityPass from Proc_Glb_StorageLocationMovement_Details_Trans 
                            where TransferNo='"+ transferno +"' and MaterialCode='"+ materialid 
                            +"' and Plant='"+ plant +"' and StorageLocation='"+ storageloc +"' and ValuationType='"+ valuationtype +"'";
        DataTable dt = com.executeSqlQry(strquery);
        if (dt != null && dt.Rows.Count > 0)
        {
            Materialchecked = Convert.ToBoolean(dt.Rows[0]["TIQualityPass"].ToString());
        }
        return Materialchecked;
    }

    //end




    //Added by lalit 21Feb 2013
    protected void gvStorageLocationMovement_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridView gvLineItems = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvLineItems.SelectedIndex = row.RowIndex + 1;

            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvLineItems.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (objdtLineItem.Rows.Count > 0)
                {
                    hidRowIndex.Value = Convert.ToString(row.RowIndex);
                    hidLineItemId.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["AutoId"].ToString();
                    HidUpdateGridRecord.Value = "Yes";
                    HidLineNo.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["LineNo"].ToString();

                    //Added by lalit 30 May 2013
                    TxtMaterialCode.Enabled = false;
                    //end

                    HidValuationTypeId.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationType"].ToString();
                    HidMaterialCode.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["MaterialCode"].ToString();
                    TxtMaterialCode.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["MaterialCode"].ToString();
                    LblMaterialName.Text = GetMaterialName(TxtMaterialCode.Text);
                    HidMaterialId.Value = GetMaterialId(TxtMaterialCode.Text);
                    //changed by lalit 21 feb 2013
                    // txtUOM.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["UOMName"].ToString();
                    //  txtValuationType.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationTypeName"].ToString();
                    // com.SetDropDownValues(DdlUOM, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["UOM"].ToString());

                    //added by lalit 27Feb 2013
                    string storageloc=objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["StorageLocation"].ToString();
                    string plant=objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Plant"].ToString();
                    string valuationtype=objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationType"].ToString();
                    if (IsMaterialQualityPassChecked(HidMaterialCode.Value, TxtTransferNo.Text.Trim(), plant, storageloc, valuationtype))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material is quality checked. You can not edit.", 125, 300);
                        return;
                    }
                    //end

                    fillAlterUnit(com.STRToInt(GetMaterialId(TxtMaterialCode.Text.Trim())), "", "");
                    com.SetDropDownValues(DdlUOM, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["UOM"].ToString());
                    FillAllValuationTypeMaster();
                    com.SetDropDownValues(DdlValuationType, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationType"].ToString());
                    //end
                   
                    com.SetDropDownValues(DdlPlant, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Plant"].ToString());
                    TxtStorageLocation.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["StorageLocationCode"].ToString();
                    HidStorageLocationId.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["StorageLocation"].ToString();

                    TxtBatch.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["BatchNo"].ToString();
                    TxtQuantity.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();
                    TxtValue.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Value"].ToString();
                    //added by lalit 9march 2013
                    HidQuantity.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();
                    txtStockQuantity.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocationId.Value, plant, DdlValuationType.SelectedValue).ToString();
                    btnAddLine.ImageUrl = "~/Images/btnUpdateLine.png";
                    //end
                    
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    //added by lalit 9march 2013
    private string GetStorageLocId(string locationcode)
    {
        string str = @"select autoid from Prod_StorageLocation_Mst where StorageLocCode='" + locationcode + "'";
        DataTable dtstorageloc = new DataTable();
        dtstorageloc = com.executeSqlQry(str);
        if (dtstorageloc != null && dtstorageloc.Rows.Count > 0)
        {
            return dtstorageloc.Rows[0]["autoid"].ToString();
        }
        return "0.0";
    }
   private double CheckForQuantity_InStock(string materialid, string storagelocationid, string plant, string valuationtype)
    {
        double TotalQuantityOnStock = 0.0;
        string str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and Plant='" + plant + "' and ValuationType='" + valuationtype + "'";
        DataTable dtquantity = com.executeSqlQry(str);
        if (dtquantity != null && dtquantity.Rows.Count > 0)
        {
            TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
        }
        return TotalQuantityOnStock;
    }
   
    //end

    private string GetMaterialId(string matericalcode)
    {
        string str = @"select distinct P.AutoId from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                       P.AutoId = M.MaterialCodeID where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["AutoId"].ToString();
        }
        return "0.0";
    }
    //end
    protected void TxtValue_TextChanged(object sender, EventArgs e)
    {

    }
    //added by lalit 9march 2013
    protected void ImgBathcode_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            HidPopUpType.Value = "BatchNo";
            lSearchList.Text = "Search By BatchNo.: ";
            BindBatch("", HidPlantId.Value, HidStorageLocationId.Value, HidValuationTypeId.Value, HidMaterialCode.Value);
            ModalPopupExtender2.Show();
        }
        catch (Exception ex) { }
    }
    public void BindBatch(string searchtext, string plant, string storagelocation, string valuationtype, string materialcode)
    {
        try
        {
            try
            {
                lPopUpHeader.Text = "Batch List";
                HidPopUpType.Value = "BatchNo";
                txtSearchFromPopup.Text = "";
                lSearchList.Text = "Search By BatchNo.: ";
                DataTable dt = new DataTable();
//                //changed by lalit 2April 2013
//                string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans
//                               where Plant='" + plant 
//                               + "' and StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid ='"
//                               + storagelocation+"') and MaterialCode='"+ materialcode + "' and ValuationType='" + valuationtype
//                               + "' and activestatus=1 and (BatchNo like '%" + searchtext + "%' or BatchNo like '%" + searchtext + "%')";
//                //end
                string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans
                               where Plant='" + plant + "' and StorageLocation='" + storagelocation + "' and MaterialCode='"
                                             + materialcode + "' and ValuationType='" + valuationtype
                                             + "' and activestatus=1 and (BatchNo like '%" + searchtext + "%' or BatchNo like '%" + searchtext + "%')";

                dt = com.executeSqlQry(sql);
                if (dt.Rows.Count > 0)
                {
                    lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                    Gdvlookup.AutoGenerateColumns = true;
                    Gdvlookup.AllowPaging = true;
                    Gdvlookup.DataSource = dt;
                    if (Gdvlookup.PageIndex > (dt.Rows.Count / Gdvlookup.PageSize))
                    {
                        Gdvlookup.SetPageIndex(0);
                    }
                    Gdvlookup.DataBind();
                }
                else
                {
                    lblTotalRecordsPopUp.Text = commessage.TotalRecord + "";
                    Gdvlookup.AllowPaging = false;
                    Gdvlookup.DataSource = "";
                    Gdvlookup.DataBind();
                }
            }
            catch (Exception ex)
            {
            }
        }
        catch (Exception ex) { }
    }
    //end

    //Added by lalit 30 May 2013
    protected void TxtMaterialCode_TextChanged(object sender, EventArgs e)
    {
        //Check if Materialcode exists or not
        string str = "select (select Description from Proc_UOM_Master where AutoId =M.UOMId) as UOM,* from Proc_MaterialMaster as M where MaterialCode='" + TxtMaterialCode.Text + "' and Status=1";
        DataTable dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            HidMaterialId.Value = dtmaterial.Rows[0]["AutoId"].ToString();
            TxtMaterialCode.Text = HidMaterialCode.Value = dtmaterial.Rows[0]["MaterialCode"].ToString();
            LblMaterialName.Text = dtmaterial.Rows[0]["MaterialDesc"].ToString();
            string sMaterialCode = dtmaterial.Rows[0]["MaterialCode"].ToString();
            DataTable dtPlant = objProc_IssueReservation.GetPlantFromValuationStock(sMaterialCode);
            if (dtPlant.Rows.Count > 0)
            {
                //txtPlant.Text = dtPlant.Rows[0]["PLANTNAME"].ToString() + " (" + dtPlant.Rows[0]["PLANTCODE"].ToString() + ")";
                //added by lalit 21Feb 2013
                DdlPlant.SelectedValue = dtPlant.Rows[0]["autoid"].ToString();
                //end
                HidPlantId.Value = dtPlant.Rows[0]["autoid"].ToString();
                HidMaterialCode.Value = sMaterialCode;
                //txtStockQuantity.Text = dtPlant.Rows[0]["ValuatedQuantity"].ToString();

                DataTable dtStorageLocationID = objProc_IssueReservation.GetStorageLocationValuationStock(dtPlant.Rows[0]["StorageLocationID"].ToString());
                HidStorageLocationId.Value = dtPlant.Rows[0]["StorageLocationID"].ToString();
                if (dtStorageLocationID.Rows.Count > 0)
                {
                    TxtStorageLocation.Text = dtStorageLocationID.Rows[0]["Location"].ToString();
                }

                HidValuationTypeId.Value = dtPlant.Rows[0]["ValuationType"].ToString();

            }

            DataTable dt = new DataTable();
            if (HidMaterialId.Value != "" && HidStorageLocationId.Value != "")
            {
                string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocationId.Value + ") And Plant = " + DdlPlant.SelectedValue + "";

                dt = com.executeSqlQry(sql);

                if (dt.Rows.Count > 0)
                {
                    TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                }
                else
                {
                    TxtBatch.Text = "";
                }
            }
            else
            {
                TxtBatch.Text = "";
            }

          
            FillAllValuationTypeMaster();
            com.SetDropDownValues(DdlValuationType, HidValuationTypeId.Value);
            //added by lalit 21Feb 2013
            fillAlterUnit(int.Parse(HidMaterialId.Value), dtmaterial.Rows[0]["UOM"].ToString(), dtmaterial.Rows[0]["UOMId"].ToString());
            HidUOMId.Value = dtmaterial.Rows[0]["UOMId"].ToString();
            HidUOMName.Value = dtmaterial.Rows[0]["UOM"].ToString();
            
            //added by lalit 9march
            txtStockQuantity.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocationId.Value, HidPlantId.Value, HidValuationTypeId.Value).ToString();
            if (!IsNotBatchIndicator(TxtMaterialCode.Text))
            {
                ImgBathcode.Visible = false;
            }
            else
            {
                ImgBathcode.Visible = true;
            }
            //end
        }
        else
        {
            MaterialLookup();
        }
    }
    protected void TxtStorageLocation_TextChanged(object sender, EventArgs e)
    {
        string str = @"select distinct S.autoid, (StorageLocCode+' ('+Location+')') as [Storage Location Name] from Prod_StorageLocation_Mst as S 
                        where S.StorageLocCode='" + TxtStorageLocation.Text + "' and Status=1 and s.PlantId='" + DdlPlant.SelectedValue + "'";

        DataTable dtStorage = com.executeSqlQry(str);
        if (dtStorage != null && dtStorage.Rows.Count > 0)
        {
            HidStorageLocationId.Value = dtStorage.Rows[0]["autoid"].ToString();
            string locationname = dtStorage.Rows[0]["Storage Location Name"].ToString();
            TxtStorageLocation.Text = locationname;
            DataTable dt = new DataTable();
            if (HidMaterialId.Value != "" && HidStorageLocationId.Value != "")
            {
                string sql = @"Select BatchNo,(QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + HidMaterialId.Value + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS from Prod_StorageLocation_Mst where autoid =" + HidStorageLocationId.Value + ") And Plant = " + DdlPlant.SelectedValue + "";

                dt = com.executeSqlQry(sql);

                if (dt.Rows.Count > 0)
                {
                    TxtBatch.Text = dt.Rows[0]["BatchNo"].ToString();
                }
                else
                {
                    TxtBatch.Text = "";
                }

            }
            else
            {
                TxtBatch.Text = "";
            }
            //added by lalit 2 April 2013
            txtStockQuantity.Text = CheckForQuantity_InStock(HidMaterialId.Value, HidStorageLocationId.Value, HidPlantId.Value, HidValuationTypeId.Value).ToString();
            if (!IsNotBatchIndicator(TxtMaterialCode.Text))
            {
                ImgBathcode.Visible = false;
            }
            else
            {
                ImgBathcode.Visible = true;
            }
            //end
        }
        else
        {
            StorageLocLookup();
        }


    }
}