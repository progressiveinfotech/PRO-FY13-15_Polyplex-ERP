﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
              
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================

        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "PTA Analysis";

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();         

                #region Change Color and Readonly Fields

                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                txtYear.Attributes.Add("style", "background:lightgray");
                txtVoucherDate.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");
                txtVendorName.Attributes.Add("style", "background:lightgray");
                txtGRNo.Attributes.Add("style", "background:lightgray");
                txtVendorRefNo.Attributes.Add("style", "background:lightgray");
                txtCarrierRefNo.Attributes.Add("style", "background:lightgray");

                txtVoucherNo.Attributes.Add("readonly", "true");
                txtYear.Attributes.Add("readonly", "true");
                txtVoucherDate.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");
                txtVendorName.Attributes.Add("readonly", "true");
                txtGRNo.Attributes.Add("readonly", "true");
                txtVendorRefNo.Attributes.Add("readonly", "true");
                txtCarrierRefNo.Attributes.Add("readonly", "true");

                #endregion

                txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>
        try
        {
            ClearHeader();

            txtSearchList.Text = "";
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllPTAAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }
    
    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary>
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearHeader();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllPTAAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary> 
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllPTAAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void imgBtnGRNo_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the GR no.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "GRNo";
            lPopUpHeader.Text = "GR List";
            lSearch.Text = "Search By GR No.: ";
            FillAllGRNo("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "GRNo")
                {
                    HidGRNo.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtGRNo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    
                    txtVendorRefNo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    txtVendorName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[4].Text;
                    HidVendorCode.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[5].Text;
                    txtCarrierRefNo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[6].Text;

                    if (txtVendorRefNo.Text == "&nbsp;")
                    {
                        DataTable dt = new DataTable();
                        string query = @"select ContactPersonOne from FA_Glb_VendorMaster_Mst where CAST( VendorId as nvarchar) = '" + HidVendorCode.Value + "'";
                        dt = com.executeSqlQry(query);
                        if (dt.Rows.Count > 0)
                        {
                            txtVendorRefNo.Text = dt.Rows[0]["ContactPersonOne"].ToString();
                        }
                        dt = null;
                    }
                    if (txtCarrierRefNo.Text == "&nbsp;")
                    {
                        txtCarrierRefNo.Text = "";
                    }
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                e.Row.Cells[1].Style.Add("display", "none");
                e.Row.Cells[5].Style.Add("display", "none");
            }
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "GRNo")
            {
                FillAllGRNo(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "GRNo")
            {
                FillAllGRNo(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>

        if (txtRemarks.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Remarks is mandatory.", 125, 300);
            return;
        }

        try
        {
            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();
            if (txtVoucherDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtVoucherDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DBNull.Value;
            }
            
            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }
            
            cmd.Parameters.Add("@GRNumber", SqlDbType.Int).Value = com.STRToInt (HidGRNo.Value);
            cmd.Parameters.Add("@VCode", SqlDbType.VarChar).Value = HidVendorCode.Value;
            cmd.Parameters.Add("@BagLotNo", SqlDbType.VarChar).Value = txtBagLotNo.Text.Trim();
            cmd.Parameters.Add("@CarrierRefNo", SqlDbType.VarChar).Value = txtCarrierRefNo.Text.Trim();
            cmd.Parameters.Add("@Appearance", SqlDbType.VarChar).Value = txtAppearance.Text.Trim();
            cmd.Parameters.Add("@Ash", SqlDbType.Float).Value = com.STRToDBL(txtAsh.Text.Trim());
            cmd.Parameters.Add("@Solubility", SqlDbType.VarChar).Value = txtSolubility.Text.Trim();
            cmd.Parameters.Add("@Alph", SqlDbType.Int).Value = com.STRToInt(txtAlph.Text.Trim());
            cmd.Parameters.Add("@Moisture", SqlDbType.Float).Value = com.STRToDBL(txtMoisture.Text.Trim());
            cmd.Parameters.Add("@Acid", SqlDbType.Int).Value = com.STRToInt(txtAcidNo.Text.Trim());
            cmd.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text.Trim();
            cmd.Parameters.Add("@TruckNo", SqlDbType.VarChar).Value = txtTransportNo.Text.Trim();
            cmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = txtInvoiceNo.Text.Trim();
            cmd.Parameters.Add("@ParticleSize", SqlDbType.Float).Value = com.STRToDBL(txtParticleSize.Text.Trim());

            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@AFlag", SqlDbType.Bit).Value = chkActive.Checked;
                        
            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewVoucherNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewVoucherNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblChtrnPTAAnalysis";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewVoucherNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Document No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Voucher No", "VoucherNo"));
        }
        catch { }
    }    

    protected void FillAllGRNo(string Searchtext)
    {
        /// <summary>
        /// This method is used to get all the GR no.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select A.AutoId ,A.GRNo,B.VendorReference,C.VendorName,C.VendorId,A.VehicleNo from Proc_GoodsReceipt_Header_Trans as A inner join
                          Inv_Glb_POHeader as B on A.POId = B.Autoid inner join FA_Glb_VendorMaster_Mst as C on B.Vendor =C.VendorId 
                          and GRNo like '%" + Searchtext + "%'";
           
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "PTA" + financialYear + inv_series.ToString().PadLeft(5, '0');

        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {
            string sql = @"select  MAX(Series) from tblChtrnPTAAnalysis where [VoucherYear]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }
        return piseries;
    }    

    protected void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

            FillFinancialYear();
            txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            HidGRNo.Value = "";
            txtGRNo.Text = "";
            HidVendorCode.Value = "";
            txtVendorName.Text = "";
            txtVendorRefNo.Text = "";
            txtTransportNo.Text = "";
            txtBagLotNo.Text = "";
            txtCarrierRefNo.Text = "";
            txtAppearance.Text = "";
            txtParticleSize.Text = "0";
            txtInvoiceNo.Text = "";
            txtAsh.Text = "0";
            txtSolubility.Text = "";
            txtAlph.Text = "0";
            txtMoisture.Text = "0";
            txtAcidNo.Text = "0";
            txtRemarks.Text = "";
            chkActive.Checked = true;
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    private void GetAllPTAAnalysisList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the voucher list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]      
                          ,[VoucherYear]
                          ,[VoucherNo]
                          ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
                          ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                          ,(select GRNo from Proc_GoodsReceipt_Header_Trans where AutoId =A.[GRNumber]) as GRNumber      
                      FROM [tblChtrnPTAAnalysis] as A where [VoucherNo] like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    private void BindHeaderRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [VoucherYear]
                              ,[VoucherNo]
                              ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
                              ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                              ,[GRNumber]
                              ,(select GRNo from Proc_GoodsReceipt_Header_Trans where AutoId = A.GRNumber) as GRNo                              
                              ,VCode
                              ,(select VendorName from FA_Glb_VendorMaster_Mst where CAST( VendorId as nvarchar) = A.VCode ) as VendorName
                              ,(select ContactPersonOne from FA_Glb_VendorMaster_Mst where CAST( VendorId as nvarchar) = A.VCode ) as VendorReference
                              ,[BagLotNo]
                              ,[CarrierRefNo]
                              ,[Appearance]
                              ,[Ash]
                              ,[Solubility]
                              ,[Alph]
                              ,[Moisture]
                              ,[Acid]
                              ,[Remarks]
                              ,[TruckNo]
                              ,[ParticleSize]
                              ,[InvoiceNo]
                              ,AFlag
                          FROM [tblChtrnPTAAnalysis] as A where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                txtVoucherDate.Text = dt.Rows[0]["VoucherDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                txtVoucherNo.Text = dt.Rows[0]["VoucherNo"].ToString();

                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();
                HidGRNo.Value  = dt.Rows[0]["GRNumber"].ToString();
                txtGRNo.Text = dt.Rows[0]["GRNo"].ToString();
                HidVendorCode.Value = dt.Rows[0]["VCode"].ToString();
                txtVendorName.Text = dt.Rows[0]["VendorName"].ToString();
                txtVendorRefNo.Text = dt.Rows[0]["VendorReference"].ToString();
                
                txtBagLotNo.Text = dt.Rows[0]["BagLotNo"].ToString();
                txtCarrierRefNo.Text = dt.Rows[0]["CarrierRefNo"].ToString();
                txtAppearance.Text = dt.Rows[0]["Appearance"].ToString();
                txtAsh.Text = dt.Rows[0]["Ash"].ToString();
                txtSolubility.Text = dt.Rows[0]["Solubility"].ToString();
                txtAlph.Text = dt.Rows[0]["Alph"].ToString();
                txtMoisture.Text = dt.Rows[0]["Moisture"].ToString();
                txtAcidNo.Text = dt.Rows[0]["Acid"].ToString();
                txtRemarks.Text = dt.Rows[0]["Remarks"].ToString();
                txtTransportNo.Text = dt.Rows[0]["TruckNo"].ToString();
                txtParticleSize.Text = dt.Rows[0]["ParticleSize"].ToString();
                txtInvoiceNo.Text = dt.Rows[0]["InvoiceNo"].ToString();
                if (dt.Rows[0]["AFlag"].ToString() == "True")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
                dt = null;
            }
        }
        catch { }
    }

    #endregion
    
}