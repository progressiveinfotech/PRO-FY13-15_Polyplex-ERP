﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Data;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst com_mst = new Common_mst();
    Common_Message commessage = new Common_Message();
    Connection objConnectionClass = new Connection();
    string ErrorStatus, RecordNo;
    double totalqty = 0;

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================

        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "Chips Bagging";

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";
                txtVoucherDate.Text = DateTime.Now.ToString(com_mst.DateFormat);
                txtBaggingDate.Text = DateTime.Now.ToString(com_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();

                BindPlant(DdlPlant);
                BindStorageLocationFromDD(ddlStorageLocationFrom);
                BindStorageLocationToDD(ddlStorageLocationTo);

                #region Change Color and Readonly Fields

                txtYear.Attributes.Add("readonly", "true");
                txtVoucherNo.Attributes.Add("readonly", "true");
                txtVoucherDate.Attributes.Add("readonly", "true");
                txtBaggingDate.Attributes.Add("readonly", "true");
                txtMaterialName.Attributes.Add("readonly", "true");
                txtUOM.Attributes.Add("readonly", "true");
                TxtBatch.Attributes.Add("readonly", "true");
                txtTotalQuantity.Attributes.Add("readonly", "true");
                txtTotalValue.Attributes.Add("readonly", "true");
                txtCurrentStock.Attributes.Add("readonly", "true");

                txtYear.Attributes.Add("style", "background:lightgray");
                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                txtVoucherDate.Attributes.Add("style", "background:lightgray");
                txtBaggingDate.Attributes.Add("style", "background:lightgray");
                txtMaterialName.Attributes.Add("style", "background:lightgray");
                txtUOM.Attributes.Add("style", "background:lightgray");
                TxtBatch.Attributes.Add("style", "background:lightgray");
                txtTotalQuantity.Attributes.Add("style", "background:lightgray");
                txtTotalValue.Attributes.Add("style", "background:lightgray");
                txtCurrentStock.Attributes.Add("style", "background:lightgray");

                #endregion

                BindLineItemsRecords("0");
                txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }
        ImgBtnSave.Attributes.Add("onclientclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>

        try
        {
            ClearHeaderItems();
            ClearLineItems();
            BindLineItemsRecords("0");
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllChipsBaggingList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary> 
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearLineItems();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderAndGridRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllChipsBaggingList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllChipsBaggingList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void imgBtnStorageLocationFrom_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the from storage location on behalf of material in popup.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationFrom";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Storage Location: ";
            BindStorageLocation("", DdlPlant.SelectedValue);
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnStorageLocationTo_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the to storage location on behalf of material.
        /// </summary> 
        try
        {
            if (DdlPlant.SelectedValue != "")
            {
                txtSearchFromPopup.Text = "";
                HidPopUpType.Value = "StorageLocationTo";
                lPopUpHeader.Text = "Storage Location";
                lSearch.Text = "Search By Storage Location: ";
                BindToStorageLocation("", DdlPlant.SelectedValue);
                ModalPopupExtender2.Show();
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Select the plant to first.", 125, 300);
            }
        }
        catch { }
    }

    protected void ImgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the materials in popup.
        /// </summary> 
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Material";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code/Name: ";
            FillAllMaterial("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "Plant")
            {
                FillAllPlantMaster(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationFrom")
            {
                BindStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlant.SelectedValue);
            }
            else if (HidPopUpType.Value == "StorageLocationTo")
            {
                BindToStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlant.SelectedValue);
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "StorageLocationFrom")
                {
                    ddlStorageLocationFrom.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    #region Reset the lineitems when storage location is changed.

                    HidMaterialId.Value = "";
                    TxtMaterialCode.Text = "";
                    txtMaterialName.Text = "";
                    HidUOM.Value = "";
                    txtUOM.Text = "";
                    DdlValuationType.Items.Clear();
                    TxtBatch.Text = "0";
                    txtChipsBags.Text = "0";
                    txtQuantityBags.Text = "0";
                    txtTotalQuantity.Text = "0";
                    txtTotalValue.Text = "0";
                    txtCurrentStock.Text = "0";
                    imgBtnBatchCode.Visible = true;

                    BindLineItemsRecords("0");

                    #endregion
                }
                else if (HidPopUpType.Value == "StorageLocationTo")
                {
                    ddlStorageLocationTo.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
                else if (HidPopUpType.Value == "Material")
                {
                    HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    txtMaterialName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    FillAllValuationTypeMaster();

                    BindMaterialInformation(HidMaterialId.Value);

                    txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                        DdlPlant.SelectedValue, DdlValuationType.SelectedValue).ToString();

                    if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                    {
                        imgBtnBatchCode.Visible = false;
                    }
                    else
                    {
                        imgBtnBatchCode.Visible = true;
                    }
                }
                else if (HidPopUpType.Value == "BatchNo")
                {
                    TxtBatch.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
            }
        }
        catch { }
    }

    protected void imgBtnBatchCode_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the batch popup.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNo";
            lPopUpHeader.Text = "Batch";
            lSearch.Text = "Search By BatchNo.: ";
            FillAllBatch("", DdlPlant.SelectedValue, ddlStorageLocationFrom.SelectedValue, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (HidPopUpType.Value != "BatchNo")
                {
                    e.Row.Cells[1].Style.Add("display", "none");
                }

                if (HidPopUpType.Value == "Material")
                {
                    e.Row.Cells[4].Style.Add("display", "none");
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;

            if (HidPopUpType.Value == "StorageLocationFrom")
            {
                BindStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlant.SelectedValue);
            }
            else if (HidPopUpType.Value == "StorageLocationTo")
            {
                BindToStorageLocation(txtSearchFromPopup.Text.Trim(), DdlPlant.SelectedValue);
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNo")
            {
                FillAllBatch("", DdlPlant.SelectedValue, ddlStorageLocationFrom.SelectedValue, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvChipsBagging_RowEditing(object sender, GridViewEditEventArgs e)
    {
        /// <summary>
        /// This event is used for update the line in grid.
        /// </summary>
        try
        {
            gvChipsBagging.EditIndex = e.NewEditIndex;
            gvChipsBagging.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsBagging.DataBind();
        }
        catch { }
    }

    protected void gvChipsBagging_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        /// <summary>
        /// This event is used for cancelling update to line in grid.
        /// </summary>
        try
        {
            gvChipsBagging.EditIndex = -1;
            gvChipsBagging.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsBagging.DataBind();
        }
        catch { }
    }

    protected void gvChipsBagging_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        /// <summary>
        /// This event is used for update the selected line of grid in datatable.
        /// </summary>
        try
        {
            TextBox TxtQuantity = (TextBox)gvChipsBagging.Rows[e.RowIndex].FindControl("TxtQuantity");
            CheckBox chkActive = (CheckBox)gvChipsBagging.Rows[e.RowIndex].FindControl("chkActive");

            int PageNo = gvChipsBagging.PageIndex;
            int noOfRowinPage = gvChipsBagging.PageSize;
            int rowno = (noOfRowinPage * (PageNo)) + e.RowIndex;

            DataTable dt = (DataTable)ViewState["LineItem"];
            dt.Rows[rowno]["Quantity"] = com.STRToDBL(TxtQuantity.Text.Trim());
            if (chkActive.Checked == true)
            {
                dt.Rows[rowno]["Aflag"] = "True";
            }
            else
            {
                dt.Rows[rowno]["Aflag"] = "False";
            }
            dt.AcceptChanges();
            ViewState["LineItem"] = dt;
            gvChipsBagging.EditIndex = -1;
            gvChipsBagging.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsBagging.DataBind();
            CalculateQty();
        }
        catch { }
    }

    protected void gvChipsBagging_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field and put the active status of line in form grid.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (e.Row.RowType != DataControlRowType.Pager)
                {
                    e.Row.Cells[0].Style.Add("display", "none");
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    ImageButton ibtnDelete = (ImageButton)e.Row.FindControl("ibtnDelete");
                    if (e.Row.Cells[0].Text != "0")
                    {
                        ibtnDelete.Visible = false;
                    }
                    HiddenField hidActive = (HiddenField)e.Row.FindControl("hidActive");
                    CheckBox chkActive = (CheckBox)e.Row.FindControl("chkActive");

                    if (hidActive.Value == "True")
                    {
                        chkActive.Checked = true;
                    }
                    else
                    {
                        chkActive.Checked = false;
                    }
                }
            }
        }
        catch { }
    }

    protected void gvChipsBagging_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in form grid.
        /// </summary>
        try
        {
            gvChipsBagging.PageIndex = e.NewPageIndex;
            gvChipsBagging.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsBagging.DataBind();
        }
        catch { }
    }

    protected void txtQuantityBags_TextChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for calculate and putting all the quantity bags in form grid.
        /// </summary>
        try
        {
            if (HidMaterialId.Value == "")
            {
                txtQuantityBags.Text = "0";
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material Code is mandatory.", 125, 300);
                return;
            }
            if (com.STRToIntBig(txtQuantityBags.Text.Trim()) > 9999999999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999999999.99.", 125, 300);
                return;
            }
            //if (ddlStorageLocationFrom.SelectedValue == ddlStorageLocationTo.SelectedValue)
            //{
            //    txtQuantityBags.Text = "0";
            //    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Storage location to cannot be same as Storage location from.", 135, 300);
            //    return;
            //}

            BindLineItemsRecords("0");
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];
            Int64 bagno = 0;
            if (objdtLineItem.Rows.Count == 0)
            {
                bagno = AutoBagNo();
            }
            else
            {
                try
                {
                    DataRow[] objdr = objdtLineItem.Select("BagNo = Max (BagNo)");
                    for (int i = 0; i < objdr.Length; i++)
                    {
                        bagno = com.STRToInt(objdr[i]["BagNo"].ToString()) + 1;
                    }
                }
                catch { }
            }
            int iCount = com.STRToInt(txtChipsBags.Text);
            for (int f = 0; f < iCount; f++)
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = com.STRToInt(HidLineNo.Value);
                objdrLineItem["BagNo"] = bagno;
                objdrLineItem["StorageLocationIssue"] = ddlStorageLocationFrom.SelectedValue;
                objdrLineItem["SLocIssue"] = ddlStorageLocationFrom.SelectedItem.Text.Trim();

                objdrLineItem["MaterialId"] = com.STRToInt(HidMaterialId.Value);
                objdrLineItem["MaterialCode"] = TxtMaterialCode.Text.Trim();
                objdrLineItem["StorageLocationRec"] = ddlStorageLocationTo.SelectedValue;
                objdrLineItem["SLocRecieve"] = ddlStorageLocationTo.SelectedItem.Text.Trim();

                objdrLineItem["BUOM"] = com.STRToInt(HidUOM.Value);
                objdrLineItem["UOM"] = txtUOM.Text.Trim();

                objdrLineItem["ValuationTypeId"] = com.STRToInt(DdlValuationType.SelectedValue);
                objdrLineItem["ValuationType"] = DdlValuationType.SelectedItem.Text;
                objdrLineItem["BatchCode"] = com.STRToIntBig(TxtBatch.Text);
                objdrLineItem["ChipsBags"] = com.STRToDBL(txtChipsBags.Text);
                objdrLineItem["Quantity"] = com.STRToDBL(txtQuantityBags.Text);
                objdrLineItem["PlantID"] = com.STRToInt(DdlPlant.SelectedValue);
                objdrLineItem["Aflag"] = "True";
                objdtLineItem.Rows.Add(objdrLineItem);

                ViewState["LineItem"] = objdtLineItem;
                int LineNoInGrid = com.STRToInt(objdtLineItem.Rows[0]["LineNo"].ToString());
                for (int i = 1; i < objdtLineItem.Rows.Count; i++)
                {
                    if (com.STRToInt(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                    {
                        LineNoInGrid = com.STRToInt(objdtLineItem.Rows[i]["LineNo"].ToString());
                    }
                }
                HidLineNo.Value = (LineNoInGrid + 10).ToString();
                bagno = bagno + 1;
            }
            gvChipsBagging.DataSource = objdtLineItem;
            gvChipsBagging.DataBind();
            CalculateQty();
            ClearLineItemsAfterAdd();
        }
        catch { };

    }

    protected void TxtMaterialCode_TextChanged(object sender, System.EventArgs e)
    {
        /// <summary>
        /// This event is used to populate enterd material.
        /// </summary>
        try
        {
            string query = @"select AutoId,MaterialCode,MaterialDesc from Proc_MaterialMaster where MaterialCode ='" + TxtMaterialCode.Text.Trim() + "' and Status =1";

            DataTable dt = new DataTable();
            dt = com.executeSqlQry(query);

            HidMaterialId.Value = "";
            TxtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            DdlValuationType.Items.Clear();

            if (dt.Rows.Count > 0)
            {
                HidMaterialId.Value = dt.Rows[0]["AutoId"].ToString();
                TxtMaterialCode.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialName.Text = dt.Rows[0]["MaterialDesc"].ToString();

                BindMaterialInformation(HidMaterialId.Value);
                FillAllValuationTypeMaster();

                txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                    DdlPlant.SelectedValue, DdlValuationType.SelectedValue).ToString();
                if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                {
                    imgBtnBatchCode.Visible = false;
                }
                else
                {
                    imgBtnBatchCode.Visible = true;
                }
            }
            else
            {
                try
                {
                    txtSearchFromPopup.Text = "";
                    HidPopUpType.Value = "Material";
                    lPopUpHeader.Text = "Material Master";
                    lSearch.Text = "Search By Material Code: ";
                    FillAllMaterial("");
                    ModalPopupExtender2.Show();
                }
                catch { }
            }
        }
        catch { }
    }

    protected void gvChipsBagging_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        /// <summary>
        /// This event is used to delete the existing line item in output section.
        /// </summary>
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItem"];

            int PageNo = gvChipsBagging.PageIndex;
            int noOfRowinPage = gvChipsBagging.PageSize;
            int rowno = (noOfRowinPage * (PageNo)) + e.RowIndex;

            dtLineItem.Rows[rowno].Delete();
            dtLineItem.AcceptChanges();
            ViewState["LineItem"] = dtLineItem;

            gvChipsBagging.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsBagging.DataBind();
            CalculateQty();
        }
        catch { }
    }

    protected void ddlStorageLocationFrom_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        try
        {
            #region Reset the lineitems when storage location is changed.

            HidMaterialId.Value = "";
            TxtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            DdlValuationType.Items.Clear();
            TxtBatch.Text = "0";
            txtChipsBags.Text = "0";
            txtQuantityBags.Text = "0";
            txtTotalQuantity.Text = "0";
            txtTotalValue.Text = "0";
            txtCurrentStock.Text = "0";
            imgBtnBatchCode.Visible = true;

            BindLineItemsRecords("0");
            #endregion
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>
        try
        {
            if (com.STRToIntBig(txtQuantityBags.Text.Trim()) > 9999999999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999999999.99.", 125, 300);
                return;
            }

            if (HidAutoId.Value == "")
            {
                if (com.STRToDBL(txtTotalQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text)))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.Current stock is:" + txtCurrentStock.Text.Trim() + ".", 125, 300);
                    return;
                }
            }
            else if (com.STRToInt(HidAutoId.Value) > 0)
            {
                double Exceededqty = com.STRToDBL(txtTotalQuantity.Text.Trim()) - com.STRToDBL(HidPreTotQty.Value);
                if (com.STRToDBL(txtCurrentStock.Text) > 0)
                {
                    if (Exceededqty > (com.STRToDBL(txtCurrentStock.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreTotQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                        return;
                    }
                }
                else if (com.STRToDBL(txtCurrentStock.Text) < 0)
                {
                    if (Exceededqty < (com.STRToDBL(txtCurrentStock.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreTotQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                        return;
                    }
                    if (Exceededqty > 0)
                    {
                        if (Exceededqty > (com.STRToDBL(txtCurrentStock.Text)))
                        {
                            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreTotQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                            return;
                        }
                    }
                }
                else if (com.STRToDBL(txtCurrentStock.Text) == 0)
                {
                    if (Exceededqty > (com.STRToDBL(txtCurrentStock.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreTotQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                        return;
                    }
                }
            }

            #region Line Item Records

            DataTable dt = new DataTable();
            dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Input a LineItem first.", 125, 300);
                return;
            }

            #region MonthClosed for Storage Location**************************************************************

            //This will help to check for month closed for material in storage location or not.

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string StorageLocationCode = "";
                string query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dt.Rows[0]["StorageLocationIssue"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dt.Rows[i]["PlantId"].ToString();
                    string VoucherDate = txtVoucherDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"].ToString() + ".";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + dt.Rows[i]["LineNo"].ToString() + " for the selected storage location.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"].ToString() + ".";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }



            #endregion***********************************************************************************

            #endregion

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region Insert Header Records

            if (HidAutoId.Value == "")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();

            cmd.Parameters.Add("@VoucherDate", SqlDbType.VarChar).Value = txtVoucherDate.Text;
            cmd.Parameters.Add("@BaggingDate", SqlDbType.VarChar).Value = txtBaggingDate.Text;
            cmd.Parameters.Add("@TotalQty", SqlDbType.Float).Value = com.STRToDBL(txtTotalQuantity.Text.Trim());
            cmd.Parameters.Add("@TotalValue", SqlDbType.Float).Value = com.STRToDBL(txtTotalValue.Text.Trim());

            cmd.Parameters.Add("@CreatedBy", SqlDbType.VarChar).Value = Session["UserId"].ToString();
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.VarChar).Value = Session["UserId"].ToString();

            #region Table Parameter

            if (dt.Columns.Contains("sLocIssue"))
            {
                dt.Columns.Remove("sLocIssue");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("sLocRecieve"))
            {
                dt.Columns.Remove("sLocRecieve");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("MaterialCode"))
            {
                dt.Columns.Remove("MaterialCode");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("MaterialCode"))
            {
                dt.Columns.Remove("MaterialCode");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("UOM"))
            {
                dt.Columns.Remove("UOM");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("UOM"))
            {
                dt.Columns.Remove("UOM");
                dt.AcceptChanges();
            }
            if (dt.Columns.Contains("ValuationType"))
            {
                dt.Columns.Remove("ValuationType");
                dt.AcceptChanges();
            }


            cmd.Parameters.AddWithValue("@dtLineitems", dt);
            #endregion

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 100));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewVoucherNo", SqlDbType.VarChar, 50);
            cmd.Parameters["@NewVoucherNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_ChipsBagging";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewVoucherNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordSaved + "Voucher No. is:" + RecordNo, 140, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeaderItems();
                ClearLineItems();
                BindLineItemsRecords("0");

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion

        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, commessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = com_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Voucher No", "VoucherNo"));
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "CB" + financialYear + inv_series.ToString().PadLeft(5, '0');
        }
        catch
        {

        }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {
            string sql = "select  MAX(Series) from tblChBagHeader where [VoucherYear]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { };
        return piseries;
    }

    protected void BindMaterialInformation(string MaterialAutoId)
    {
        /// <summary>
        /// This method is used to get material information depend upon the material selection.
        /// </summary>
        try
        {
            txtUOM.Text = "";
            string sql = @"select MaterialDesc,B.Code,B.AutoId  from Proc_MaterialMaster as A inner join Proc_UOM_Master as B on A.UOMId = B.AutoId
                          where A.AutoId ='" + MaterialAutoId + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                HidUOM.Value = dt.Rows[0]["AutoId"].ToString();
                txtUOM.Text = dt.Rows[0]["Code"].ToString();
            }
            dt = null;
        }
        catch { }
    }

    protected void BindPlant(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the plant.
        /// </summary>
        try
        {
            string str = "SELECT autoid,(PLANTCODE+'('+PLANTNAME+')') as [Plant] FROM COM_PLANT_MST WHERE ACTIVESTATUS =1";
            DataTable dt = com.executeSqlQry(str);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["Plant"].ToString(), row["AutoId"].ToString()));
                }
            }
        }
        catch { }
    }

    private void BindToStorageLocation(string Searchtext, string Plant)
    {
        /// <summary>
        /// This method is used to bind to storage location for popup on behalf of plant.
        /// </summary>
        /// 
        DataTable dt = new DataTable();
        try
        {
            string sql = @" Select distinct S.autoid,StorageLocCode as Code, Location as Name from Prod_StorageLocation_Mst as S Where
                            PlantId =" + Plant + " and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
            Dispose(dt);
        }
        catch
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
            Dispose(dt);
        }
    }

    protected void BindStorageLocationFromDD(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the storage location in from dd.
        /// </summary>
        try
        {
            string sql = @" Select distinct S.autoid,(StorageLocCode+' - '+Location+'')
                            as StorageLocation from Prod_StorageLocation_Mst as S inner 
                            join Proc_MasterValuationStk as P on S.autoid = P.StorageLocationID  and P.Plant='" + DdlPlant.SelectedValue + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["StorageLocation"].ToString(), row["autoid"].ToString()));
                }
            }
        }
        catch { }
    }

    protected void BindStorageLocationToDD(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the storage location in to dd.
        /// </summary>
        try
        {
            string sql = @" Select distinct S.autoid,(StorageLocCode+' - '+Location+'') as StorageLocation from Prod_StorageLocation_Mst as S Where
                            PlantId ='" + DdlPlant.SelectedValue + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["StorageLocation"].ToString(), row["autoid"].ToString()));
                }
            }
        }
        catch { }
    }

    private void FillAllPlantMaster(string Searchtext)
    {
        /// <summary>
        /// This method is fill all the plant in popup.
        /// </summary>

        try
        {
            DataTable dt = new DataTable();
            dt = com_mst.FillAllPlantMaster(Searchtext);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                if (dt.Columns.Contains("PLANTCODE"))
                {
                    dt.Columns["PLANTCODE"].ColumnName = "Plant Code";

                }
                if (dt.Columns.Contains("PLANTNAME"))
                {
                    dt.Columns["PLANTNAME"].ColumnName = "Plant Name";
                }
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private bool IsNotBatchIndicator(string materialcode)
    {
        /// <summary>
        /// This method is check the batch indicator of the material.
        /// </summary>

        bool IsBatchIndicator = false;
        try
        {
            string str = "select BatchIndicator from Proc_MaterialMaster where MaterialCode='" + materialcode + "'";
            DataTable dtstr = com.executeSqlQry(str);
            if (dtstr != null && dtstr.Rows.Count > 0)
            {
                if (dtstr.Rows[0]["BatchIndicator"].ToString() == "True")
                {
                    IsBatchIndicator = true;
                }
            }
            Dispose(dtstr);
        }
        catch { };
        return IsBatchIndicator;
    }

    private void FillAllValuationTypeMaster()
    {
        /// <summary>
        /// This method is fill all the valuation type on behalf of material.
        /// </summary>

        DataTable dt = new DataTable();
        try
        {
            string sql = @"Select distinct V.AutoId, V.ValuationType from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
                           on V.AutoId =P.ValuationType where P.MaterialCodeID ='" + HidMaterialId.Value + "'";
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                DdlValuationType.DataTextField = "ValuationType";
                DdlValuationType.DataValueField = "AutoId";
                DdlValuationType.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    DdlValuationType.DataBind();
                }
            }
            else
            {
                DdlValuationType.Items.Clear();
            }
            Dispose(dt);
        }
        catch
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
            Dispose(dt);
        }
    }

    protected void Dispose(DataTable ddt)
    {
        /// <summary>
        /// This method is to dispose the datatable.
        /// </summary>
        ///
        try
        {
            ddt.Dispose();
        }
        catch { }
    }

    private void FillAllMaterial(string Searchtext)
    {
        /// <summary>
        /// This method is fill all the material in popup.
        /// </summary>

        try
        {
            DataTable dt = new DataTable();
            string sql = @"select distinct P.AutoId,P.MaterialCode as [Material Code],P.MaterialDesc as [Description],UOMId
	                      ,(select Description from Proc_UOM_Master where AutoId =P.UOMId) as UOM
                           from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                          P.AutoId = M.MaterialCodeID where M.StorageLocationID ='" + ddlStorageLocationFrom.SelectedValue + "' and (P.MaterialCode like '%" + Searchtext + "%' or P.MaterialDesc like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void BindStorageLocation(string Searchtext, string Plant)
    {
        /// <summary>
        /// This method is fill all the storage location on behalf on plant in popup.
        /// </summary>

        DataTable dt = new DataTable();
        try
        {
            string sql = @" Select distinct S.autoid,StorageLocCode as [Storage Location Code], (StorageLocCode+' ('+Location+')')
                            as [Storage Location Name] from Prod_StorageLocation_Mst as S inner 
                            join Proc_MasterValuationStk as P on S.autoid = P.StorageLocationID  and P.Plant='" + Plant + "' and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
            Dispose(dt);
        }
        catch
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
            Dispose(dt);
        }

    }

    protected void FillAllBatch(string Searchtext, string storagelocationid, string plant, string ValuationTypeid, string materialcode)
    {
        /// <summary>
        /// This method is used to get all the batch and fill in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans where Plant='" + plant + "' and";
            sql += " StorageLocation='" + GetStorageLocationCodeById(storagelocationid) + "' and MaterialCode='"
                                      + materialcode + "' and ValuationType='" + ValuationTypeid
                                      + "' and activestatus=1 and (BatchNo like '%" + Searchtext + "%' or BatchNo like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = commessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = commessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = commessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    public string GetStorageLocationCodeById(string id)
    {
        /// <summary>
        /// This method is get the storage location code by id.
        /// </summary>

        try
        {
            string str = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid='" + id + "'";
            DataTable dtstr = com.executeSqlQry(str);
            if (dtstr != null && dtstr.Rows.Count > 0)
            {
                return dtstr.Rows[0]["StorageLocCode"].ToString();
            }
            Dispose(dtstr);
        }
        catch { }
        return "";
    }

    public void ClearHeaderItems()
    {
        /// <summary>
        /// This method is clear the header records.
        /// </summary>

        try
        {
            HidAutoId.Value = "";
            FillFinancialYear();
            txtBaggingDate.Text = DateTime.Now.ToString(com_mst.DateFormat);
            txtVoucherDate.Text = DateTime.Now.ToString(com_mst.DateFormat);
            txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            HidPreTotQty.Value = "0";
            EnableDisableFields(true);
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    public void ClearLineItems()
    {
        /// <summary>
        /// This method is clear the line item records.
        /// </summary>

        try
        {
            HidMaterialId.Value = "";
            DdlPlant.SelectedIndex = 0;
            ddlStorageLocationFrom.SelectedIndex = 0;
            ddlStorageLocationTo.SelectedIndex = 0;

            TxtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            HidLineNo.Value = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            DdlValuationType.Items.Clear();
            TxtBatch.Text = "0";
            txtChipsBags.Text = "0";
            txtQuantityBags.Text = "0";
            txtTotalQuantity.Text = "0";
            txtTotalValue.Text = "0";
            txtCurrentStock.Text = "0";
            imgBtnBatchCode.Visible = true;
        }
        catch { }
    }

    public void ClearLineItemsAfterAdd()
    {
        /// <summary>
        /// This method is clear the line item record after adding the records in grid.
        /// </summary>

        try
        {
            HidMaterialId.Value = "";
            DdlPlant.SelectedIndex = 0;
            ddlStorageLocationFrom.SelectedIndex = 0;
            ddlStorageLocationTo.SelectedIndex = 0;

            TxtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            //HidLineNo.Value = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            DdlValuationType.Items.Clear();
            TxtBatch.Text = "0";
            txtChipsBags.Text = "0";
            txtQuantityBags.Text = "0";
            imgBtnBatchCode.Visible = true;
        }
        catch { }
    }

    private Int64 AutoBagNo()
    {
        /// <summary>
        /// This method is calculate the bag no.
        /// </summary>
        try
        {
            string formid = ConfigurationManager.AppSettings["FormIdChipsBagging"].ToString();
            DataTable dt = com_mst.GetNewGeneratedSeriesForCriteria(formid, txtYear.Text, "", "");
            if (dt != null && dt.Rows.Count > 0)
            {
                return Convert.ToInt64(dt.Rows[0]["GeneratedNo"].ToString());
            }
        }
        catch { };
        return 0;
    }

    private void GetAllChipsBaggingList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the voucher list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]  
		                    ,[VoucherNo]
		                    ,[VoucherYear]
		                    ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
		                    ,CONVERT(VARCHAR(11), [BaggingDate], 101) as [BaggingDate]     
                      FROM [tblChBagHeader] as A where [VoucherNo] like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = commessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = commessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    private void BindHeaderAndGridRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [VoucherNo]
                          ,[VoucherYear]
                          ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
	                      ,CONVERT(VARCHAR(11), [BaggingDate], 101) as [BaggingDate]      
                          ,[TotalQty]                   
                      FROM [tblChBagHeader] as A where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                txtVoucherDate.Text = dt.Rows[0]["VoucherDate"].ToString();
                txtBaggingDate.Text = dt.Rows[0]["BaggingDate"].ToString();
                txtVoucherNo.Text = dt.Rows[0]["VoucherNo"].ToString();
                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();
                HidPreTotQty.Value = dt.Rows[0]["TotalQty"].ToString();
                dt = null;
            }
            dt = null;
            EnableDisableFields(false);

            #region Bind Line Items

            BindLineItemsRecords(HidAutoId.Value);

            #endregion

            dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count > 0)
            {
                DdlPlant.SelectedValue = dt.Rows[0]["PlantId"].ToString();
                ddlStorageLocationFrom.SelectedValue = dt.Rows[0]["StorageLocationIssue"].ToString();
                ddlStorageLocationTo.SelectedValue = dt.Rows[0]["StorageLocationRec"].ToString();
            }
            dt = null;
        }
        catch { }
    }

    protected void EnableDisableFields(bool booltype)
    {
        /// <summary>
        /// This method is used to to enable/disable line item controls.
        /// </summary>
        try
        {

            DdlPlant.Enabled = booltype;
            ddlStorageLocationFrom.Enabled = booltype;
            ddlStorageLocationTo.Enabled = booltype;
            TxtMaterialCode.Enabled = booltype;
            DdlValuationType.Enabled = booltype;
            txtChipsBags.Enabled = booltype;
            txtQuantityBags.Enabled = booltype;
            imgBtnStorageLocationFrom.Enabled = booltype;
            imgBtnStorageLocationTo.Enabled = booltype;
            ImgBtnMaterialCode.Enabled = booltype;
            imgBtnBatchCode.Enabled = booltype;
        }
        catch { }
    }

    private void BindLineItemsRecords(string VoucherId)
    {
        /// <summary>
        /// This method is used to bind the form grid on behalf of voucher id.
        /// </summary>
        try
        {
            string sql = @"SELECT [AutoId]      
                          ,[LnNo] as [LineNo]
                          ,[BagNo]
                          ,[PlantId]
                          ,[StorageLocationIssue]
                          ,(Select StorageLocCode+' - '+Location from Prod_StorageLocation_Mst WHERE autoid =B.StorageLocationIssue) AS SLocIssue
                          ,[StorageLocationRec]
                          ,(Select StorageLocCode+' - '+Location from Prod_StorageLocation_Mst WHERE autoid =B.StorageLocationRec) AS SLocRecieve
                          ,[MaterialId]
                          ,(SELECT MaterialCode FROM Proc_MaterialMaster WHERE AutoId = B.MaterialId) as MaterialCode
                          ,[BUOM]
                          ,(select Description from Proc_UOM_Master where AutoId =B.BUOM) as UOM
                          ,[ValuationTypeId]
                          ,(Select ValuationType from Proc_ValuationClass_Master WHERE autoid =B.ValuationTypeId) AS ValuationType
                          ,[BatchCode]
                          ,[ChipsBags]
                          ,[Quantity]
                          ,[Aflag]
                      FROM [tblChBagDetails] as B where [ChipsID]='" + VoucherId + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                int TotalRows = dt.Rows.Count;
                HidLineNo.Value = (com.STRToInt(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
            }
            else
            {
                HidLineNo.Value = "10";
            }

            ViewState["LineItem"] = dt;
            gvChipsBagging.EditIndex = -1;
            gvChipsBagging.DataSource = dt;
            gvChipsBagging.DataBind();
            CalculateQty();
        }
        catch { }
    }

    protected void CalculateQty()
    {
        /// <summary>
        /// This method is used to calculate the quantity.
        /// </summary>
        /// 
        double totalqty = 0;
        DataTable dt = new DataTable();
        dt = (DataTable)ViewState["LineItem"];
        try
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["Aflag"].ToString() == "True")
                {
                    totalqty += com.STRToDBL(dt.Rows[i]["Quantity"].ToString());
                }
            }
            txtTotalQuantity.Text = Convert.ToString(totalqty);

            string MaterialId = dt.Rows[0]["MaterialId"].ToString();
            string MaterialCode = dt.Rows[0]["MaterialCode"].ToString();
            string PlantId = dt.Rows[0]["PlantId"].ToString();
            string ValuationTypeId = dt.Rows[0]["ValuationTypeId"].ToString();
            string StorageLocationId = dt.Rows[0]["StorageLocationIssue"].ToString();

            if (txtTotalQuantity.Text != "0" && MaterialId != "0" && PlantId != "0" && ValuationTypeId != "0")
            {
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string Query = @"select dbo.mm_get_valuated_wa_price( '" + MaterialCode + "','" + PlantId + "','" + ValuationTypeId + "','" + txtVoucherDate.Text + "') as MaterialRate";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(Query);
                if (dtValStk.Rows.Count > 0)
                {
                    MaterialRate = Convert.ToDouble(dtValStk.Rows[0]["MaterialRate"].ToString());
                }
                MaterialValue = Math.Round((Convert.ToDouble(txtTotalQuantity.Text.Trim()) * MaterialRate), 2);
                txtTotalValue.Text = Convert.ToString(MaterialValue);
            }

            if (com.STRToInt(HidAutoId.Value) > 0)
            {
                txtCurrentStock.Text = CheckForQuantity_InStock(MaterialId, StorageLocationId, PlantId, ValuationTypeId).ToString();
            }
        }
        catch { }
    }

    private double CheckForQuantity_InStock(string materialid, string storagelocationid, string plant, string ValuationTypeid)
    {
        /// <summary>
        /// This method is used to check the quantity in stock.
        /// </summary>
        double TotalQuantityOnStock = 0.0;
        string str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
                        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and Plant='" + plant + "' and ValuationType='" + ValuationTypeid + "'";
        DataTable dtquantity = com.executeSqlQry(str);
        if (dtquantity != null && dtquantity.Rows.Count > 0)
        {
            TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
        }
        return TotalQuantityOnStock;
    }

    #endregion


}