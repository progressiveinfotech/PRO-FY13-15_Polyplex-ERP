﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Data.Sql;
using System.Data.Common;

public partial class Sales_Reports_InvoiceNotMade : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    private SqlConnection con = new SqlConnection();
    private string constr;
    private SqlCommand cmd = new SqlCommand();
    private SqlDataAdapter da;
    private DataSet ds = new DataSet();
    private int i, y, z;
    private PrProc abc = new PrProc();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                TabContainer1.ActiveTabIndex = 0;
            }

            if (!IsPostBack)
            {
                DateTime firstDayOfSelectedMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DateTime defaultToDate = System.DateTime.Now;

                txtfromdate.Attributes.Add("readonly", "true");
                txttodate.Attributes.Add("readonly", "true");

                txtfromdate.Attributes.Add("style", "background:lightgray");
                txttodate.Attributes.Add("style", "background:lightgray");

                txtfromdate.Text = firstDayOfSelectedMonth.ToString("MM-dd-yyyy");
                txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");

                pnlgridlist.Visible = false;
                btnshowexcel.Visible = false;
                lblmsg.Visible = false;
            }
        }
        catch { }
    }

    protected void ButReset_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime defaultToDate = System.DateTime.Now;
            DateTime firstDayOfSelectedMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);

            txtfromdate.Text = firstDayOfSelectedMonth.ToString("MM-dd-yyyy");
            txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");

            this.gridList.Visible = false;
            btnshowexcel.Visible = false;
            lblmsg.Visible = false;
            this.txtfromdate.Focus();
        }
        catch { }
    }

    protected void ButShow_Click(object sender, EventArgs e)
    {
        try
        {
            this.gridList.Visible = true;
            pnlgridlist.Visible = true;
            btnshowexcel.Visible = true;
            lblmsg.Visible = true;
            this.txtfromdate.Focus();

            if ((txtfromdate.Text == "") & (txttodate.Text == ""))
            {
                getdata();
            }
            else
            {
                DateTime startdt = DateTime.Parse(txtfromdate.Text);
                DateTime enddt = DateTime.Parse(txttodate.Text);
                if (startdt > enddt)
                {
                    lblmsg.Text = "Please enter Valid Date Range";
                    pnlgridlist.Visible = false;
                    btnshowexcel.Visible = false;
                }
                else
                {
                    getdata();
                }
            }
        }
        catch { }
    }        

    protected void btnshowexcel_Click(object sender, EventArgs e)
    {

        try
        {
            if (gridList.Rows.Count < 1)
            { }
            else
            {
                string attachment = "attachment; filename=MEGFromProcess.xls";
                Response.ClearContent();
                Response.AddHeader("content-disposition", attachment);
                Response.ContentType = "application/ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                //---------------------------------------------
                HtmlForm frm = new HtmlForm();
                Response.Charset = "";
                EnableViewState = false;
                Controls.Add(frm);
                frm.InnerHtml = "<table style='border:1px solid #000000;' border='0'><caption><strong>MEG From Process</strong></caption>";
                frm.InnerHtml += "<tr style='background-color:#dce1fa'><th></th><th>&nbsp;</th><th>From :</th><td>&nbsp;</td><th>To :</th></tr>";
                frm.InnerHtml += "<tr><td align='center'></td><td>&nbsp;</td><td align='center'>" + txtfromdate.Text + "</td><td>&nbsp;</td><td align='center'>" + txttodate.Text + "</td></tr>";
                frm.InnerHtml += "</table><br>";
                frm.Controls.Add(gridList);
                frm.RenderControl(htw);
                //---------------------------------------------
                Response.Write(sw.ToString());
                Response.End();
            }
        }
        catch { }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void getdata()
    {
        try
        {
            lblmsg.Visible = false;
            constr = ConfigurationManager.ConnectionStrings["Polyplex_DB"].ConnectionString;
            con.ConnectionString = constr;
            con.Open();
            con.Close();
            ds.Clear();

            string sql = @"SELECT [VoucherNo]
                          ,[VoucherYear]
                          ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
	                      ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                          ,[Weightofwater]
                          ,[ReagentforWater]
                          ,[Factor]
                          ,[WeightofMEG]
                          ,[ReagentforMEG]
                          ,[Location]
                          ,[MoistureContent]
                          ,[Acidity]
                          ,[Appearance_350]
                          ,[Appearance_220]
                          ,[Appearance_275]
                          ,[Aldehyde]
                          ,[SpecificGravity]
                          ,(case when AFlag =1 then 'Active' else 'InActive' end) as Status
                      FROM [tblChMegProcess] as A where PostingDate between '" + abc.DtString(Convert.ToDateTime(txtfromdate.Text))
                                                                                       + "' And '" + abc.DtString(Convert.ToDateTime(txttodate.Text)) + "'";
            da = new SqlDataAdapter(sql, con);
            i = da.Fill(ds, "disp");
            if (i == 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Record Not Found";
                pnlgridlist.Visible = false;
                btnshowexcel.Visible = true;
                return;
            }
            DataTable dt = abc.executeSqlQry(sql);
            gridList.DataSource = dt;
            gridList.DataBind();
            this.TabContainer1.ActiveTabIndex = 1;
            pnlgridlist.Visible = true;
            btnshowexcel.Visible = true;
            lblmsg.Visible = false;
        }
        catch { }
    }

    #endregion
    
}