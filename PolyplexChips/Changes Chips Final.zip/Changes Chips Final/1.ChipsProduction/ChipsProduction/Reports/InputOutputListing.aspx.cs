﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Data.Sql;
using System.Data.Common;

public partial class Sales_Reports_InvoiceNotMade : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    private SqlConnection con = new SqlConnection();
    private string constr;
    private SqlCommand cmd = new SqlCommand();
    private SqlDataAdapter da;
    private DataSet ds = new DataSet();
    private int i, y, z;
    private PrProc abc = new PrProc();
    Common_Message objcommonmessage = new Common_Message();
    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                TabContainer1.ActiveTabIndex = 0;
            }

            if (!IsPostBack)
            {                
                DateTime firstDayOfSelectedMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DateTime defaultToDate = System.DateTime.Now;

                txtfromdate.Attributes.Add("readonly", "true");
                txttodate.Attributes.Add("readonly", "true");
                txtDocumentNo.Attributes.Add("readonly", "true");
                txtMaterialCode.Attributes.Add("readonly", "true");

                txtfromdate.Attributes.Add("style", "background:lightgray");
                txttodate.Attributes.Add("style", "background:lightgray");
                txtDocumentNo.Attributes.Add("style", "background:lightgray");
                txtMaterialCode.Attributes.Add("style", "background:lightgray");

                txtfromdate.Text = firstDayOfSelectedMonth.ToString("MM-dd-yyyy");
                txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");

                pnlgridlist.Visible = false;
                btnshowexcel.Visible = false;
                lblmsg.Visible = false;                
            }
        }
        catch { }
    }

    protected void ButShow_Click(object sender, EventArgs e)
    {
        try
        {
            this.gridList.Visible = true;
            pnlgridlist.Visible = true;
            btnshowexcel.Visible = true;
            lblmsg.Visible = true;
            this.txtfromdate.Focus();

            if ((txtfromdate.Text == "") & (txttodate.Text == ""))
            {
                getdata();
            }
            else
            {
                DateTime startdt = DateTime.Parse(txtfromdate.Text);
                DateTime enddt = DateTime.Parse(txttodate.Text);
                if (startdt > enddt)
                {                    
                    lblmsg.Text = "Please enter Valid Date Range";
                    pnlgridlist.Visible = false;
                    btnshowexcel.Visible = false;
                }
                else
                {
                    getdata();
                }
            }
        }
        catch { }
    }    

    protected void ButReset_Click(object sender, EventArgs e)
    {
        try
        {            
            DateTime defaultToDate = System.DateTime.Now;
            DateTime firstDayOfSelectedMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);

            txtfromdate.Text = firstDayOfSelectedMonth.ToString("MM-dd-yyyy");
            txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");
            txtDocumentNo.Text = "";
            txtMaterialCode.Text = "";

            this.gridList.Visible = false;
            btnshowexcel.Visible = false;
            lblmsg.Visible = false;
            this.txtfromdate.Focus();
        }
        catch { }
    }

    protected void imgBtnDocumentNo_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            /// <summary>
            /// This event is used to populate all the materials for output section.
            /// </summary> 
            try
            {
                txtSearchFromPopup.Text = "";
                HidPopUpType.Value = "Document";
                lPopUpHeader.Text = "Document List";
                lSearch.Text = "Search By Document No: ";
                FillAllDocument("");
                ModalPopupExtender2.Show();
            }
            catch { }
        }
        catch { }
    }

    protected void imgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the materials.
        /// </summary> 
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Material";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code/Name: ";
            FillAllMaterial("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "Document")
                {
                    txtDocumentNo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
                else if (HidPopUpType.Value == "Material")
                {
                    txtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
            }
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "Document")
            {
                FillAllDocument(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "Document")
            {
                FillAllDocument(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void btnshowexcel_Click(object sender, EventArgs e)
    {

        try
        {
            if (gridList.Rows.Count < 1)
            { }
            else
            {
                string attachment = "attachment; filename=InputOutputListing.xls";
                Response.ClearContent();
                Response.AddHeader("content-disposition", attachment);
                Response.ContentType = "application/ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                //---------------------------------------------
                HtmlForm frm = new HtmlForm();
                Response.Charset = "";
                EnableViewState = false;
                Controls.Add(frm);
                frm.InnerHtml = "<table style='border:1px solid #000000;' border='0'><caption><strong>Input/Output Listing</strong></caption>";
                frm.InnerHtml += "<tr style='background-color:#dce1fa'><th></th><th>&nbsp;</th><th>From :</th><td>&nbsp;</td><th>To :</th></tr>";
                frm.InnerHtml += "<tr><td align='center'></td><td>&nbsp;</td><td align='center'>" + txtfromdate.Text + "</td><td>&nbsp;</td><td align='center'>" + txttodate.Text + "</td></tr>";
                frm.InnerHtml += "</table><br>";
                frm.Controls.Add(gridList);
                frm.RenderControl(htw);
                //---------------------------------------------
                Response.Write(sw.ToString());
                Response.End();
            }
        }
        catch { }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void getdata()
    {
        try
        {
            lblmsg.Visible = false;
            constr = ConfigurationManager.ConnectionStrings["Polyplex_DB"].ConnectionString;
            con.ConnectionString = constr;
            con.Open();
            con.Close();
            ds.Clear();

            string sql = @"SELECT [LineNo]
                          ,H.DocumentNo
                          ,H.[VoucherYear]
                          ,CONVERT(VARCHAR(11), H.DocumentDate, 101) as DocumentDate
                          ,CONVERT(VARCHAR(11), H.PostingDate , 101) as PostingDate
                          ,(select ChMstBatchDesc from tblChMstMasterBatch where AutoId =H.ChProcessCode) as ChProcessCode
                          ,(select MaterialCode from Proc_MaterialMaster where AutoId =D.MaterialCodeID) as MaterialCode       
                          ,(SELECT MaterialDesc FROM Proc_MaterialMaster WHERE AutoId = D.MaterialCodeID) as MaterialName  
                          ,(select Code from Proc_UOM_Master where AutoId =(SELECT UOMId FROM Proc_MaterialMaster WHERE AutoId = D.MaterialCodeID )) as Uom                 
                          ,(select ValuationType from Proc_ValuationClass_Master where AutoId =D.ValuationTypeId) as ValuationType
                          ,[BatchCode]                        
                          ,(select StorageLocCode from Prod_StorageLocation_Mst where autoid =D.StorageLocationId) as StorageLocationCode
                          ,(select PlantCode+' - '+PlantName from Com_Plant_Mst where autoid =D.PlantId) as Plant
                          ,[Quantity]
                          ,[Value]
                          ,(case when [PreparationDilution] ='P' then 'Preparation' when [PreparationDilution] ='D' then 'Dilution' end) as PreparationDilution                          
                          ,D.Category
                          ,(case when D.AFlag =1 then 'Active' else 'InActive' end) as Status
                      FROM [tblCPEntryDetails] as D inner join tblCPEntryHeader as H on D.DocAutoId =H.AutoId 
                      where (H.DocumentNo like '" + txtDocumentNo.Text.Trim() + "' and D.MaterialCodeID = (select AutoId from Proc_MaterialMaster";
            sql += " where MaterialCode like'" + txtMaterialCode.Text.Trim() + "') and H.PostingDate between '" + abc.DtString(Convert.ToDateTime(txtfromdate.Text))
                                                                                       + "' And '" + abc.DtString(Convert.ToDateTime(txttodate.Text)) + "')";
            da = new SqlDataAdapter(sql, con);
            i = da.Fill(ds, "disp");
            if (i == 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Record Not Found";
                pnlgridlist.Visible = false;
                btnshowexcel.Visible = true;
                return;
            }
            DataTable dt = new DataTable();
            dt = abc.executeSqlQry(sql);
            gridList.DataSource = dt;
            gridList.DataBind();
            this.TabContainer1.ActiveTabIndex = 1;
            pnlgridlist.Visible = true;
            btnshowexcel.Visible = true;
            lblmsg.Visible = false;
        }
        catch { }
    }

    protected void FillAllDocument(string Searchtext)
    {
        /// <summary>
        /// This method is used to get all materials and fill in popup grid depend upon the category i.e output or input.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select DocumentNo from tblCPEntryHeader where DocumentNo like '%" + Searchtext + "%'";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    protected void FillAllMaterial(string Searchtext)
    {
        /// <summary>
        /// This method is used to get all materials and fill in popup grid depend upon the category i.e output or input.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select distinct B.MaterialCode,B.MaterialDesc from tblMatMapping as A inner join Proc_MaterialMaster as B 
                          on A.MaterialId =B.AutoId where A.BatchId in (5,6) and A.Category in ('Output','Input') and A.AFlag =1 and
                          B.Status =1 and (B.MaterialCode like '%" +Searchtext+"%' or B.MaterialDesc like '%"+Searchtext +"%')";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    #endregion   
    
}