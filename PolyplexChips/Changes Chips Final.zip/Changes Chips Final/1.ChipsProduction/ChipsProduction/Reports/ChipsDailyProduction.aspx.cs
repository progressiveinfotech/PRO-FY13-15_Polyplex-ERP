﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Data.Sql;
using System.Data.Common;

public partial class Sales_Reports_InvoiceNotMade : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    private SqlConnection con = new SqlConnection();
    private string constr;
    private SqlCommand cmd = new SqlCommand();
    private SqlDataAdapter da;
    private DataSet ds = new DataSet();
    private int i, y, z;
    private PrProc abc = new PrProc();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            TabContainer1.ActiveTabIndex = 0;
        }

        if (!IsPostBack)
        {
            DateTime defaultFromDate = System.DateTime.Now;
            DateTime defaultToDate = System.DateTime.Now;

            txtfromdate.Attributes.Add("readonly", "true");
            txttodate.Attributes.Add("readonly", "true");


            txtfromdate.Text = defaultFromDate.ToString("MM-dd-yyyy");
            txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");

            pnlgridlist.Visible = false;
            btnshowexcel.Visible = false;
            lblmsg.Visible = false;
        }
    }

    protected void ButShow_Click(object sender, EventArgs e)
    {
        if ((txtfromdate.Text == "") & (txttodate.Text == ""))
        {
            getdata();
        }

        else
        {
            DateTime startdt = DateTime.Parse(txtfromdate.Text);
            DateTime enddt = DateTime.Parse(txttodate.Text);
            if (startdt > enddt)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Please enter Valid Date Range";
                pnlgridlist.Visible = false;
                btnshowexcel.Visible = false;
            }
            else
            {
                getdata();
            }
        }
    }    

    protected void ButReset_Click(object sender, EventArgs e)
    {
        DateTime defaultFromDate = System.DateTime.Now;
        DateTime defaultToDate = System.DateTime.Now;

        txtfromdate.Attributes.Add("readonly", "true");
        txttodate.Attributes.Add("readonly", "true");

        txtfromdate.Text = defaultFromDate.ToString("MM-dd-yyyy");
        txttodate.Text = defaultToDate.ToString("MM-dd-yyyy");

        this.gridList.Visible = false;
        btnshowexcel.Visible = false;
        lblmsg.Visible = false;
        this.txtfromdate.Focus();

    }

    protected void btnshowexcel_Click(object sender, EventArgs e)
    {
        
        try
        {
            if (gridList.Rows.Count < 1)
            {            }
            else
            {
                string attachment = "attachment; filename=InvNotMade.xls";
                Response.ClearContent();
                Response.AddHeader("content-disposition", attachment);
                Response.ContentType = "application/ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                //---------------------------------------------
                HtmlForm frm = new HtmlForm();
                Response.Charset = "";
                EnableViewState = false;
                Controls.Add(frm);
                frm.InnerHtml = "<table style='border:1px solid #000000;' border='0'><caption><strong>Invoice Not Made</strong></caption>";
                frm.InnerHtml += "<tr style='background-color:#dce1fa'><th></th><th>&nbsp;</th><th>From :</th><td>&nbsp;</td><th>To :</th></tr>";
                frm.InnerHtml += "<tr><td align='center'></td><td>&nbsp;</td><td align='center'>" + txtfromdate.Text + "</td><td>&nbsp;</td><td align='center'>" + txttodate.Text + "</td></tr>";
                frm.InnerHtml += "</table><br>";
                frm.Controls.Add(gridList);
                frm.RenderControl(htw);
                //---------------------------------------------
                Response.Write(sw.ToString());
                Response.End();
            }
        }
        catch (Exception ex)
        {        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void getdata()
    {
        try
        {
            lblmsg.Visible = false;
            constr = ConfigurationManager.ConnectionStrings["Polyplex_DB"].ConnectionString;
            con.ConnectionString = constr;
            con.Open();
            con.Close();
            ds.Clear();

            string sql = @"Select distinct InvNo, ISS_DATE, SalesOrdNo, c.Name from Prod_RollSlitting_Details a Inner Join dbo.Sal_Glb_OrderInformations o on 
                            a.SalesOrdNo = o.SoNo Inner join dbo.Sal_Glb_Customer_Mst c on o.socustomer = c.customerid 
                            where InvNo not in (Select InvoiceNo From Sal_Glb_Invoice_Tran) And ISS_PAC = 'D' And o.SalesTypeId not in (1,7) And
                            ISS_DATE Between '" + abc.DtString(Convert.ToDateTime(txtfromdate.Text)) + "' And '" + abc.DtString(Convert.ToDateTime(txttodate.Text)) + @"' Or 
                                    InvNo not in (Select VoucherNumber From dbo.FA_Glb_JournalVoucher_Header_trans) And iss_pac = 'D' And o.SalesTypeId not in (1,7) And
                            ISS_DATE Between '" + abc.DtString(Convert.ToDateTime(txtfromdate.Text)) + "' And '" + abc.DtString(Convert.ToDateTime(txttodate.Text)) + "'";

            da = new SqlDataAdapter(sql, con);
            i = da.Fill(ds, "disp");
            if (i == 0)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Record Not Found";
                pnlgridlist.Visible = false;
                btnshowexcel.Visible = true;
                return;
            }
            DataTable dt = abc.executeSqlQry(sql);
            gridList.DataSource = dt;
            gridList.DataBind();
            this.TabContainer1.ActiveTabIndex = 1;
            pnlgridlist.Visible = true;
            btnshowexcel.Visible = true;
            lblmsg.Visible = false;
        }
        catch (Exception ex)
        {
        }
    }

    #endregion
}