﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================

        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "CP Entry";
                TabContainer1.ActiveTabIndex = 0;

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                txtDocumentDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();

                BindPlant(ddlPlantOutput);
                BindStorageLocation(ddlPlantOutput, ddlStorageLocationOutput);
                BindChCPEntryDetails("Output", gvOutPut);

                BindPlant(ddlPlantInput);
                BindStorageLocation(ddlPlantInput, ddlStorageLocationInput);
                BindChCPEntryDetails("Input", gvInput);

                #region Change Color and Readonly Fields

                txtDocumentNo.Attributes.Add("style", "background:lightgray");
                txtYear.Attributes.Add("style", "background:lightgray");
                txtDocumentDate.Attributes.Add("style", "background:lightgray");
                txtDocumentNo.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");
                txtMaterialNameOutput.Attributes.Add("style", "background:lightgray");
                txtMaterialNameInput.Attributes.Add("style", "background:lightgray");
                txtUOMOutput.Attributes.Add("style", "background:lightgray");
                txtUOMInput.Attributes.Add("style", "background:lightgray");
                txtCurrentStockOutput.Attributes.Add("style", "background:lightgray");
                txtCurrentStockInput.Attributes.Add("style", "background:lightgray");
                txtBatchNoOutput.Attributes.Add("style", "background:lightgray");
                txtBatchNoInput.Attributes.Add("style", "background:lightgray");
                txtValueOutput.Attributes.Add("style", "background:lightgray");
                txtValueInput.Attributes.Add("style", "background:lightgray");

                txtDocumentNo.Attributes.Add("readonly", "true");
                txtYear.Attributes.Add("readonly", "true");
                txtDocumentDate.Attributes.Add("readonly", "true");
                txtDocumentNo.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");
                txtMaterialNameOutput.Attributes.Add("readonly", "true");
                txtMaterialNameInput.Attributes.Add("readonly", "true");
                txtUOMOutput.Attributes.Add("readonly", "true");
                txtUOMInput.Attributes.Add("readonly", "true");
                txtCurrentStockOutput.Attributes.Add("readonly", "true");
                txtCurrentStockInput.Attributes.Add("readonly", "true");
                txtBatchNoOutput.Attributes.Add("readonly", "true");
                txtBatchNoInput.Attributes.Add("readonly", "true");
                txtValueOutput.Attributes.Add("readonly", "true");
                txtValueInput.Attributes.Add("readonly", "true");

                #endregion

                txtDocumentNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>
        try
        {
            ClearHeader();
            ClearLineItemRecordsOutput();
            ClearLineItemRecordsInput();
            BindChCPEntryDetails("Output", gvOutPut);
            BindChCPEntryDetails("Input", gvInput);

            txtSearchList.Text = "";
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllCPEntryList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void ddlProcessCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to generate new voucher no by this selection.
        /// </summary>
        try
        {
            txtDocumentNo.Text = AutogenerateNo(txtYear.Text);
        }
        catch { }
    }

    protected void imgBtnAddLineOutput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to add and update new line item in output section.
        /// </summary>
        try
        {
            if (com.STRToIntBig(txtQuantityOutput.Text.Trim()) > 9999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999.99.", 125, 300);
                return;
            }

            //Added by satish on 18 July-13
            if (txtQuantityOutput.Text != "" && HidMaterialIdOutput.Value != "" && ddlPlantOutput.SelectedValue != "" && ddlValuationTypeOutput.Items.Count > 0 && ddlStorageLocationOutput.SelectedValue != "")
            {
                string query = @"select top(1) StandardPrice from Proc_MasterValuationStk where MaterialCode ='" + txtMaterialCodeOutput.Text + "' and Plant ='" + ddlPlantOutput.SelectedValue + "' and ValuationType ='" + ddlValuationTypeOutput.SelectedValue + "' and StorageLocationID ='" + ddlStorageLocationOutput.SelectedValue + "'";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(query);
                if (dtValStk.Rows.Count > 0)
                {
                    if (com.STRToDBL(dtValStk.Rows[0]["StandardPrice"].ToString()) == 0)
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Standard price is not maintained in stock for the selected combination. Please contact the administrator.", 140, 305);
                        return;
                    }
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Standard price is not maintained in stock for the selected combination. Please contact the administrator.", 140, 305);
                    return;
                }
                dtValStk = null;
            }
            //---------------------------
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItemOutput"];

            if (HidUpdateGridRecordOutput.Value == "")
            {
                if (objdtLineItem.Rows.Count > 0)
                {
                    for (int i = 0; i < objdtLineItem.Rows.Count; i++)
                    {
                        if (com.STRToInt(objdtLineItem.Rows[i]["MaterialCodeID"].ToString()) == com.STRToInt(HidMaterialIdOutput.Value)
                            && com.STRToInt(objdtLineItem.Rows[i]["ValuationTypeId"].ToString()) == com.STRToInt(ddlValuationTypeOutput.SelectedValue)
                            && com.STRToInt(objdtLineItem.Rows[i]["StorageLocationId"].ToString()) == com.STRToInt(ddlStorageLocationOutput.SelectedValue)
                            && com.STRToInt(objdtLineItem.Rows[i]["PlantId"].ToString()) == com.STRToInt(ddlPlantOutput.SelectedValue)
                            && com.STRToIntBig(objdtLineItem.Rows[i]["BatchCode"].ToString()) == com.STRToIntBig(txtBatchNoOutput.Text.Trim()))
                        {
                            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "This combination is already used. Check the line no: " + objdtLineItem.Rows[i]["LineNo"].ToString() + ". You can modify it if you need.", 140, 310);
                            return;
                        }
                    }
                }
            }

            if (com.STRToDBL(txtQuantityOutput.Text) == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be 0.", 125, 300);
                return;
            }

            if (HidUpdateGridRecordOutput.Value == "") //For Insert new record
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = com.STRToInt(HidLineNoOutput.Value);
                objdrLineItem["MaterialCodeID"] = com.STRToInt(HidMaterialIdOutput.Value);
                objdrLineItem["MaterialCode"] = txtMaterialCodeOutput.Text.Trim();
                objdrLineItem["ValuationTypeId"] = com.STRToInt(ddlValuationTypeOutput.SelectedValue);
                objdrLineItem["ValuationTypeName"] = ddlValuationTypeOutput.SelectedItem.Text;
                objdrLineItem["BatchCode"] = com.STRToIntBig(txtBatchNoOutput.Text.Trim());
                objdrLineItem["StorageLocationId"] = com.STRToInt(ddlStorageLocationOutput.SelectedValue);
                objdrLineItem["StorageLocationCode"] = ddlStorageLocationOutput.SelectedItem.Text;
                objdrLineItem["PlantId"] = com.STRToInt(ddlPlantOutput.SelectedValue);
                objdrLineItem["Quantity"] = com.STRToDBL(txtQuantityOutput.Text.Trim());
                objdrLineItem["Value"] = com.STRToDBL(txtValueOutput.Text.Trim());

                if (rbtnPreparationOutput.Checked == true)
                {
                    objdrLineItem["PreparationDilution"] = "P";
                }
                else if (rbtnDilutionOutput.Checked == true)
                {
                    objdrLineItem["PreparationDilution"] = "D";
                }
                else
                {
                    objdrLineItem["PreparationDilution"] = "";
                }
                objdrLineItem["AFlag"] = chkActiveOutput.Checked;
                objdtLineItem.Rows.Add(objdrLineItem);
            }
            else if (HidUpdateGridRecordOutput.Value == "Yes") //For Update record
            {
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["MaterialCodeID"] = com.STRToInt(HidMaterialIdOutput.Value);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["MaterialCode"] = txtMaterialCodeOutput.Text.Trim();
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["ValuationTypeId"] = com.STRToInt(ddlValuationTypeOutput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["ValuationTypeName"] = ddlValuationTypeOutput.SelectedItem.Text;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["BatchCode"] = com.STRToIntBig(txtBatchNoOutput.Text.Trim());
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["StorageLocationId"] = com.STRToInt(ddlStorageLocationOutput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["StorageLocationCode"] = ddlStorageLocationOutput.SelectedItem.Text;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["PlantId"] = com.STRToInt(ddlPlantOutput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["Quantity"] = com.STRToDBL(txtQuantityOutput.Text.Trim());
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["Value"] = com.STRToDBL(txtValueOutput.Text.Trim());

                if (rbtnPreparationOutput.Checked == true)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["PreparationDilution"] = "P";
                }
                else if (rbtnDilutionOutput.Checked == true)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["PreparationDilution"] = "D";
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["PreparationDilution"] = "";
                }
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexOutput.Value)]["AFlag"] = chkActiveOutput.Checked;
                objdtLineItem.AcceptChanges();
            }

            ViewState["LineItemOutput"] = objdtLineItem;
            int LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[0]["LineNo"].ToString());
            for (int i = 1; i < objdtLineItem.Rows.Count; i++)
            {
                if (Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                {
                    LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString());
                }
            }
            HidLineNoOutput.Value = (LineNoInGrid + 10).ToString();
            gvOutPut.DataSource = objdtLineItem;
            gvOutPut.DataBind();
            ClearLineItemRecordsOutput();
        }
        catch { }
    }

    protected void imgBtnAddLineInput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to add and update new line item in input section.
        /// </summary>
        try
        {
            if (com.STRToIntBig(txtQuantityInput.Text.Trim()) > 9999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999.99.", 125, 300);
                return;
            }
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItemInput"];

            if (HidUpdateGridRecordInput.Value == "")
            {
                if (objdtLineItem.Rows.Count > 0)
                {
                    for (int i = 0; i < objdtLineItem.Rows.Count; i++)
                    {
                        if (com.STRToInt(objdtLineItem.Rows[i]["MaterialCodeID"].ToString()) == com.STRToInt(HidMaterialIdInput.Value)
                            && com.STRToInt(objdtLineItem.Rows[i]["ValuationTypeId"].ToString()) == com.STRToInt(ddlValuationTypeInput.SelectedValue)
                            && com.STRToInt(objdtLineItem.Rows[i]["StorageLocationId"].ToString()) == com.STRToInt(ddlStorageLocationInput.SelectedValue)
                            && com.STRToInt(objdtLineItem.Rows[i]["PlantId"].ToString()) == com.STRToInt(ddlPlantInput.SelectedValue)
                            && com.STRToIntBig(objdtLineItem.Rows[i]["BatchCode"].ToString()) == com.STRToIntBig(txtBatchNoInput.Text.Trim()))
                        {
                            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "This combination is already used. Check the line no: " + objdtLineItem.Rows[i]["LineNo"].ToString() + ". You can modify it if you need.", 140, 310);
                            return;
                        }
                    }
                }
            }

            if (com.STRToDBL(txtQuantityInput.Text) == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be 0.", 125, 300);
                return;
            }

            //*******************************************************************************************************************
            //Validation for check stock
            if (com.STRToInt(HidAutoId.Value) == 0)
            {
                if (com.STRToDBL(txtQuantityInput.Text) > (com.STRToDBL(txtCurrentStockInput.Text)))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.Current stock is:" + txtCurrentStockInput.Text.Trim() + ".", 125, 300);
                    return;
                }
            }
            else if (com.STRToInt(HidAutoId.Value) > 0)
            {
                if (HidUpdateGridRecordInput.Value == "")
                {
                    if (com.STRToDBL(txtQuantityInput.Text) > (com.STRToDBL(txtCurrentStockInput.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.Current stock is:" + txtCurrentStockInput.Text.Trim() + ".", 125, 300);
                        return;
                    }
                }
                else if (HidUpdateGridRecordInput.Value == "Yes")
                {
                    double Exceededqty = com.STRToDBL(txtQuantityInput.Text.Trim()) - com.STRToDBL(HidPreInputQty.Value);
                    if ((com.STRToDBL(txtQuantityInput.Text.Trim()) - com.STRToDBL(HidPreInputQty.Value)) > (com.STRToDBL(txtCurrentStockInput.Text)))
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreInputQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                        return;
                    }
                }
            }
            //********************************************************************************************************

            if (HidUpdateGridRecordInput.Value == "") //For Insert new record
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = com.STRToInt(HidLineNoInput.Value);
                objdrLineItem["MaterialCodeID"] = com.STRToInt(HidMaterialIdInput.Value);
                objdrLineItem["MaterialCode"] = txtMaterialCodeInput.Text.Trim();
                objdrLineItem["ValuationTypeId"] = com.STRToInt(ddlValuationTypeInput.SelectedValue);
                objdrLineItem["ValuationTypeName"] = ddlValuationTypeInput.SelectedItem.Text;
                objdrLineItem["BatchCode"] = com.STRToIntBig(txtBatchNoInput.Text.Trim());
                objdrLineItem["StorageLocationId"] = com.STRToInt(ddlStorageLocationInput.SelectedValue);
                objdrLineItem["StorageLocationCode"] = ddlStorageLocationInput.SelectedItem.Text;
                objdrLineItem["PlantId"] = com.STRToInt(ddlPlantInput.SelectedValue);
                objdrLineItem["Quantity"] = com.STRToDBL(txtQuantityInput.Text.Trim());
                objdrLineItem["Value"] = com.STRToDBL(txtValueInput.Text.Trim());

                if (rbtnPreparationInput.Checked == true)
                {
                    objdrLineItem["PreparationDilution"] = "P";
                }
                else if (rbtnDilutionInput.Checked == true)
                {
                    objdrLineItem["PreparationDilution"] = "D";
                }
                else
                {
                    objdrLineItem["PreparationDilution"] = "";
                }
                objdrLineItem["AFlag"] = chkActiveInput.Checked;
                objdtLineItem.Rows.Add(objdrLineItem);
            }
            else if (HidUpdateGridRecordInput.Value == "Yes") //For Update record
            {
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["MaterialCodeID"] = com.STRToInt(HidMaterialIdInput.Value);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["MaterialCode"] = txtMaterialCodeInput.Text.Trim();
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["ValuationTypeId"] = com.STRToInt(ddlValuationTypeInput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["ValuationTypeName"] = ddlValuationTypeInput.SelectedItem.Text;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["BatchCode"] = com.STRToIntBig(txtBatchNoInput.Text.Trim());
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["StorageLocationId"] = com.STRToInt(ddlStorageLocationInput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["StorageLocationCode"] = ddlStorageLocationInput.SelectedItem.Text;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["PlantId"] = com.STRToInt(ddlPlantInput.SelectedValue);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["Quantity"] = com.STRToDBL(txtQuantityInput.Text.Trim());
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["Value"] = com.STRToDBL(txtValueInput.Text.Trim());
                if (rbtnPreparationInput.Checked == true)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["PreparationDilution"] = "P";
                }
                else if (rbtnDilutionInput.Checked == true)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["PreparationDilution"] = "D";
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["PreparationDilution"] = "";
                }
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndexInput.Value)]["AFlag"] = chkActiveInput.Checked;
                objdtLineItem.AcceptChanges();
            }

            ViewState["LineItemInput"] = objdtLineItem;
            int LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[0]["LineNo"].ToString());
            for (int i = 1; i < objdtLineItem.Rows.Count; i++)
            {
                if (Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                {
                    LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString());
                }
            }
            HidLineNoInput.Value = (LineNoInGrid + 10).ToString();
            gvInput.DataSource = objdtLineItem;
            gvInput.DataBind();
            ClearLineItemRecordsInput();
        }
        catch { }
    }

    protected void gvOutPut_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select and update the existing line item in output section.
        /// </summary>
        try
        {
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItemOutput"];

            if (e.CommandName == "select")
            {
                GridView gvOutPut = (GridView)sender;
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                gvOutPut.SelectedIndex = row.RowIndex + 1;

                foreach (GridViewRow oldrow in gvOutPut.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearLineItemRecordsOutput();

                if (objdtLineItem.Rows.Count > 0)
                {
                    int PageNo = gvOutPut.PageIndex;
                    int noOfRowinPage = gvOutPut.PageSize;
                    int rowno = (noOfRowinPage * (PageNo)) + row.RowIndex;

                    hidRowIndexOutput.Value = Convert.ToString(rowno);
                    HidUpdateGridRecordOutput.Value = "Yes";
                    HidLineNoOutput.Value = objdtLineItem.Rows[rowno]["LineNo"].ToString();

                    HidMaterialIdOutput.Value = objdtLineItem.Rows[rowno]["MaterialCodeID"].ToString();
                    txtMaterialCodeOutput.Text = objdtLineItem.Rows[rowno]["MaterialCode"].ToString();

                    BindMaterialInformation(HidMaterialIdOutput.Value, txtMaterialNameOutput, txtUOMOutput);
                    ddlPlantOutput.SelectedValue = objdtLineItem.Rows[rowno]["PlantId"].ToString();

                    FillValuation(ddlValuationTypeOutput, HidMaterialIdOutput.Value);
                    ddlValuationTypeOutput.SelectedValue = objdtLineItem.Rows[rowno]["ValuationTypeId"].ToString();

                    ddlStorageLocationOutput.SelectedValue = objdtLineItem.Rows[rowno]["StorageLocationId"].ToString();
                    txtBatchNoOutput.Text = objdtLineItem.Rows[rowno]["BatchCode"].ToString();

                    txtQuantityOutput.Text = objdtLineItem.Rows[rowno]["Quantity"].ToString();
                    HidPreOutputQty.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndexOutput.Value)]["Quantity"].ToString();
                    txtValueOutput.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndexOutput.Value)]["Value"].ToString();

                    txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();

                    if (objdtLineItem.Rows[rowno]["AFlag"].ToString() == "True")
                    {
                        chkActiveOutput.Checked = true;
                    }
                    else
                    {
                        chkActiveOutput.Checked = false;
                    }
                    if (objdtLineItem.Rows[rowno]["PreparationDilution"].ToString() == "P")
                    {
                        rbtnPreparationOutput.Checked = true;
                    }
                    else if (objdtLineItem.Rows[rowno]["PreparationDilution"].ToString() == "D")
                    {
                        rbtnDilutionOutput.Checked = true;
                    }

                    EnableDisableLineitemControlsOutput(false);
                    imgBtnAddLineOutput.ImageUrl = "../Images/btnUpdateLine.png";

                }
            }
        }
        catch { }
    }

    protected void gvInput_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select and update the existing line item in input section.
        /// </summary>
        try
        {
            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItemInput"];

            if (e.CommandName == "select")
            {
                GridView gvInput = (GridView)sender;
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                gvInput.SelectedIndex = row.RowIndex + 1;

                foreach (GridViewRow oldrow in gvInput.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearLineItemRecordsInput();

                if (objdtLineItem.Rows.Count > 0)
                {
                    int PageNo = gvInput.PageIndex;
                    int noOfRowinPage = gvInput.PageSize;
                    int rowno = (noOfRowinPage * (PageNo)) + row.RowIndex;

                    hidRowIndexInput.Value = Convert.ToString(rowno);
                    HidUpdateGridRecordInput.Value = "Yes";
                    HidLineNoInput.Value = objdtLineItem.Rows[rowno]["LineNo"].ToString();

                    HidMaterialIdInput.Value = objdtLineItem.Rows[rowno]["MaterialCodeID"].ToString();
                    txtMaterialCodeInput.Text = objdtLineItem.Rows[rowno]["MaterialCode"].ToString();

                    BindMaterialInformation(HidMaterialIdInput.Value, txtMaterialNameInput, txtUOMInput);
                    ddlPlantInput.SelectedValue = objdtLineItem.Rows[rowno]["PlantId"].ToString();

                    FillValuation(ddlValuationTypeInput, HidMaterialIdInput.Value);
                    ddlValuationTypeInput.SelectedValue = objdtLineItem.Rows[rowno]["ValuationTypeId"].ToString();
                    ddlStorageLocationInput.SelectedValue = objdtLineItem.Rows[rowno]["StorageLocationId"].ToString();
                    txtBatchNoInput.Text = objdtLineItem.Rows[rowno]["BatchCode"].ToString();

                    txtQuantityInput.Text = objdtLineItem.Rows[rowno]["Quantity"].ToString();
                    HidPreInputQty.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndexInput.Value)]["Quantity"].ToString();
                    txtValueInput.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndexInput.Value)]["Value"].ToString();

                    txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();

                    if (objdtLineItem.Rows[rowno]["AFlag"].ToString() == "True")
                    {
                        chkActiveInput.Checked = true;
                    }
                    else
                    {
                        chkActiveInput.Checked = false;
                    }
                    if (objdtLineItem.Rows[rowno]["PreparationDilution"].ToString() == "P")
                    {
                        rbtnPreparationInput.Checked = true;
                    }
                    else if (objdtLineItem.Rows[rowno]["PreparationDilution"].ToString() == "D")
                    {
                        rbtnDilutionInput.Checked = true;
                    }

                    EnableDisableLineitemControlsInput(false);
                    imgBtnAddLineInput.ImageUrl = "../Images/btnUpdateLine.png";

                }
            }
        }
        catch { }
    }

    protected void gvOutPut_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        /// <summary>
        /// This event is used to delete the existing line item in output section.
        /// </summary>
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItemOutput"];
            DataTable dtForDelete = (DataTable)ViewState["ForDeleteOutput"];

            int PageNo = gvOutPut.PageIndex;
            int noOfRowinPage = gvOutPut.PageSize;
            int rowno = (noOfRowinPage * (PageNo)) + e.RowIndex;

            DataRow drForDelete = dtForDelete.NewRow();
            drForDelete["AutoId"] = dtLineItem.Rows[rowno]["AutoId"].ToString();
            dtForDelete.Rows.Add(drForDelete);
            dtForDelete.AcceptChanges();
            ViewState["ForDeleteOutput"] = dtForDelete;

            ClearLineItemRecordsOutput();

            dtLineItem.Rows[rowno].Delete();
            dtLineItem.AcceptChanges();
            ViewState["LineItemOutput"] = dtLineItem;
            gvOutPut.DataSource = (DataTable)ViewState["LineItemOutput"];
            gvOutPut.DataBind();

            int LineNoInGrid = 0;
            DataTable dt = (DataTable)ViewState["LineItemOutput"];
            if (dt.Rows.Count > 0)
            {
                LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[0]["LineNo"].ToString());
                for (int i = 1; i < dtLineItem.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                    {
                        LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString());
                    }
                }
            }
            HidLineNoOutput.Value = (LineNoInGrid + 10).ToString();
        }
        catch { }
    }

    protected void gvInput_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        /// <summary>
        /// This event is used to delete the existing line item in input section.
        /// </summary>
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItemInput"];
            DataTable dtForDelete = (DataTable)ViewState["ForDeleteInput"];

            int PageNo = gvInput.PageIndex;
            int noOfRowinPage = gvInput.PageSize;
            int rowno = (noOfRowinPage * (PageNo)) + e.RowIndex;

            DataRow drForDelete = dtForDelete.NewRow();
            drForDelete["AutoId"] = dtLineItem.Rows[rowno]["AutoId"].ToString();
            dtForDelete.Rows.Add(drForDelete);
            dtForDelete.AcceptChanges();
            ViewState["ForDeleteInput"] = dtForDelete;

            ClearLineItemRecordsInput();

            dtLineItem.Rows[rowno].Delete();
            dtLineItem.AcceptChanges();
            ViewState["LineItemInput"] = dtLineItem;
            gvInput.DataSource = (DataTable)ViewState["LineItemInput"];
            gvInput.DataBind();

            int LineNoInGrid = 0;
            DataTable dt = (DataTable)ViewState["LineItemInput"];
            if (dt.Rows.Count > 0)
            {
                LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[0]["LineNo"].ToString());
                for (int i = 1; i < dtLineItem.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                    {
                        LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString());
                    }
                }
            }
            HidLineNoInput.Value = (LineNoInGrid + 10).ToString();
        }
        catch { }
    }

    protected void gvOutPut_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to put the preparation or dilution in every grid line in output section depend upon the selection.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label LPreparationDilution = (Label)e.Row.FindControl("LPreparationDilution");
                    if (LPreparationDilution.Text == "P")
                    {
                        LPreparationDilution.Text = "Preparation";
                    }
                    else if (LPreparationDilution.Text == "D")
                    {
                        LPreparationDilution.Text = "Dilution";
                    }
                }
            }
        }
        catch { }
    }

    protected void gvInput_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to put the preparation or dilution in every grid line in input section depend upon the selection.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label LPreparationDilution = (Label)e.Row.FindControl("LPreparationDilution");
                    if (LPreparationDilution.Text == "P")
                    {
                        LPreparationDilution.Text = "Preparation";
                    }
                    else if (LPreparationDilution.Text == "D")
                    {
                        LPreparationDilution.Text = "Dilution";
                    }
                }
            }
        }
        catch { }
    }

    protected void gvOutPut_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in grid in output section.
        /// </summary>
        try
        {
            gvOutPut.PageIndex = e.NewPageIndex;
            gvOutPut.DataSource = (DataTable)ViewState["LineItemOutput"];
            gvOutPut.DataBind();
        }
        catch { }
    }

    protected void gvInput_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in grid in input section.
        /// </summary>
        try
        {
            gvInput.PageIndex = e.NewPageIndex;
            gvInput.DataSource = (DataTable)ViewState["LineItemInput"];
            gvInput.DataBind();
        }
        catch { }
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary>         
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearHeader();
                ClearLineItemRecordsOutput();
                ClearLineItemRecordsInput();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderAndGridRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary> 
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllCPEntryList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary> 
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllCPEntryList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void imgBtnMaterialCodeOutput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the materials for output section.
        /// </summary> 
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "MaterialOutput";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code: ";
            FillAllMaterial("Output", "");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnMaterialCodeInput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the materials for input section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "MaterialInput";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code: ";
            FillAllMaterial("Input", "");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void txtMaterialCodeOutput_TextChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to populate enterd material in output section.
        /// </summary>
        try
        {
            string query = @"select A.MaterialId,B.MaterialCode,B.MaterialDesc from tblMatMapping as A inner join Proc_MaterialMaster as B 
                          on A.MaterialId =B.AutoId where A.BatchId ='" + ddlProcessCode.SelectedValue + "' and";
            query += " A.Category ='Output' and A.AFlag =1 and B.Status =1 and B.MaterialCode = '" + txtMaterialCodeOutput.Text.Trim() + "'";

            DataTable dt = new DataTable();
            dt = com.executeSqlQry(query);

            HidMaterialIdOutput.Value = "";
            txtMaterialCodeOutput.Text = "";
            txtMaterialNameOutput.Text = "";
            txtUOMOutput.Text = "";
            ddlValuationTypeOutput.Items.Clear();

            if (dt.Rows.Count > 0)
            {
                HidMaterialIdOutput.Value = dt.Rows[0]["MaterialId"].ToString();
                txtMaterialCodeOutput.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialNameOutput.Text = dt.Rows[0]["MaterialDesc"].ToString();

                BindMaterialInformation(HidMaterialIdOutput.Value, txtMaterialNameOutput, txtUOMOutput);
                FillValuation(ddlValuationTypeOutput, HidMaterialIdOutput.Value);

                #region Reset the outputlineitems when material is changed.

                ddlPlantOutput.SelectedIndex = 0;
                ddlStorageLocationOutput.SelectedIndex = 0;
                txtBatchNoOutput.Text = "0";
                txtQuantityOutput.Text = "0";
                txtValueOutput.Text = "0";
                txtCurrentStockOutput.Text = "0";

                #endregion

                txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                    ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();

                if (!IsNotBatchIndicator(txtMaterialCodeOutput.Text))
                {
                    imgBtnBatchNoOutput.Visible = false;
                }
                else
                {
                    imgBtnBatchNoOutput.Visible = true;
                }
            }
            else
            {
                try
                {
                    txtSearchFromPopup.Text = "";
                    HidPopUpType.Value = "MaterialOutput";
                    lPopUpHeader.Text = "Material Master";
                    lSearch.Text = "Search By Material Code: ";
                    FillAllMaterial("Output", "");
                    ModalPopupExtender2.Show();
                }
                catch { }
            }
        }
        catch { }
    }

    protected void txtMaterialCodeInput_TextChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to populate enterd material in input section.
        /// </summary>
        try
        {
            string query = @"select A.MaterialId,B.MaterialCode,B.MaterialDesc from tblMatMapping as A inner join Proc_MaterialMaster as B 
                          on A.MaterialId =B.AutoId where A.BatchId ='" + ddlProcessCode.SelectedValue + "' and";
            query += " A.Category ='Input' and A.AFlag =1 and B.Status =1 and B.MaterialCode = '" + txtMaterialCodeInput.Text.Trim() + "'";

            DataTable dt = new DataTable();
            dt = com.executeSqlQry(query);

            HidMaterialIdInput.Value = "";
            txtMaterialCodeInput.Text = "";
            txtMaterialNameInput.Text = "";
            txtUOMInput.Text = "";
            ddlValuationTypeInput.Items.Clear();

            if (dt.Rows.Count > 0)
            {
                HidMaterialIdInput.Value = dt.Rows[0]["MaterialId"].ToString();
                txtMaterialCodeInput.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialNameInput.Text = dt.Rows[0]["MaterialDesc"].ToString();

                BindMaterialInformation(HidMaterialIdInput.Value, txtMaterialNameInput, txtUOMInput);
                FillValuation(ddlValuationTypeInput, HidMaterialIdInput.Value);

                #region Reset the inputlineitems when material is changed.

                ddlPlantInput.SelectedIndex = 0;
                ddlStorageLocationInput.SelectedIndex = 0;
                txtBatchNoInput.Text = "0";
                txtQuantityInput.Text = "0";
                txtValueInput.Text = "0";
                txtCurrentStockInput.Text = "0";

                #endregion

                txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                    ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();

                if (!IsNotBatchIndicator(txtMaterialCodeInput.Text))
                {
                    imgBtnBatchNoInput.Visible = false;
                }
                else
                {
                    imgBtnBatchNoInput.Visible = true;
                }
            }
            else
            {
                try
                {
                    txtSearchFromPopup.Text = "";
                    HidPopUpType.Value = "MaterialInput";
                    lPopUpHeader.Text = "Material Master";
                    lSearch.Text = "Search By Material Code: ";
                    FillAllMaterial("Input", "");
                    ModalPopupExtender2.Show();
                }
                catch { }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "MaterialOutput")
                {
                    HidMaterialIdOutput.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtMaterialCodeOutput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    txtMaterialNameOutput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;

                    BindMaterialInformation(HidMaterialIdOutput.Value, txtMaterialNameOutput, txtUOMOutput);
                    FillValuation(ddlValuationTypeOutput, HidMaterialIdOutput.Value);

                    #region Reset the outputlineitems when material is changed.

                    ddlPlantOutput.SelectedIndex = 0;
                    ddlStorageLocationOutput.SelectedIndex = 0;
                    txtBatchNoOutput.Text = "0";
                    txtQuantityOutput.Text = "0";
                    txtValueOutput.Text = "0";
                    txtCurrentStockOutput.Text = "0";

                    #endregion

                    txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();

                    if (!IsNotBatchIndicator(txtMaterialCodeOutput.Text))
                    {
                        imgBtnBatchNoOutput.Visible = false;
                    }
                    else
                    {
                        imgBtnBatchNoOutput.Visible = true;
                    }
                }
                else if (HidPopUpType.Value == "MaterialInput")
                {
                    HidMaterialIdInput.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtMaterialCodeInput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    txtMaterialNameInput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;

                    BindMaterialInformation(HidMaterialIdInput.Value, txtMaterialNameInput, txtUOMInput);
                    FillValuation(ddlValuationTypeInput, HidMaterialIdInput.Value);

                    #region Reset the inputlineitems when material is changed.

                    ddlPlantInput.SelectedIndex = 0;
                    ddlStorageLocationInput.SelectedIndex = 0;
                    txtBatchNoInput.Text = "0";
                    txtQuantityInput.Text = "0";
                    txtValueInput.Text = "0";
                    txtCurrentStockInput.Text = "0";

                    #endregion

                    txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();

                    if (!IsNotBatchIndicator(txtMaterialCodeInput.Text))
                    {
                        imgBtnBatchNoInput.Visible = false;
                    }
                    else
                    {
                        imgBtnBatchNoInput.Visible = true;
                    }
                }
                else if (HidPopUpType.Value == "StorageLocationOutput")
                {
                    ddlStorageLocationOutput.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    #region Reset the output fields.

                    txtQuantityOutput.Text = "0";
                    txtValueOutput.Text = "0";
                    txtCurrentStockOutput.Text = "0";
                    txtBatchNoOutput.Text = "0";
                    #endregion
                    #region Check the stock when storage location is changed

                    txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();

                    #endregion ======================
                }
                else if (HidPopUpType.Value == "StorageLocationInput")
                {
                    ddlStorageLocationInput.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    #region Reset the Input fields.

                    txtQuantityInput.Text = "0";
                    txtValueInput.Text = "0";
                    txtCurrentStockInput.Text = "0";
                    txtBatchNoInput.Text = "0";
                    #endregion
                    #region Check the stock when storage location is changed

                    txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();

                    #endregion ======================
                }
                else if (HidPopUpType.Value == "BatchNoOutput")
                {
                    txtBatchNoOutput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    #region Reset the output fields.

                    txtQuantityOutput.Text = "0";
                    txtValueOutput.Text = "0";
                    txtCurrentStockOutput.Text = "0";

                    #endregion
                    #region Check the stock when storage location is changed

                    txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();

                    #endregion ======================
                }
                else if (HidPopUpType.Value == "BatchNoInput")
                {
                    txtBatchNoInput.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    #region Reset the Input fields.

                    txtQuantityInput.Text = "0";
                    txtValueInput.Text = "0";
                    txtCurrentStockInput.Text = "0";

                    #endregion
                    #region Check the stock when storage location is changed

                    txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();

                    #endregion ======================
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (HidPopUpType.Value != "BatchNoOutput" && HidPopUpType.Value != "BatchNoInput")
                {
                    e.Row.Cells[1].Style.Add("display", "none");
                }
            }
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "MaterialOutput")
            {
                FillAllMaterial("Output", txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "MaterialInput")
            {
                FillAllMaterial("Input", txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationOutput")
            {
                FillAllStorageLocation(ddlPlantOutput, txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationInput")
            {
                FillAllStorageLocation(ddlPlantInput, txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNoOutput")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim(), ddlStorageLocationOutput.SelectedValue, ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue,
                txtMaterialCodeOutput.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNoInput")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim(), ddlStorageLocationInput.SelectedValue, ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue,
                txtMaterialCodeInput.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "MaterialOutput")
            {
                FillAllMaterial("Output", txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "MaterialInput")
            {
                FillAllMaterial("Input", txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationOutput")
            {
                FillAllStorageLocation(ddlPlantOutput, txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationInput")
            {
                FillAllStorageLocation(ddlPlantInput, txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNoOutput")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim(), ddlStorageLocationOutput.SelectedValue, ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue,
                txtMaterialCodeOutput.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNoInput")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim(), ddlStorageLocationInput.SelectedValue, ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue,
                txtMaterialCodeInput.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnStorageLocationOutput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the storage location popup for output section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationOutput";
            lPopUpHeader.Text = "Storage Location Master";
            lSearch.Text = "Search By Code: ";
            FillAllStorageLocation(ddlPlantOutput, "");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnStorageLocationInput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the storage location popup for input section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationInput";
            lPopUpHeader.Text = "Storage Location Master";
            lSearch.Text = "Search By Code: ";
            FillAllStorageLocation(ddlPlantInput, "");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnBatchNoOutput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the batch popup for output section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNoOutput";
            lPopUpHeader.Text = "Batch Master";
            lSearch.Text = "Search By Batch: ";
            FillAllBatch("", ddlStorageLocationOutput.SelectedValue, ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue,
                txtMaterialCodeOutput.Text.Trim());
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnBatchNoInput_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the batch popup for input section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNoInput";
            lPopUpHeader.Text = "Batch Master";
            lSearch.Text = "Search By Batch: ";
            FillAllBatch("", ddlStorageLocationInput.SelectedValue, ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue,
                txtMaterialCodeInput.Text.Trim());
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void ddlValuationTypeOutput_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            #region Reset the output fields.

            txtQuantityOutput.Text = "0";
            txtValueOutput.Text = "0";
            txtCurrentStockOutput.Text = "0";
            txtBatchNoOutput.Text = "0";
            #endregion
            txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();
        }
        catch { }
    }

    protected void ddlValuationTypeInput_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            #region Reset the Input fields.

            txtQuantityInput.Text = "0";
            txtValueInput.Text = "0";
            txtCurrentStockInput.Text = "0";
            txtBatchNoInput.Text = "0";
            #endregion
            txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();
        }
        catch { }
    }

    protected void ddlStorageLocationOutput_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            #region Reset the output fields.

            txtQuantityOutput.Text = "0";
            txtValueOutput.Text = "0";
            txtCurrentStockOutput.Text = "0";
            txtBatchNoOutput.Text = "0";
            #endregion
            txtCurrentStockOutput.Text = CheckForQuantity_InStock(HidMaterialIdOutput.Value, ddlStorageLocationOutput.SelectedValue,
                        ddlPlantOutput.SelectedValue, ddlValuationTypeOutput.SelectedValue, txtBatchNoOutput.Text.Trim()).ToString();
        }
        catch { }
    }

    protected void ddlStorageLocationInput_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            #region Reset the Input fields.

            txtQuantityInput.Text = "0";
            txtValueInput.Text = "0";
            txtCurrentStockInput.Text = "0";
            txtBatchNoInput.Text = "0";
            #endregion
            txtCurrentStockInput.Text = CheckForQuantity_InStock(HidMaterialIdInput.Value, ddlStorageLocationInput.SelectedValue,
                        ddlPlantInput.SelectedValue, ddlValuationTypeInput.SelectedValue, txtBatchNoInput.Text.Trim()).ToString();
        }
        catch { }
    }

    protected void txtQuantityOutput_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (com.STRToIntBig(txtQuantityOutput.Text.Trim()) > 9999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999.99.", 125, 300);
                return;
            }
            //Added by satish on 18 July-13
            if (txtQuantityOutput.Text != "" && HidMaterialIdOutput.Value != "" && ddlPlantOutput.SelectedValue != "" && ddlValuationTypeOutput.Items.Count > 0 && ddlStorageLocationOutput.SelectedValue != "")
            {
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string query = @"select top(1) StandardPrice from Proc_MasterValuationStk where MaterialCode ='" + txtMaterialCodeOutput.Text + "' and Plant ='" + ddlPlantOutput.SelectedValue + "' and ValuationType ='" + ddlValuationTypeOutput.SelectedValue + "' and StorageLocationID ='" + ddlStorageLocationOutput.SelectedValue + "'";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(query);
                if (dtValStk.Rows.Count > 0)
                {
                    if (com.STRToDBL(dtValStk.Rows[0]["StandardPrice"].ToString()) > 0)
                    {
                        MaterialRate = com.STRToDBL(dtValStk.Rows[0]["StandardPrice"].ToString());
                    }
                    else
                    {
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Standard price is not maintained in stock for the selected combination. Please contact the administrator.", 140, 305);
                        return;
                    }
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Standard price is not maintained in stock for the selected combination. Please contact the administrator.", 140, 305);
                    return;
                }
                //---------------------------
                MaterialValue = Math.Round((Convert.ToDouble(txtQuantityOutput.Text.Trim()) * MaterialRate), 2);
                txtValueOutput.Text = Convert.ToString(MaterialValue);
            }
        }
        catch { }
    }

    protected void txtQuantityInput_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (com.STRToIntBig(txtQuantityInput.Text.Trim()) > 9999999999.99)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 9999999999.99.", 125, 300);
                return;
            }
            //*******************************************************************************************************************
            //Validation for check stock
            if (com.STRToInt(HidAutoId.Value) == 0)
            {
                if (com.STRToDBL(txtQuantityInput.Text) > (com.STRToDBL(txtCurrentStockInput.Text)))
                {
                    txtQuantityInput.Text = "0";
                    txtValueInput.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.Current stock is:" + txtCurrentStockInput.Text.Trim() + ".", 125, 300);
                    return;
                }

                DataTable dt = (DataTable)ViewState["LineItemInput"];
                double Quantity = 0.00, AddedQuantity = 0.00;
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Select("MaterialCode='" + txtMaterialCodeInput.Text + "' AND PlantId=" + ddlPlantInput.SelectedValue + " AND StorageLocationId=" + ddlStorageLocationInput.SelectedValue))
                    {
                        Quantity = com.STRToDBL(row["Quantity"].ToString());
                        AddedQuantity = Quantity + AddedQuantity;
                    }
                }
                if (!IsQuantityValid(com.STRToDBL(txtCurrentStockInput.Text), com.STRToDBL(txtQuantityInput.Text), AddedQuantity))
                {
                    txtQuantityInput.Text = "0";
                    txtValueInput.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                    return;
                }
            }
            else if (com.STRToInt(HidAutoId.Value) > 0)
            {
                if (HidUpdateGridRecordInput.Value == "")
                {
                    if (com.STRToDBL(txtQuantityInput.Text) > (com.STRToDBL(txtCurrentStockInput.Text)))
                    {
                        txtQuantityInput.Text = "0";
                        txtValueInput.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.Current stock is:" + txtCurrentStockInput.Text.Trim() + ".", 125, 300);
                        return;
                    }
                }
                else if (HidUpdateGridRecordInput.Value == "Yes")
                {
                    double Exceededqty = com.STRToDBL(txtQuantityInput.Text.Trim()) - com.STRToDBL(HidPreInputQty.Value);
                    if ((com.STRToDBL(txtQuantityInput.Text.Trim()) - com.STRToDBL(HidPreInputQty.Value)) > (com.STRToDBL(txtCurrentStockInput.Text)))
                    {
                        txtQuantityInput.Text = "0";
                        txtValueInput.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, " Stock is not available for this material. Previous quantity was:" + HidPreInputQty.Value + ".Exceeded quantity is:" + Exceededqty + ".Exceeded quantity cannot be greater than available stock.", 185, 320);
                        return;
                    }
                }
            }
            //********************************************************************************************************

            if (txtQuantityInput.Text != "" && HidMaterialIdInput.Value != "" && ddlPlantInput.SelectedValue != "" && ddlValuationTypeInput.Items.Count > 0)
            {
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string Query = @"select dbo.mm_get_valuated_wa_price( '" + txtMaterialCodeInput.Text + "','" + ddlPlantInput.SelectedValue + "','" + ddlValuationTypeInput.SelectedValue + "','" + txtDocumentDate.Text + "') as MaterialRate";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(Query);
                if (dtValStk.Rows.Count > 0)
                {
                    MaterialRate = Convert.ToDouble(dtValStk.Rows[0]["MaterialRate"].ToString());
                }
                MaterialValue = Math.Round((Convert.ToDouble(txtQuantityInput.Text.Trim()) * MaterialRate), 2);
                txtValueInput.Text = Convert.ToString(MaterialValue);
            }
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>
        try
        {
            #region Line Item Records

            DataTable dtLineItemOutput = new DataTable();
            dtLineItemOutput = (DataTable)ViewState["LineItemOutput"];

            DataTable dtLineItemInput = new DataTable();
            dtLineItemInput = (DataTable)ViewState["LineItemInput"];

            if (dtLineItemOutput.Rows.Count == 0 && dtLineItemInput.Rows.Count == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Please add atleast one lineitem for output / input.", 125, 300);
                return;
            }

            #region Check Transaction event in determination table for output

            for (int i = 0; i < dtLineItemOutput.Rows.Count; i++)
            {
                string MaterialType = "", VendorAccGroupID = "", TransactionEvent = "PROD";
                DataTable dt2 = new DataTable();
                string query2 = @"select Type from Proc_MaterialMaster where MaterialCode ='" + dtLineItemOutput.Rows[i]["MaterialCode"].ToString() + "'";
                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    MaterialType = dt2.Rows[0]["Type"].ToString();
                }
                dt2 = null;

                dt2 = new DataTable();
                query2 = "";
                query2 = @"Select top 1 VendorAccGroupID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = '" + MaterialType + "'";
                query2 += " AND ValuationTypeID = '" + dtLineItemOutput.Rows[i]["ValuationTypeId"].ToString() + "' AND TransactionEvent = '" + TransactionEvent + "'";

                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    VendorAccGroupID = dt2.Rows[0]["VendorAccGroupID"].ToString();
                }
                dt2 = null;

                dt2 = new DataTable();
                query2 = "";
                query2 = @"Select top 1 Debit_GLID,Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = '" + MaterialType + "'";
                query2 += " AND ValuationTypeID = '" + dtLineItemOutput.Rows[i]["ValuationTypeId"].ToString() + "' AND";
                query2 += " VendorAccGroupID = '" + VendorAccGroupID + "' AND TransactionEvent = '" + TransactionEvent + "'";

                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    if (dt2.Rows[0]["Debit_GLID"].ToString() == "" || dt2.Rows[0]["Credit_GLID"].ToString() == "")
                    {
                        string msg = @"Either debit GL or credit GL is not defined in Line no: " + dtLineItemOutput.Rows[i]["LineNo"] + " in output section.";
                        msg += " Please contact the admin.";

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 145, 340);
                        return;
                    }
                }
                else
                {
                    string msg = @"Either debit GL or credit GL is not defined in Line no: " + dtLineItemOutput.Rows[i]["LineNo"] + " in output section.";
                    msg += " Please contact the admin.";

                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 145, 340);
                    return;
                }
                dt2 = null;
            }

            #endregion

            #region Check Transaction event in determination table for input

            for (int i = 0; i < dtLineItemInput.Rows.Count; i++)
            {
                string MaterialType = "", VendorAccGroupID = "", TransactionEvent = "GI";
                DataTable dt2 = new DataTable();
                string query2 = @"select Type from Proc_MaterialMaster where MaterialCode ='" + dtLineItemInput.Rows[i]["MaterialCode"].ToString() + "'";
                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    MaterialType = dt2.Rows[0]["Type"].ToString();
                }
                dt2 = null;

                dt2 = new DataTable();
                query2 = "";
                query2 = @"Select top 1 VendorAccGroupID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = '" + MaterialType + "'";
                query2 += " AND ValuationTypeID = '" + dtLineItemInput.Rows[i]["ValuationTypeId"].ToString() + "' AND TransactionEvent = '" + TransactionEvent + "'";

                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    VendorAccGroupID = dt2.Rows[0]["VendorAccGroupID"].ToString();
                }
                dt2 = null;

                dt2 = new DataTable();
                query2 = "";
                query2 = @"Select top 1 Debit_GLID,Credit_GLID from Com_Auto_GL_Determination_Mst Where MaterialTypeID = '" + MaterialType + "'";
                query2 += " AND ValuationTypeID = '" + dtLineItemInput.Rows[i]["ValuationTypeId"].ToString() + "' AND";
                query2 += " VendorAccGroupID = '" + VendorAccGroupID + "' AND TransactionEvent = '" + TransactionEvent + "'";

                dt2 = com.executeSqlQry(query2);
                if (dt2.Rows.Count > 0)
                {
                    if (dt2.Rows[0]["Debit_GLID"].ToString() == "" || dt2.Rows[0]["Credit_GLID"].ToString() == "")
                    {
                        string msg = @"Either debit GL or credit GL is not defined in Line no: " + dtLineItemInput.Rows[i]["LineNo"] + " in input section.";
                        msg += " Please contact the admin.";

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 135, 340);
                        return;
                    }
                }
                else
                {
                    string msg = @"Either debit GL or credit GL is not defined in Line no: " + dtLineItemInput.Rows[i]["LineNo"] + " in input section.";
                    msg += " Please contact the admin.";

                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 135, 340);
                    return;
                }
                dt2 = null;
            }

            #endregion

            #region MonthClosed for Storage Location**************************************************************

            //This will help to check for month closed for material in storage location or not.

            #region For Output Grid
            for (int i = 0; i < dtLineItemOutput.Rows.Count; i++)
            {
                string StorageLocationCode = "";
                string query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dtLineItemOutput.Rows[0]["StorageLocationId"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dtLineItemOutput.Rows[i]["PlantId"].ToString();
                    string VoucherDate = txtDocumentDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + i + " in output section.";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + i + " for the selected storage location in output section.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + i + " in output section.";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }

            #endregion

            #region For Input Grid
            for (int i = 0; i < dtLineItemInput.Rows.Count; i++)
            {
                string StorageLocationCode = "", query1 = "";
                query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dtLineItemInput.Rows[0]["StorageLocationId"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dtLineItemInput.Rows[i]["PlantId"].ToString();
                    string VoucherDate = txtDocumentDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + i + " in input section.";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + i + " for the selected storage location in input section.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + i + " in input section.";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }

            #endregion

            #endregion***********************************************************************************

            DataTable dtForDeleteOutput = new DataTable();
            dtForDeleteOutput = (DataTable)ViewState["ForDeleteOutput"];

            DataTable dtForDeleteInput = new DataTable();
            dtForDeleteInput = (DataTable)ViewState["ForDeleteInput"];

            #endregion

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@DocumentNoExist", SqlDbType.VarChar).Value = txtDocumentNo.Text.Trim();
            cmd.Parameters.Add("@ChProcessCode", SqlDbType.VarChar).Value = ddlProcessCode.SelectedValue;
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();
            if (txtDocumentDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@DocumentDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtDocumentDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@DocumentDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            cmd.Parameters.Add("@Concentration", SqlDbType.Float).Value = com.STRToDBL(txtConcentration.Text.Trim());
            cmd.Parameters.Add("@Moisture", SqlDbType.Float).Value = com.STRToDBL(txtMoisture.Text.Trim());

            cmd.Parameters.Add("@AFlag", SqlDbType.Bit).Value = chkBoxActiveHeader.Checked;
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());

            #region Table Parameter

            cmd.Parameters.AddWithValue("@dtLineItemOutput", dtLineItemOutput);
            cmd.Parameters.AddWithValue("@dtLineItemInput", dtLineItemInput);

            cmd.Parameters.AddWithValue("@dtDeleteOutput", dtForDeleteOutput);
            cmd.Parameters.AddWithValue("@dtDeleteInput", dtForDeleteInput);

            #endregion

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewDocumentNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewDocumentNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblCPEntry";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewDocumentNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Document No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();
                ClearLineItemRecordsOutput();
                ClearLineItemRecordsInput();
                BindChCPEntryDetails("Output", gvOutPut);
                BindChCPEntryDetails("Input", gvInput);

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Document No", "DocumentNo"));
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no depend upon the selected master batch type.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            if (ddlProcessCode.SelectedValue == "5")
            {
                inv_no = "CP" + financialYear + inv_series.ToString().PadLeft(5, '0');
            }
            else if (ddlProcessCode.SelectedValue == "6")
            {
                inv_no = "BP" + financialYear + inv_series.ToString().PadLeft(5, '0');
            }

        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {

            string sql = @"select  MAX(Series) from tblCPEntryHeader where [VoucherYear]='" + fin_yr + "' and ChProcessCode='" + ddlProcessCode.SelectedValue + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }
        return piseries;
    }

    protected void FillAllMaterial(string Category, string Searchtext)
    {
        /// <summary>
        /// This method is used to get all materials and fill in popup grid depend upon the category i.e output or input.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select A.MaterialId,B.MaterialCode,B.MaterialDesc from tblMatMapping as A inner join Proc_MaterialMaster as B 
                          on A.MaterialId =B.AutoId where A.BatchId ='" + ddlProcessCode.SelectedValue + "' and";
            sql += " A.Category ='" + Category + "' and A.AFlag =1 and B.Status =1 and B.MaterialCode like '%" + Searchtext + "%'";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    protected void BindMaterialInformation(string MaterialAutoId, TextBox txtMaterialName, TextBox txtUOM)
    {
        /// <summary>
        /// This method is used to get material information depend upon the material selection.
        /// </summary>
        try
        {
            txtMaterialName.Text = "";
            txtUOM.Text = "";
            string sql = @"select MaterialDesc,B.Code  from Proc_MaterialMaster as A inner join Proc_UOM_Master as B on A.UOMId = B.AutoId
                          where A.AutoId ='" + MaterialAutoId + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                txtMaterialName.Text = dt.Rows[0]["MaterialDesc"].ToString();
                txtUOM.Text = dt.Rows[0]["Code"].ToString();
            }
            dt = null;
        }
        catch { }
    }

    protected void BindPlant(DropDownList ddlPlant)
    {
        /// <summary>
        /// This method is used to get the plant.
        /// </summary>
        try
        {
            ddlPlant.Items.Clear();
            DataTable dt = new DataTable();
            string query = @" SELECT autoid,(PlantCode+' - '+PlantName) as PlantCode FROM COM_PLANT_MST where ActiveStatus =1";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                ddlPlant.DataSource = dt;
                ddlPlant.DataTextField = "PlantCode";
                ddlPlant.DataValueField = "autoid";
                ddlPlant.DataBind();
            }
        }
        catch { }
    }

    protected void FillValuation(DropDownList ddlValuation, string MaterialAutoId)
    {
        /// <summary>
        /// This method is used to get valuation depend upon the material.
        /// </summary>
        try
        {
            ddlValuation.Items.Clear();
            DataTable dt = new DataTable();
            string sql = @"select AutoId,ValuationType from Proc_ValuationClass_Master where Status=1 and MaterialType =(SELECT Type FROM
                           Proc_MaterialMaster where AutoId ='" + MaterialAutoId + "')";
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddlValuation.Items.Add(new ListItem(row["ValuationType"].ToString(), row["AutoId"].ToString()));
                }
            }
        }
        catch { }
    }

    protected void BindStorageLocation(DropDownList ddlPlant, DropDownList ddlStorageLocation)
    {
        /// <summary>
        /// This method is used to get all the storage location and fill in drop down depend upon the plant.
        /// </summary>
        try
        {
            ddlStorageLocation.Items.Clear();
            DataTable dtlocation = new DataTable();
            string sql = @"select autoid,(StorageLocCode +' - '+ Location) as CodeName from Prod_StorageLocation_Mst where
                           PlantId ='" + ddlPlant.SelectedValue + "' and Status =1";

            dtlocation = com.executeSqlQry(sql);

            if (dtlocation.Rows.Count > 0)
            {
                ddlStorageLocation.DataSource = dtlocation;
                ddlStorageLocation.DataTextField = "CodeName";
                ddlStorageLocation.DataValueField = "autoid";
                ddlStorageLocation.DataBind();
            }
        }
        catch { }
    }

    protected void FillAllStorageLocation(DropDownList ddlPlant, string Searchtext)
    {
        /// <summary>
        /// This method is used to get all the storage location and fill in popup grid depend upon the plant.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select autoid,(StorageLocCode +' - '+ Location) as CodeName from Prod_StorageLocation_Mst where
                           PlantId ='" + ddlPlant.SelectedValue + "' and Status =1 and StorageLocCode like '%" + Searchtext + "%'";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    protected void FillAllBatch(string Searchtext, string storagelocationid, string plant, string ValuationTypeid, string materialcode)
    {
        /// <summary>
        /// This method is used to get all the batch and fill in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans where Plant='" + plant + "' and";
            sql += " StorageLocation='" + GetStorageLocationCodeById(storagelocationid) + "' and MaterialCode='"
                                      + materialcode + "' and ValuationType='" + ValuationTypeid
                                      + "' and activestatus=1 and (BatchNo like '%" + Searchtext + "%' or BatchNo like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    protected void BindChCPEntryDetails(string Category, GridView gridview)
    {
        /// <summary>
        /// This method is used to get all the detail records in from the database in each section i.e output or input
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT 
                           [AutoId]
                          ,[LineNo]
                          ,[MaterialCodeID]
                          ,(select MaterialCode from Proc_MaterialMaster where AutoId =A.MaterialCodeID) as MaterialCode
                          ,[ValuationTypeId]
                          ,(select ValuationType from Proc_ValuationClass_Master where AutoId =A.ValuationTypeId) as ValuationTypeName
                          ,[BatchCode]
                          ,[StorageLocationId]
                          ,(select StorageLocCode from Prod_StorageLocation_Mst where autoid =A.StorageLocationId) as StorageLocationCode
                          ,[PlantId]
                          ,[Quantity]
                          ,[Value]
                          ,[PreparationDilution]
                          ,[AFlag]
                      FROM [tblCPEntryDetails] as A where [Category] ='" + Category + "' and DocAutoId='" + HidAutoId.Value + "'";
            dt = com.executeSqlQry(query);

            string sql = @"SELECT [AutoId] FROM [tblCPEntryDetails] as A where [Category] ='" + Category + "' and DocAutoId='0'";
            DataTable dtdelete = new DataTable();
            dtdelete = com.executeSqlQry(sql);

            if (Category == "Output")
            {
                ViewState["LineItemOutput"] = dt;
                ViewState["ForDeleteOutput"] = dtdelete;

                if (dt.Rows.Count > 0)
                {
                    int TotalRows = dt.Rows.Count;
                    HidLineNoOutput.Value = (Convert.ToInt32(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
                }
                else
                {
                    HidLineNoOutput.Value = "10";
                }
            }
            else if (Category == "Input")
            {
                ViewState["LineItemInput"] = dt;
                ViewState["ForDeleteInput"] = dtdelete;

                if (dt.Rows.Count > 0)
                {
                    int TotalRows = dt.Rows.Count;
                    HidLineNoInput.Value = (Convert.ToInt32(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
                }
                else
                {
                    HidLineNoInput.Value = "10";
                }
            }

            gridview.DataSource = dt;
            gridview.DataBind();

            dt = null;
            dtdelete = null;
        }
        catch { }
    }

    protected void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            ddlProcessCode.SelectedIndex = 0;
            txtDocumentDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

            FillFinancialYear();
            txtDocumentNo.Text = AutogenerateNo(txtYear.Text);
            txtMoisture.Text = "0";
            txtConcentration.Text = "0";
            chkBoxActiveHeader.Checked = true;
            ddlProcessCode.Enabled = true;
            TabContainer1.ActiveTabIndex = 0;
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    protected void ClearLineItemRecordsOutput()
    {
        /// <summary>
        /// This method is used to clear all the lineitem records in output section.
        /// </summary>
        try
        {
            HidUpdateGridRecordOutput.Value = "";
            hidRowIndexOutput.Value = "";

            HidMaterialIdOutput.Value = "";
            txtMaterialCodeOutput.Text = "";
            txtMaterialNameOutput.Text = "";
            txtUOMOutput.Text = "";
            ddlPlantOutput.SelectedIndex = 0;
            ddlValuationTypeOutput.Items.Clear();
            ddlStorageLocationOutput.SelectedIndex = 0;
            txtBatchNoOutput.Text = "0";
            imgBtnBatchNoOutput.Visible = true;

            txtQuantityOutput.Text = "0";
            txtCurrentStockOutput.Text = "0";
            txtValueOutput.Text = "0";
            HidPreOutputQty.Value = "0";

            chkActiveOutput.Checked = true;
            rbtnPreparationOutput.Checked = false;
            rbtnDilutionOutput.Checked = false;

            EnableDisableLineitemControlsOutput(true);
            imgBtnAddLineOutput.ImageUrl = "../Images/btnAddLinegreen.png";
        }
        catch { }
    }

    protected void ClearLineItemRecordsInput()
    {
        /// <summary>
        /// This method is used to clear all the lineitem records in input section.
        /// </summary>
        try
        {
            HidUpdateGridRecordInput.Value = "";
            hidRowIndexInput.Value = "";

            HidMaterialIdInput.Value = "";
            txtMaterialCodeInput.Text = "";
            txtMaterialNameInput.Text = "";
            txtUOMInput.Text = "";

            ddlPlantInput.SelectedIndex = 0;
            ddlValuationTypeInput.Items.Clear();
            ddlStorageLocationInput.SelectedIndex = 0;
            txtBatchNoInput.Text = "0";
            imgBtnBatchNoInput.Visible = true;

            txtQuantityInput.Text = "0";
            txtCurrentStockInput.Text = "0";
            txtValueInput.Text = "0";
            HidPreInputQty.Value = "0";

            chkActiveInput.Checked = true;
            rbtnPreparationInput.Checked = false;
            rbtnDilutionInput.Checked = false;

            EnableDisableLineitemControlsInput(true);
            imgBtnAddLineInput.ImageUrl = "../Images/btnAddLinegreen.png";
        }
        catch { }
    }

    private void GetAllCPEntryList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the master batch list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT A.[AutoId]      
                          ,B.ChMstBatchDesc
                          ,[DocumentNo]
                          ,[VoucherYear]
                          ,CONVERT(VARCHAR(11), [DocumentDate], 101) as [DocumentDate] 
                          ,CONVERT(VARCHAR(11), [PostingDate] , 101) as [PostingDate]     
                      FROM [tblCPEntryHeader] as A inner join tblChMstMasterBatch as B on A.ChProcessCode= cast(B.AutoId as nvarchar) 
                      where DocumentNo like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    public string GetStorageLocationCodeById(string id)
    {
        try
        {
            string str = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid='" + id + "' and Status =1";
            DataTable dtstr = com.executeSqlQry(str);
            if (dtstr != null && dtstr.Rows.Count > 0)
            {
                return dtstr.Rows[0]["StorageLocCode"].ToString();
            }
        }
        catch { }
        return "";
    }

    private void BindHeaderAndGridRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [ChProcessCode]
                            ,[DocumentNo]
                            ,[VoucherYear]
                            ,CONVERT(VARCHAR(11), [DocumentDate], 101) as [DocumentDate]
                            ,CONVERT(VARCHAR(11), [PostingDate] , 101) as [PostingDate]                           
                            ,[Concentration]
                            ,[Moisture]
                            ,[AFlag]
                        FROM [tblCPEntryHeader] where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                ddlProcessCode.SelectedValue = dt.Rows[0]["ChProcessCode"].ToString();
                txtDocumentDate.Text = dt.Rows[0]["DocumentDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();
                txtDocumentNo.Text = dt.Rows[0]["DocumentNo"].ToString();
                txtMoisture.Text = dt.Rows[0]["Moisture"].ToString();
                txtConcentration.Text = dt.Rows[0]["Concentration"].ToString();
                if (dt.Rows[0]["AFlag"].ToString() == "True")
                {
                    chkBoxActiveHeader.Checked = true;
                }
                else
                {
                    chkBoxActiveHeader.Checked = false;
                }

                ddlProcessCode.Enabled = false;

                #region Bind Line Items

                BindChCPEntryDetails("Output", gvOutPut);
                BindChCPEntryDetails("Input", gvInput);

                #endregion

                dt = null;
            }
        }
        catch { }
    }

    private double CheckForQuantity_InStock(string materialid, string storagelocationid, string plant, string ValuationTypeid, string BatchNo)
    {
        /// <summary>
        /// This method is used to check the quantity in stock.
        /// </summary>
        double TotalQuantityOnStock = 0.0;
        string str = "";

        if (BatchNo == "0")
        {
            str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
                        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and Plant='" + plant + "' and ValuationType='" + ValuationTypeid + "'";
            DataTable dtquantity = com.executeSqlQry(str);
            if (dtquantity != null && dtquantity.Rows.Count > 0)
            {
                TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
            }
        }
        else if (BatchNo != "0")
        {
            DataTable dt = new DataTable();
            if (materialid != "")
            {
                string sql = @"Select (QuantityAcceptedStockUOM -(case when BatchQtyConsumed Is null then 0 else BatchQtyConsumed end)) as StockQuantity
                        From Proc_GoodsReceipt_OtherDetails_Trans where MaterialCode =(select MaterialCode COLLATE SQL_Latin1_General_CP1_CI_AS from Proc_MaterialMaster 
                        where autoid  =" + materialid + " ) and	ActiveStatus = 1 And StorageLocation =(select StorageLocCode COLLATE SQL_Latin1_General_CP1_CI_AS";
                sql += " from Prod_StorageLocation_Mst where autoid =" + storagelocationid + ") And Plant = '"
                    + plant + "' and ValuationType ='" + ValuationTypeid + "' and BatchNo ='" + BatchNo + "'";

                dt = com.executeSqlQry(sql);
                if (dt.Rows.Count > 0)
                {
                    TotalQuantityOnStock = com.STRToDBL(dt.Rows[0]["StockQuantity"].ToString());
                }
            }
        }
        return TotalQuantityOnStock;
    }

    private bool IsNotBatchIndicator(string materialcode)
    {
        /// <summary>
        /// This method is used to check the batch indicator of selected material.
        /// </summary>
        /// 
        string str = "select BatchIndicator from Proc_MaterialMaster where MaterialCode='" + materialcode + "'";
        bool IsBatchIndicator = false;
        DataTable dtstr = com.executeSqlQry(str);
        if (dtstr != null && dtstr.Rows.Count > 0)
        {
            if (dtstr.Rows[0]["BatchIndicator"].ToString() == "True")
            {
                IsBatchIndicator = true;
            }
        }
        return IsBatchIndicator;
    }

    public bool IsQuantityValid(double availablequantity, double inputquantity, double AddedQuantity)
    {
        /// <summary>
        /// This method is used to check weither quantity is valid or not.
        /// </summary>
        /// 
        if ((inputquantity + AddedQuantity) > availablequantity)
            return false;
        else return true;
    }

    protected void EnableDisableLineitemControlsOutput(bool type)
    {
        try
        {
            txtMaterialCodeOutput.Enabled = type;
            ddlPlantOutput.Enabled = type;
            ddlValuationTypeOutput.Enabled = type;
            ddlStorageLocationOutput.Enabled = type;
            imgBtnMaterialCodeOutput.Enabled = type;
            imgBtnStorageLocationOutput.Enabled = type;
            imgBtnBatchNoOutput.Enabled = type;
        }
        catch { }
    }

    protected void EnableDisableLineitemControlsInput(bool type)
    {
        try
        {
            txtMaterialCodeInput.Enabled = type;
            ddlPlantInput.Enabled = type;
            ddlValuationTypeInput.Enabled = type;
            ddlStorageLocationInput.Enabled = type;
            imgBtnMaterialCodeInput.Enabled = type;
            imgBtnStorageLocationInput.Enabled = type;
            imgBtnBatchNoInput.Enabled = type;
        }
        catch { }
    }

    #endregion
}