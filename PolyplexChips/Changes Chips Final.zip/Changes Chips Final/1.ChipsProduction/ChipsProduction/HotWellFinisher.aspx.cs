﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================
        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "Hot Well Finisher";

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();

                string CurrentTime = DateTime.Now.ToString("HH:mm");
                string[] TimeIndex = CurrentTime.Split(':');
                txtTimeHrUPR3.Text = TimeIndex[0];
                txtTimeMinUPR3.Text = TimeIndex[1];
                txtTimeHrFinisher.Text = TimeIndex[0];
                txtTimeMinFinisher.Text = TimeIndex[1];

                #region Change Color and Readonly Fields

                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                txtYear.Attributes.Add("style", "background:lightgray");
                txtVoucherDate.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");

                txtVoucherNo.Attributes.Add("readonly", "true");
                txtYear.Attributes.Add("readonly", "true");
                txtVoucherDate.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");

                #endregion

                txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>
        try
        {
            ClearHeader();

            txtSearchList.Text = "";
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllHotWellFinisherList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary>
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearHeader();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllHotWellFinisherList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllHotWellFinisherList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>

        if (txtTimeHrUPR3.Text == "" || txtTimeMinUPR3.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Time in UPR-3 is mandatory.", 125, 300);
            return;
        }
        if (txtTimeHrFinisher.Text == "" || txtTimeMinFinisher.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Time in Finisher is mandatory.", 125, 300);
            return;
        }
        if (com.STRToInt(txtTimeHrUPR3.Text.Trim()) > 23)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Hrs in time (UPR-3) cannot be greater than 23.", 125, 300);
            return;
        }
        if (com.STRToInt(txtTimeMinUPR3.Text.Trim()) > 59)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Mins in time (UPR-3) cannot be greater than 59.", 125, 300);
            return;
        }

        if (com.STRToInt(txtTimeHrFinisher.Text.Trim()) > 23)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Hrs in time (Finisher) cannot be greater than 23.", 125, 300);
            return;
        }
        if (com.STRToInt(txtTimeMinFinisher.Text.Trim()) > 59)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Mins in time (Finisher) cannot be greater than 59.", 125, 300);
            return;
        }
        if (txtRemarksUPR3.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Remarks in UPR-3 is mandatory.", 125, 300);
            return;
        }
        if (txtRemarksFinisher.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Remarks in Finisher is mandatory.", 125, 300);
            return;
        }        

        try
        {
            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();
            if (txtVoucherDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtVoucherDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtTimeHrUPR3.Text.Trim().Length < 2)
            {
                int uy = txtTimeHrUPR3.Text.Trim().Length;
                txtTimeHrUPR3.Text = uy == 0 ? "00" : "0" + txtTimeHrUPR3.Text.Trim();
            }
            if (txtTimeMinUPR3.Text.Trim().Length < 2)
            {
                int uy = txtTimeMinUPR3.Text.Trim().Length;
                txtTimeMinUPR3.Text = uy == 0 ? "00" : "0" + txtTimeMinUPR3.Text.Trim();
            }

            cmd.Parameters.Add("@TimeHWU", SqlDbType.VarChar).Value = txtTimeHrUPR3.Text.Trim() + ":" + txtTimeMinUPR3.Text.Trim();
            cmd.Parameters.Add("@MoistureHWU", SqlDbType.Float).Value = com.STRToDBL(txtMoistureUPR3.Text.Trim());
            cmd.Parameters.Add("@SolidHWU", SqlDbType.Float).Value = com.STRToDBL(txtSolidUPR3.Text.Trim());
            cmd.Parameters.Add("@AldehydeHWU", SqlDbType.Float).Value = com.STRToDBL(txtAldehydeUPR3.Text.Trim());
            cmd.Parameters.Add("@RemarksHWU", SqlDbType.VarChar).Value = txtRemarksUPR3.Text.Trim();

            if (txtTimeHrFinisher.Text.Trim().Length < 2)
            {
                int uy = txtTimeHrFinisher.Text.Trim().Length;
                txtTimeHrFinisher.Text = uy == 0 ? "00" : "0" + txtTimeHrFinisher.Text.Trim();
            }
            if (txtTimeMinFinisher.Text.Trim().Length < 2)
            {
                int uy = txtTimeMinFinisher.Text.Trim().Length;
                txtTimeMinFinisher.Text = uy == 0 ? "00" : "0" + txtTimeMinFinisher.Text.Trim();
            }

            cmd.Parameters.Add("@TimeHWF", SqlDbType.VarChar).Value = txtTimeHrFinisher.Text.Trim() + ":" + txtTimeMinFinisher.Text.Trim();
            cmd.Parameters.Add("@MoistureHWF", SqlDbType.Float).Value = com.STRToDBL(txtMoistureFinisher.Text.Trim());
            cmd.Parameters.Add("@SolidHWF", SqlDbType.Float).Value = com.STRToDBL(txtSolidFinisher.Text.Trim());
            cmd.Parameters.Add("@AldehydeHWF", SqlDbType.Float).Value = com.STRToDBL(txtAldehydeFinisher.Text.Trim());
            cmd.Parameters.Add("@RemarksHWF", SqlDbType.VarChar).Value = txtRemarksFinisher.Text.Trim();

            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewVoucherNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewVoucherNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblChHotWellFinisher";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewVoucherNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Voucher No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }


    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Voucher No", "VoucherNo"));
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "HWF" + financialYear + inv_series.ToString().PadLeft(5, '0');

        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {

            string sql = @"select  MAX(Series) from tblChHotWellFinisher where [VoucherYear]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }
        return piseries;
    }

    protected void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

            FillFinancialYear();
            txtVoucherNo.Text = AutogenerateNo(txtYear.Text);

            string CurrentTime = DateTime.Now.ToString("HH:mm");
            string[] TimeIndex = CurrentTime.Split(':');
            txtTimeHrUPR3.Text = TimeIndex[0];
            txtTimeMinUPR3.Text = TimeIndex[1];
            txtTimeHrFinisher.Text = TimeIndex[0];
            txtTimeMinFinisher.Text = TimeIndex[1];
            
            txtMoistureUPR3.Text = "0";
            txtSolidUPR3.Text = "0";
            txtAldehydeUPR3.Text = "0";
            txtRemarksUPR3.Text = "";
            
            txtMoistureFinisher.Text = "0";
            txtSolidFinisher.Text = "0";
            txtAldehydeFinisher.Text = "0";
            txtRemarksFinisher.Text = "";
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    private void GetAllHotWellFinisherList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the voucher list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]  
		                    ,[VoucherNo]
		                    ,[VoucherYear]
		                    ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
		                    ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]     
                      FROM [tblChHotWellFinisher] as A where [VoucherNo] like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    private void BindHeaderRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [VoucherNo]
                          ,[VoucherYear]
                          ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
	                      ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                          ,[TimeHWU]
                          ,[MoistureHWU]
                          ,[SolidHWU]
                          ,[AldehydeHWU]
                          ,[RemarksHWU]
                          ,[TimeHWF]
                          ,[MoistureHWF]
                          ,[SolidHWF]
                          ,[AldehydeHWF]
                          ,[RemarksHWF]
                      FROM [tblChHotWellFinisher] as A where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                txtVoucherDate.Text = dt.Rows[0]["VoucherDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                txtVoucherNo.Text = dt.Rows[0]["VoucherNo"].ToString();

                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();

                if (dt.Rows[0]["TimeHWU"].ToString().Contains(":"))
                {
                    string time = dt.Rows[0]["TimeHWU"].ToString();
                    string[] timearr = time.Split(':');
                    txtTimeHrUPR3.Text = timearr[0];
                    txtTimeMinUPR3.Text = timearr[1];
                }

                txtMoistureUPR3.Text = dt.Rows[0]["MoistureHWU"].ToString();
                txtSolidUPR3.Text = dt.Rows[0]["SolidHWU"].ToString();
                txtAldehydeUPR3.Text = dt.Rows[0]["AldehydeHWU"].ToString();
                txtRemarksUPR3.Text = dt.Rows[0]["RemarksHWU"].ToString();

                if (dt.Rows[0]["TimeHWF"].ToString().Contains(":"))
                {
                    string time = dt.Rows[0]["TimeHWF"].ToString();
                    string[] timearr = time.Split(':');
                    txtTimeHrFinisher.Text = timearr[0];
                    txtTimeMinFinisher.Text = timearr[1];
                }

                txtMoistureFinisher.Text = dt.Rows[0]["MoistureHWF"].ToString();
                txtSolidFinisher.Text = dt.Rows[0]["SolidHWF"].ToString();
                txtAldehydeFinisher.Text = dt.Rows[0]["AldehydeHWF"].ToString();
                txtRemarksFinisher.Text = dt.Rows[0]["RemarksHWF"].ToString();
                dt = null;
            }
        }
        catch { }
    }

    #endregion

}