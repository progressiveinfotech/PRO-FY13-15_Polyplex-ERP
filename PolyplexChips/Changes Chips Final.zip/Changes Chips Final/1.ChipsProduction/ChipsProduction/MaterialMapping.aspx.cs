﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 21-Jun-13
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;

public partial class Sales_MasterFinalDestination : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common_Message objcommonmessage = new Common_Message();
    MasterWithGrid cs = new MasterWithGrid();
    Common com = new Common();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Label lbl = (Label)Master.FindControl("lbl_PageHeader");
                lbl.Text = "Material Mapping";

                if (Session["UserID"] == null)
                {
                    Server.Transfer("../SessionExpired.aspx");
                }
                else
                {
                    BindMasterBatchType();
                    makeGrid();
                    txtMaterialCode.Focus();
                }

                #region Change Color and Readonly Fields

                txtMaterialName.Attributes.Add("readonly", "true");
                txtMaterialName.Attributes.Add("style", "background:lightgray");

                #endregion
            }
        }
        catch { }

    }

    protected void btnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used for search the record in saved mapping in grid.
        /// </summary>
        makeGrid();
    }

    protected void gvMaterialMapping_SelectedIndexChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing record from all saved mapping in grid.
        /// </summary> 
        try
        {
            foreach (GridViewRow oldrow in gvMaterialMapping.Rows)
            {
                ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                oldrow.BackColor = Color.White;
            }
            ImageButton img = (ImageButton)gvMaterialMapping.Rows[gvMaterialMapping.SelectedIndex].FindControl("ImageButton1");
            img.ImageUrl = "~/Images/chkbxcheck.png";

            int DataKey = int.Parse(gvMaterialMapping.SelectedDataKey.Value.ToString());
            HidAutoId.Value = DataKey.ToString();
            BindHeaderRecords(HidAutoId.Value);
        }
        catch { }
    }

    protected void gvMaterialMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in material mapping grid.
        /// </summary> 
        try
        {
            gvMaterialMapping.PageIndex = e.NewPageIndex;
            makeGrid();
        }
        catch { }
    }

    protected void gvMaterialMapping_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id column in grid.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                e.Row.Cells[6].Style.Add("display", "none");
                e.Row.Cells[7].Style.Add("display", "none");
            }
        }
        catch { }
    }

    protected void imgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the materials for output section.
        /// </summary> 
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Material";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code: ";
            FillAllMaterial("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void txtMaterial_TextChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to populate entered material.
        /// </summary>
        try
        {
            string query = @"select AutoId,MaterialCode,MaterialDesc from Proc_MaterialMaster where Status =1 and MaterialCode = '" + txtMaterialCode.Text.Trim() + "'";

            DataTable dt = new DataTable();
            dt = com.executeSqlQry(query);

            HidMaterialId.Value = "";
            txtMaterialCode.Text = "";
            txtMaterialName.Text = "";

            if (dt.Rows.Count > 0)
            {
                HidMaterialId.Value = dt.Rows[0]["AutoId"].ToString();
                txtMaterialCode.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialName.Text = dt.Rows[0]["MaterialDesc"].ToString();
            }
            else
            {
                try
                {
                    txtSearchFromPopup.Text = "";
                    HidPopUpType.Value = "Material";
                    lPopUpHeader.Text = "Material Master";
                    lSearch.Text = "Search By Material Code: ";
                    FillAllMaterial("");
                    ModalPopupExtender2.Show();
                }
                catch { }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "Material")
                {
                    HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    txtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    txtMaterialName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                e.Row.Cells[1].Style.Add("display", "none");
            }
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>
        try
        {
            #region Check if mapping exist in table***************************************

            if (HidAutoId.Value == "0")
            {
                DataTable dt = new DataTable();
                string query = @"select AutoId from tblMatMapping where BatchId ='"+ddlMasterBatchType.SelectedValue +"' and";
                       query +=" MaterialId ='"+HidMaterialId.Value+"' and Category ='"+ddlCategory.SelectedValue+"'";
                dt = com.executeSqlQry(query);
                if (dt.Rows.Count > 0)
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info,"Mapping is already exist. Please check it.", 125, 300);
                    return;
                }
                dt = null;
            }

            #endregion********************************************************************

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@BatchId", SqlDbType.Int).Value = com.STRToInt(ddlMasterBatchType.SelectedValue);
            cmd.Parameters.Add("@MaterialId", SqlDbType.Int).Value = com.STRToInt(HidMaterialId.Value);
            cmd.Parameters.Add("@Category", SqlDbType.VarChar).Value = ddlCategory.SelectedValue;

            cmd.Parameters.Add("@AFlag", SqlDbType.Bit).Value = chkActive.Checked;
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblMatMapping";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();

            if (ErrorStatus == "0")
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);

                #region Clear All records after save

                ClearFields();
                makeGrid();

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void BindMasterBatchType()
    {
        /// <summary>
        /// This method is used to get the master batch type.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"select AutoId,ChMstBatchDesc from tblChMstMasterBatch";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                ddlMasterBatchType.DataTextField = "ChMstBatchDesc";
                ddlMasterBatchType.DataValueField = "AutoId";
                ddlMasterBatchType.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    ddlMasterBatchType.DataBind();
                }
            }
        }
        catch { }
    }

    protected void makeGrid()
    {
        /// <summary>
        /// This method is used to get all the detail records in from the database in grid.
        /// </summary>
        try
        {
            string query = @"SELECT A.[AutoId]
                            ,[BatchId]
                            ,B.ChMstBatchDesc
                            ,[MaterialId]
                            ,C.MaterialCode
                            ,C.MaterialDesc
                            ,A.[Category]
                            ,A.[AFlag]
                        FROM [tblMatMapping] as A inner join tblChMstMasterBatch as B on A.BatchId =B.AutoId inner join Proc_MaterialMaster as C
                        on A.MaterialId = C.AutoId where (C.MaterialCode like '%" + txtSearch.Text.Trim() + "%' or B.ChMstBatchDesc like '%" + txtSearch.Text.Trim() + "%' or A.Category like '%" + txtSearch.Text.Trim() + "%')  order by A.AutoId desc";

            DataTable dt = cs.getGrid(query);
            gvMaterialMapping.DataSource = dt;
            gvMaterialMapping.DataBind();
            lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
        }
        catch { }
    }

    private void ClearFields()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            ddlMasterBatchType.SelectedIndex = 0;
            HidMaterialId.Value = "";
            txtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            ddlCategory.SelectedIndex = 0;
            chkActive.Checked = true;
            txtMaterialCode.Focus();
        }
        catch { }
    }

    private void BindHeaderRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [BatchId]
                            ,[MaterialId]
                            ,C.MaterialCode
                            ,C.MaterialDesc
                            ,A.[Category]
                            ,A.[AFlag]
                        FROM [tblMatMapping] as A inner join tblChMstMasterBatch as B on A.BatchId =B.AutoId inner join Proc_MaterialMaster as C
                        on A.MaterialId = C.AutoId where A.[AutoId] = '" + AutoId + "'";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                ddlMasterBatchType.SelectedValue = dt.Rows[0]["BatchId"].ToString();
                HidMaterialId.Value = dt.Rows[0]["MaterialId"].ToString();
                txtMaterialCode.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialName.Text = dt.Rows[0]["MaterialDesc"].ToString();
                ddlCategory.SelectedValue = dt.Rows[0]["Category"].ToString();
                if (dt.Rows[0]["AFlag"].ToString() == "True")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
            }
            dt = null;
        }
        catch { }
    }

    protected void FillAllMaterial(string Searchtext)
    {
        /// <summary>
        /// This method is used to get all materials and fill in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select AutoId,MaterialCode,MaterialDesc as MaterialName from Proc_MaterialMaster where Status =1 and (MaterialCode
                           like '%" + Searchtext + "%' or MaterialDesc like '%" + Searchtext + "%')";

            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    #endregion

}