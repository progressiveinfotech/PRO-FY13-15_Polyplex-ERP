﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region********************************************Variables ************************************************

    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    Common com = new Common();
    Proc_StorageLocationMovement objstoragelocation = new Proc_StorageLocationMovement();

    Connection objConnectionClass = new Connection();
    string ErrorStatus, RecordNo;


    #endregion

    #region************************************************Events**********************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //Code to disable the save btn to avoid double click
            ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");

            //========================================

            if (!IsPostBack)
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "Chips Movement";

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                TxtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                FillFinancialYear();

                BindSearchList();

                BindPlant(DdlPlantFrom);
                BindPlant(DdlPlantTo);
                BindStorageLocationFromDD(ddlStorageLocationFrom);
                BindStorageLocationToDD(ddlStorageLocationTo);

                #region Change Color and Readonly Fields

                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                TxtVoucherDate.Attributes.Add("style", "background:lightgray");
                TxtYear.Attributes.Add("style", "background:lightgray");
                TxtValue.Attributes.Add("style", "background:lightgray");
                txtCurrentStock.Attributes.Add("style", "background:lightgray");
                TxtBatch.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");
                txtUOM.Attributes.Add("style", "background:lightgray");
                txtMaterialName.Attributes.Add("style", "background:lightgray");

                txtVoucherNo.Attributes.Add("readonly", "true");
                TxtVoucherDate.Attributes.Add("readonly", "true");
                TxtYear.Attributes.Add("readonly", "true");
                TxtValue.Attributes.Add("readonly", "true");
                txtCurrentStock.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");
                TxtBatch.Attributes.Add("readonly", "true");
                txtUOM.Attributes.Add("readonly", "true");
                txtMaterialName.Attributes.Add("readonly", "true");

                #endregion

                #region Blank Grid

                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                #endregion

                txtVoucherNo.Text = AutogenerateNo(TxtYear.Text);
            }

            ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
            btnAdd.CausesValidation = false;
            btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

            ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
            imgbtnSearch.CausesValidation = false;
            imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);
        }
        catch { }
    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>

        try
        {
            ClearHeader();
            ClearLineItems();
            GetProc_Glb_StorageLocationMovement_Details_Trans("0");
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";
            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
        }
        catch { }

        ModalPopupExtender1.Show();
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary> 
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";
                //added by lalit 4march 2013
                ClearLineItems();
                //end
                hidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderAndGridRecords(hidAutoId.Value);
                EnableDisableHeaderControls(false);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            DataTable dt = new DataTable();
            dt = Get_AllStorageLocationMovement(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            txtSearchList.Focus();
        }
        catch { }

        ModalPopupExtender1.Show();
    }

    protected void imgBtnStorageLocationFrom_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate from storage location.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationFrom";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Storage Location: ";
            BindStorageLocationFromPopup("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void imgBtnStorageLocationTo_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate to storage location.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "StorageLocationTo";
            lPopUpHeader.Text = "Storage Location";
            lSearch.Text = "Search By Storage Location: ";
            BindStorageLocationToPopup("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void ImgBtnMaterialCode_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate from material.
        /// </summary>
        try
        {
            //added by lalit on 26 April 2013
            if (IsSameStroageLoc(DdlPlantFrom.SelectedValue, DdlPlantTo.SelectedValue, ddlStorageLocationFrom.SelectedValue, ddlStorageLocationTo.SelectedValue))
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material can not be moved in same storage location of same plant.", 125, 300);
                return;
            }
            //end
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "Material";
            lPopUpHeader.Text = "Material Master";
            lSearch.Text = "Search By Material Code/Name: ";
            FillAllMaterial("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (HidPopUpType.Value != "BatchNo")
                {
                    e.Row.Cells[1].Style.Add("display", "none");
                }

                if (HidPopUpType.Value == "Material")
                {
                    e.Row.Cells[4].Style.Add("display", "none");
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "StorageLocationFrom")
                {
                    ddlStorageLocationFrom.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    HidMaterialId.Value = "";
                    TxtMaterialCode.Text = "";
                    DdlValuationType.Items.Clear();
                    TxtBatch.Text = "0";
                    TxtQuantity.Text = "";
                    TxtValue.Text = "";
                }
                else if (HidPopUpType.Value == "StorageLocationTo")
                {
                    ddlStorageLocationTo.SelectedValue = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
                else if (HidPopUpType.Value == "Material")
                {
                    HidMaterialId.Value = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                    TxtMaterialCode.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[2].Text;
                    txtMaterialName.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[3].Text;
                    FillAllValuationTypeMaster();
                    BindMaterialInformation(HidMaterialId.Value);

                    #region Reset the lineitems when material is changed.

                    TxtBatch.Text = "0";
                    TxtQuantity.Text = "0";
                    TxtValue.Text = "0";
                    txtCurrentStock.Text = "0";

                    #endregion

                    txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                        DdlPlantFrom.SelectedValue, DdlValuationType.SelectedValue).ToString();

                    //added by lalit 9march 2013
                    if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                    {
                        imgBtnBatchNo.Visible = false;
                    }
                    else
                    {
                        imgBtnBatchNo.Visible = true;
                    }
                    //end
                }
                else if (HidPopUpType.Value == "BatchNo")
                {
                    TxtBatch.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;

            if (HidPopUpType.Value == "StorageLocationFrom")
            {
                BindStorageLocationFromPopup(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationTo")
            {
                BindStorageLocationToPopup(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "BatchNo")
            {
                FillAllBatch("", DdlPlantFrom.SelectedValue, ddlStorageLocationFrom.SelectedValue, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
            }

            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "StorageLocationFrom")
            {
                BindStorageLocationFromPopup(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "StorageLocationTo")
            {
                BindStorageLocationToPopup(txtSearchFromPopup.Text.Trim());
            }
            else if (HidPopUpType.Value == "Material")
            {
                FillAllMaterial(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void TxtQuantity_TextChanged(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to fill other controls related to entered material.
        /// </summary>
        try
        {
            if (com.STRToIntBig(TxtQuantity.Text.Trim()) > 99999999999999.9999)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 99999999999999.9999.", 125, 300);
                return;
            }

            if (Hidstockflag.Value != "")
            {
                if (hidAutoId.Value != "")
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text) + com.STRToDBL(HidQuantity.Value)))
                    {
                        TxtQuantity.Text = "0";
                        TxtValue.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                        return;
                    }
                }
                else
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text)))
                    {
                        TxtQuantity.Text = "0";
                        TxtValue.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                        return;
                    }
                }
            }
            else
            {
                if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text)))
                {
                    TxtQuantity.Text = "0";
                    TxtValue.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                    return;
                }

                DataTable dt = (DataTable)ViewState["LineItem"];
                double Quantity = 0.00, AddedQuantity = 0.00;
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Select("MaterialCode='" + TxtMaterialCode.Text + "' AND Plant=" + DdlPlantFrom.SelectedValue + " AND StorageLocation=" + ddlStorageLocationFrom.SelectedValue))
                    {
                        Quantity = com.STRToDBL(row["Quantity"].ToString());
                        AddedQuantity = Quantity + AddedQuantity;
                    }
                }
                if (!IsQuantityValid(com.STRToDBL(txtCurrentStock.Text), com.STRToDBL(TxtQuantity.Text), AddedQuantity))
                {
                    TxtQuantity.Text = "0";
                    TxtValue.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                    return;
                }
            }

            if (TxtQuantity.Text != "" && HidMaterialId.Value != "" && DdlPlantFrom.SelectedValue != "" && DdlValuationType.Items.Count > 0)
            {
                double MaterialRate = 0.00, MaterialValue = 0.00;
                string Query = @"select dbo.mm_get_valuated_wa_price( '" + TxtMaterialCode.Text + "','" + DdlPlantFrom.SelectedValue + "','" + DdlValuationType.SelectedValue + "','" + TxtVoucherDate.Text + "') as MaterialRate";
                DataTable dtValStk = new DataTable();
                dtValStk = com.executeSqlQry(Query);
                if (dtValStk.Rows.Count > 0)
                {
                    MaterialRate = Convert.ToDouble(dtValStk.Rows[0]["MaterialRate"].ToString());
                }
                MaterialValue = Math.Round((Convert.ToDouble(TxtQuantity.Text.Trim()) * MaterialRate), 2);
                TxtValue.Text = Convert.ToString(MaterialValue);
            }
        }
        catch { }
    }

    protected void gvChipsMovement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the grid columns which contain the id.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                if (hidAutoId.Value != "")
                {
                    e.Row.Cells[9].Style.Add("display", "none");
                }
                //end
                e.Row.Cells[10].Style.Add("display", "none");
                e.Row.Cells[11].Style.Add("display", "none");
            }
        }
        catch { }
    }

    protected void gvChipsMovement_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        /// <summary>
        /// This event is used to delete the record in form grid.
        /// </summary>
        try
        {
            DataTable dtLineItem = (DataTable)ViewState["LineItem"];
            DataTable dtForDelete = (DataTable)ViewState["ForDelete"];
            DataRow drForDelete = dtForDelete.NewRow();
            drForDelete["AutoId"] = dtLineItem.Rows[e.RowIndex]["AutoId"].ToString();
            dtForDelete.Rows.Add(drForDelete);
            dtForDelete.AcceptChanges();
            ViewState["ForDelete"] = dtForDelete;

            ClearLineItems();

            dtLineItem.Rows[e.RowIndex].Delete();
            dtLineItem.AcceptChanges();
            ViewState["LineItem"] = dtLineItem;

            gvChipsMovement.DataSource = (DataTable)ViewState["LineItem"];
            gvChipsMovement.DataBind();

            int LineNoInGrid = 0;
            DataTable dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count > 0)
            {
                LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[0]["LineNo"].ToString());
                for (int i = 1; i < dtLineItem.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                    {
                        LineNoInGrid = Convert.ToInt32(dtLineItem.Rows[i]["LineNo"].ToString());
                    }
                }
            }
            HidLineNo.Value = (LineNoInGrid + 10).ToString();
        }
        catch { }
    }

    protected void gvChipsMovement_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to fill the line item section after select the record in form grid.
        /// </summary>
        try
        {
            GridView gvLineItems = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvLineItems.SelectedIndex = row.RowIndex + 1;

            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvLineItems.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (objdtLineItem.Rows.Count > 0)
                {
                    if (hidAutoId.Value != "")
                    {
                        Hidstockflag.Value = "1";
                    }
                    else
                    {
                        Hidstockflag.Value = "0";
                    }
                    hidRowIndex.Value = Convert.ToString(row.RowIndex);
                    hidLineItemId.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["AutoId"].ToString();
                    HidUpdateGridRecord.Value = "Yes";
                    HidLineNo.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["LineNo"].ToString();

                    TxtMaterialCode.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["MaterialCode"].ToString();
                    txtMaterialName.Text = GetMaterialName(TxtMaterialCode.Text);

                    HidMaterialId.Value = GetMaterialId(TxtMaterialCode.Text);
                    BindMaterialInformation(HidMaterialId.Value);

                    FillAllValuationTypeMaster();
                    com.SetDropDownValues(DdlValuationType, objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["ValuationType"].ToString());
                    TxtBatch.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["BatchNo"].ToString();
                    TxtQuantity.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();
                    HidQuantity.Value = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Quantity"].ToString();
                    TxtValue.Text = objdtLineItem.Rows[com.STRToNum(hidRowIndex.Value)]["Value"].ToString();
                    txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                        DdlPlantFrom.SelectedValue, DdlValuationType.SelectedValue).ToString();

                    EnableDisableLineitemControls(false);
                    btnAddLine.ImageUrl = "../Images/btnUpdateLine.png";
                }
            }
        }
        catch { }
    }

    protected void imgBtnBatchNo_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate all the batch.
        /// </summary> 
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNo";
            lPopUpHeader.Text = "Batch";
            lSearch.Text = "Search By BatchNo.: ";
            FillAllBatch("", DdlPlantFrom.SelectedValue, ddlStorageLocationFrom.SelectedValue, DdlValuationType.SelectedValue, TxtMaterialCode.Text);
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void TxtMaterialCode_TextChanged(object sender, System.EventArgs e)
    {
        /// <summary>
        /// This event is used to populate enterd material.
        /// </summary>
        try
        {
            if (IsSameStroageLoc(DdlPlantFrom.SelectedValue, DdlPlantTo.SelectedValue, ddlStorageLocationFrom.SelectedValue, ddlStorageLocationTo.SelectedValue))
            {
                TxtMaterialCode.Text = "";
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Material can not be moved in same storage location of same plant.", 125, 300);
                return;
            }

            string query = @"select AutoId,MaterialCode,MaterialDesc from Proc_MaterialMaster where MaterialCode ='" + TxtMaterialCode.Text.Trim() + "' and Status =1";

            DataTable dt = new DataTable();
            dt = com.executeSqlQry(query);

            HidMaterialId.Value = "";
            TxtMaterialCode.Text = "";
            txtMaterialName.Text = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            DdlValuationType.Items.Clear();

            if (dt.Rows.Count > 0)
            {
                HidMaterialId.Value = dt.Rows[0]["AutoId"].ToString();
                TxtMaterialCode.Text = dt.Rows[0]["MaterialCode"].ToString();
                txtMaterialName.Text = dt.Rows[0]["MaterialDesc"].ToString();

                BindMaterialInformation(HidMaterialId.Value);
                FillAllValuationTypeMaster();

                #region Reset the lineitems when material is changed.

                TxtBatch.Text = "0";
                TxtQuantity.Text = "0";
                TxtValue.Text = "0";
                txtCurrentStock.Text = "0";

                #endregion

                txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                    DdlPlantFrom.SelectedValue, DdlValuationType.SelectedValue).ToString();

                if (!IsNotBatchIndicator(TxtMaterialCode.Text))
                {
                    imgBtnBatchNo.Visible = false;
                }
                else
                {
                    imgBtnBatchNo.Visible = true;
                }
            }
            else
            {
                try
                {
                    txtSearchFromPopup.Text = "";
                    HidPopUpType.Value = "Material";
                    lPopUpHeader.Text = "Material Master";
                    lSearch.Text = "Search By Material Code: ";
                    FillAllMaterial("");
                    ModalPopupExtender2.Show();
                }
                catch { }
            }
        }
        catch { }
    }

    protected void DdlValuationType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtCurrentStock.Text = CheckForQuantity_InStock(HidMaterialId.Value, ddlStorageLocationFrom.SelectedValue,
                        DdlPlantFrom.SelectedValue, DdlValuationType.SelectedValue).ToString();
        }
        catch { }
    }

    protected void ddlStorageLocationFrom_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearLineItems();
            GetProc_Glb_StorageLocationMovement_Details_Trans("0");
        }
        catch { }
    }

    protected void btnAddLine_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to add and update new line item grid.
        /// </summary>
        try
        {
            if (com.STRToIntBig(TxtQuantity.Text.Trim()) > 99999999999999.9999)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be greater than 99999999999999.9999.", 125, 300);
                return;
            }

            if (IsNotBatchIndicator(TxtMaterialCode.Text) && TxtBatch.Text == "0")
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Please enter BatchNo.", 125, 300);
                return;
            }

            if (com.STRToDBL(TxtQuantity.Text) == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Quantity cannot be 0.", 125, 300);
                return;
            }

            if (Hidstockflag.Value != "")
            {
                if (hidAutoId.Value != "")
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text) + com.STRToDBL(HidQuantity.Value)))
                    {
                        TxtQuantity.Text = "0";
                        TxtValue.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                        return;
                    }
                }
                else
                {
                    if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text)))
                    {
                        TxtQuantity.Text = "0";
                        TxtValue.Text = "0";
                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                        return;
                    }
                }
            }
            else
            {
                if (com.STRToDBL(TxtQuantity.Text) > (com.STRToDBL(txtCurrentStock.Text)))
                {
                    TxtQuantity.Text = "0";
                    TxtValue.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                    return;
                }

                DataTable dt = (DataTable)ViewState["LineItem"];
                double Quantity = 0.00, AddedQuantity = 0.00;
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Select("MaterialCode='" + TxtMaterialCode.Text + "' AND Plant=" + DdlPlantFrom.SelectedValue + " AND StorageLocation=" + ddlStorageLocationFrom.SelectedValue))
                    {
                        Quantity = com.STRToDBL(row["Quantity"].ToString());
                        AddedQuantity = Quantity + AddedQuantity;
                    }
                }
                if (!IsQuantityValid(com.STRToDBL(txtCurrentStock.Text), com.STRToDBL(TxtQuantity.Text), AddedQuantity))
                {
                    TxtQuantity.Text = "0";
                    TxtValue.Text = "0";
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Stock is not available for this material.", 125, 300);
                    return;
                }
            }

            DataTable objdtLineItem = new DataTable();
            objdtLineItem = (DataTable)ViewState["LineItem"];

            if (HidUpdateGridRecord.Value == "") //For Insert new record
            {
                DataRow objdrLineItem = objdtLineItem.NewRow();
                objdrLineItem["AutoId"] = 0;
                objdrLineItem["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdrLineItem["MaterialCode"] = TxtMaterialCode.Text.Trim();

                objdrLineItem["UOM"] = HidUOM.Value;
                objdrLineItem["UOMName"] = txtUOM.Text;


                objdrLineItem["ValuationType"] = DdlValuationType.SelectedValue;
                objdrLineItem["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                objdrLineItem["Plant"] = DdlPlantTo.SelectedValue;
                objdrLineItem["StorageLocation"] = ddlStorageLocationFrom.SelectedValue;
                if (TxtQuantity.Text != "")
                {
                    objdrLineItem["Quantity"] = Convert.ToDouble(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdrLineItem["Quantity"] = 0;
                }
                objdrLineItem["BatchNo"] = com.STRToIntBig(TxtBatch.Text.Trim());
                if (TxtValue.Text != "")
                {
                    objdrLineItem["Value"] = Convert.ToDouble(TxtValue.Text.Trim());
                }
                else
                {
                    objdrLineItem["Value"] = 0;
                }
                objdrLineItem["IsUpdated"] = "No";
                objdtLineItem.Rows.Add(objdrLineItem);
            }
            else if (HidUpdateGridRecord.Value == "Yes") //For Update record
            {
                if (hidLineItemId.Value != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = com.STRToNum(hidLineItemId.Value);
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["AutoId"] = 0;
                }


                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["LineNo"] = Convert.ToInt32(HidLineNo.Value);
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["MaterialCode"] = TxtMaterialCode.Text.Trim();

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOM"] = HidUOM.Value;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["UOMName"] = txtUOM.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationType"] = DdlValuationType.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["ValuationTypeName"] = DdlValuationType.SelectedItem.Text;

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Plant"] = DdlPlantTo.SelectedValue;
                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["StorageLocation"] = ddlStorageLocationFrom.SelectedValue;

                if (TxtQuantity.Text != "")
                {

                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = com.STRToDBL(TxtQuantity.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Quantity"] = 0;
                }
                //added by lalit 5march 2013
                if (HidQuantity.Value != TxtQuantity.Text)
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["IsUpdated"] = "Yes";
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["IsUpdated"] = "No";
                }
                //end

                objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["BatchNo"] = com.STRToIntBig(TxtBatch.Text.Trim());
                if (TxtValue.Text != "")
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = com.STRToDBL(TxtValue.Text.Trim());
                }
                else
                {
                    objdtLineItem.Rows[Convert.ToInt32(hidRowIndex.Value)]["Value"] = 0;
                }

                objdtLineItem.AcceptChanges();
            }
            ViewState["LineItem"] = objdtLineItem;
            int LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[0]["LineNo"].ToString());
            for (int i = 1; i < objdtLineItem.Rows.Count; i++)
            {
                if (Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString()) > LineNoInGrid)
                {
                    LineNoInGrid = Convert.ToInt32(objdtLineItem.Rows[i]["LineNo"].ToString());
                }
            }
            HidLineNo.Value = (LineNoInGrid + 10).ToString();
            gvChipsMovement.DataSource = objdtLineItem;
            gvChipsMovement.DataBind();
            ClearLineItems();
            Hidstockflag.Value = "";
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.ErrorToLineItem, 125, 300);
        }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>
        try
        {
            #region Line Item Records

            DataTable dt = new DataTable();
            dt = (DataTable)ViewState["LineItem"];
            if (dt.Rows.Count == 0)
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.AddLineItem, 125, 300);
                return;
            }

            //DataTable dtForDelete = new DataTable();
            //dtForDelete = (DataTable)ViewState["ForDelete"];

            #region MonthClosed for Storage Location**************************************************************
            //Added by satish on 30 may-13
            //This will help to check for month closed for material in storage location or not.

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string StorageLocationCode = "";
                string query1 = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid ='" + dt.Rows[0]["StorageLocation"].ToString() + "'";
                DataTable dt2 = new DataTable();
                dt2 = com.executeSqlQry(query1);
                if (dt2.Rows.Count > 0)
                {
                    StorageLocationCode = dt2.Rows[0]["StorageLocCode"].ToString();
                }
                dt2 = null;

                if (StorageLocationCode != "")
                {
                    string Plant = dt.Rows[i]["Plant"].ToString();
                    string VoucherDate = TxtVoucherDate.Text.Trim();

                    string FromDate = "", ToDate = "";
                    string msg = "";
                    DataTable dtFromTodate = new DataTable();
                    dtFromTodate = com.GetMonthCloseFromAndToDate(StorageLocationCode, Plant);

                    bool BoolValueForMonthClose = false;
                    BoolValueForMonthClose = com.IsMonthClosedForMaterialInStorLoc(StorageLocationCode, Plant, VoucherDate);
                    if (BoolValueForMonthClose == false)
                    {
                        if (dtFromTodate.Rows.Count > 0)
                        {
                            if (dtFromTodate.Rows[0]["FromDate"].ToString() != "" && dtFromTodate.Rows[0]["ToDate"].ToString() != "")
                            {
                                if (Convert.ToDateTime(dtFromTodate.Rows[0]["ToDate"].ToString()) < Convert.ToDateTime(VoucherDate))
                                {
                                    msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                    msg += " Please select another storage location.";
                                }
                                else
                                {
                                    FromDate = dtFromTodate.Rows[0]["FromDate"].ToString();
                                    ToDate = dtFromTodate.Rows[0]["ToDate"].ToString();

                                    msg = @"Month is closed for Line no: " + dt.Rows[i]["LineNo"] + " for the selected storage location.You have";
                                    msg += " to save it between " + FromDate + " and " + ToDate + ". Please select another storage location.";
                                }
                            }
                            else
                            {
                                msg = @"Month is not open for the selected storage location in Line no: " + dt.Rows[i]["LineNo"] + ".";
                                msg += " Please select another storage location.";
                            }
                        }

                        MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, msg, 180, 340);
                        return;
                    }
                }
            }

            #endregion***********************************************************************************

            //added by lalit 9March 2013
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double totalQuantity = 0.0;
                string TotalStockQty = "0";
                DataTable dtvalue = new DataTable();
                string sql1 = @"select ValuatedQuantity from Proc_MasterValuationStk where MaterialCode='" + dt.Rows[i]["MaterialCode"].ToString() + "' and";
                sql1 += " Plant ='" + dt.Rows[i]["Plant"].ToString() + "' and ValuationType ='" + dt.Rows[i]["ValuationType"].ToString() + "' and";
                sql1 += " StorageLocationID ='" + dt.Rows[i]["StorageLocation"].ToString() + "'";

                dtvalue = com.executeSqlQry(sql1);
                if (dtvalue.Rows.Count > 0)
                {
                    TotalStockQty = dtvalue.Rows[0]["ValuatedQuantity"].ToString();
                }
                dtvalue = null;

                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    if ((dt.Rows[i]["MaterialCode"].ToString() == dt.Rows[j]["MaterialCode"].ToString()) &&
                        (dt.Rows[i]["Plant"].ToString() == dt.Rows[j]["Plant"].ToString()) &&
                        (dt.Rows[i]["ValuationType"].ToString() == dt.Rows[j]["ValuationType"].ToString()) &&
                        (dt.Rows[i]["StorageLocation"].ToString() == dt.Rows[j]["StorageLocation"].ToString()))
                    {
                        totalQuantity = totalQuantity + Convert.ToDouble(dt.Rows[j]["Quantity"].ToString());
                    }
                }
                if (totalQuantity > com.STRToDBL(TotalStockQty))
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Total Stock quantity of material code: " + dt.Rows[i]["MaterialCode"].ToString() + " is:" + TotalStockQty + ". You have total entered:" + totalQuantity + ". Please reduce the quantity for this material.", 155, 300);
                    return;
                }
            }
            //end

            #endregion

            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region Insert Header Records

            if (hidAutoId.Value == "")
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@TransferId", SqlDbType.Int).Value = Convert.ToInt32(hidAutoId.Value);
            }
            cmd.Parameters.Add("@TransferNoExist", SqlDbType.VarChar).Value = txtVoucherNo.Text.Trim();
            if (TxtVoucherDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DateTime.ParseExact(TxtVoucherDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@TransferDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = "CM";

            cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = TxtYear.Text.Trim();
            cmd.Parameters.Add("@PlantFrom", SqlDbType.VarChar).Value = DdlPlantFrom.SelectedValue;
            cmd.Parameters.Add("@PlantTo", SqlDbType.VarChar).Value = DdlPlantTo.SelectedValue;
            cmd.Parameters.Add("@FromStorageLocation", SqlDbType.VarChar).Value = ddlStorageLocationFrom.SelectedValue;
            cmd.Parameters.Add("@ToStorageLocation", SqlDbType.VarChar).Value = ddlStorageLocationTo.SelectedValue;
            cmd.Parameters.Add("@RequestedBy", SqlDbType.VarChar).Value = "";
            cmd.Parameters.Add("@ApprovedBy", SqlDbType.VarChar).Value = "";

            cmd.Parameters.Add("@ActiveStatus", SqlDbType.Bit).Value = true;
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = Convert.ToInt32(Session["UserId"].ToString());

            #region Table Parameter

            cmd.Parameters.AddWithValue("@dtLineitems", dt);
            //cmd.Parameters.AddWithValue("@dtLineitemsForDelete", dtForDelete);

            #endregion

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewTransferNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewTransferNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Proc_Glb_StorageLocationMovement";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewTransferNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Voucher No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();
                ClearLineItems();
                gvChipsMovement.DataSource = "";
                gvChipsMovement.DataBind();
                GetProc_Glb_StorageLocationMovement_Details_Trans("0");

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region*******************************************Functions****************************************************

    protected void BindSearchList()
    {
        try
        {
            /// <summary>
            /// This method is used to get search list type of form.
            /// </summary>
            try
            {
                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.Items.Add(new ListItem("Voucher No", "TransferNo"));
            }
            catch { }
        }
        catch { }
    }

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    TxtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    TxtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        /// 
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "CM" + financialYear + inv_series.ToString().PadLeft(5, '0');
        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {

            string sql = "select  MAX([Series]) from Proc_Glb_StorageLocationMovement_Header where [Year]='" + fin_yr + "' and Type ='CM'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }

        return piseries;
    }

    protected void BindPlant(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the plant.
        /// </summary>
        try
        {
            string str = "SELECT autoid,(PLANTCODE+'('+PLANTNAME+')') as [Plant] FROM COM_PLANT_MST WHERE ACTIVESTATUS =1";
            DataTable dt = com.executeSqlQry(str);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["Plant"].ToString(), row["AutoId"].ToString()));
                }
            }
        }
        catch { }
    }

    protected void BindStorageLocationFromDD(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the storage location in from dd.
        /// </summary>
        try
        {
            string sql = @" Select distinct S.autoid,(StorageLocCode+' - '+Location+'')
                            as StorageLocation from Prod_StorageLocation_Mst as S inner 
                            join Proc_MasterValuationStk as P on S.autoid = P.StorageLocationID  and P.Plant='" + DdlPlantFrom.SelectedValue + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["StorageLocation"].ToString(), row["autoid"].ToString()));
                }
            }
        }
        catch { }
    }

    protected void BindStorageLocationToDD(DropDownList ddl)
    {
        /// <summary>
        /// This method is used to bind the storage location in to dd.
        /// </summary>
        try
        {
            string sql = @" Select distinct S.autoid,(StorageLocCode+' - '+Location+'')
                            as StorageLocation from Prod_StorageLocation_Mst as S Where
                            PlantId ='" + DdlPlantTo.SelectedValue + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ddl.Items.Add(new ListItem(row["StorageLocation"].ToString(), row["autoid"].ToString()));
                }
            }
        }
        catch { }
    }

    private void BindStorageLocationFromPopup(string Searchtext)
    {
        /// <summary>
        /// This method is used to fill the from storage location in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @" Select distinct S.autoid,StorageLocCode as Code, Location as Name from Prod_StorageLocation_Mst as S inner 
                            join Proc_MasterValuationStk as P on S.autoid = P.StorageLocationID  where S.Status=1 and P.Plant='" + DdlPlantFrom.SelectedValue + "' and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";

            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void BindStorageLocationToPopup(string Searchtext)
    {
        /// <summary>
        /// This method is used to fill the to storage location in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @" Select distinct S.autoid,StorageLocCode as Code, Location as Name from Prod_StorageLocation_Mst as S Where S.Status=1 and 
                            PlantId =" + DdlPlantTo.SelectedValue + " and (S.StorageLocCode like '%" + Searchtext + "%' or Location like '%" + Searchtext + "%')";

            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;
                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void FillAllMaterial(string Searchtext)
    {
        /// <summary>
        /// This method is used to fill the material in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string sql = @"select distinct P.AutoId,P.MaterialCode as [Material Code],P.MaterialDesc as [Description],UOMId
	                      ,(select Description from Proc_UOM_Master where AutoId =P.UOMId) as UOM
                           from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                          P.AutoId = M.MaterialCodeID where P.Status=1 and M.StorageLocationID ='" + ddlStorageLocationFrom.SelectedValue + "' and (P.MaterialCode like '%" + Searchtext + "%' or P.MaterialDesc like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private string GetMaterialId(string matericalcode)
    {
        /// <summary>
        /// This method is used to get the material id.
        /// </summary>
        /// 
        string str = @"select distinct P.AutoId from Proc_MaterialMaster as P inner join Proc_MasterValuationStk as M on
                       P.AutoId = M.MaterialCodeID where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["AutoId"].ToString();
        }
        return "0.0";
    }

    private string GetMaterialName(string matericalcode)
    {
        /// <summary>
        /// This method is used to get the material name.
        /// </summary>
        string str = @"select MaterialDesc from Proc_MaterialMaster as P where P.MaterialCode='" + matericalcode + "'";
        DataTable dtmaterial = new DataTable();
        dtmaterial = com.executeSqlQry(str);
        if (dtmaterial != null && dtmaterial.Rows.Count > 0)
        {
            return dtmaterial.Rows[0]["MaterialDesc"].ToString();
        }
        return "";
    }

    private void FillAllValuationTypeMaster()
    {
        /// <summary>
        /// This method is used to fill all the valuation type according to the material.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            //changed by LJ 19Feb2013
            string sql = @"Select distinct V.AutoId, V.ValuationType from Proc_ValuationClass_Master as V inner join Proc_MasterValuationStk as P 
                           on V.AutoId =P.ValuationType where V.Status=1 and P.MaterialCodeID ='" + HidMaterialId.Value + "'";
            //end
            dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                DdlValuationType.DataTextField = "ValuationType";
                DdlValuationType.DataValueField = "AutoId";
                DdlValuationType.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    DdlValuationType.DataBind();
                }
            }
            else
            {
                DdlValuationType.Items.Clear();
            }
        }
        catch
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            hidAutoId.Value = "";
            FillFinancialYear();
            TxtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtVoucherNo.Text = AutogenerateNo(TxtYear.Text);
            ddlStorageLocationFrom.SelectedIndex = 0;
            ddlStorageLocationTo.SelectedIndex = 0;
            DdlPlantFrom.SelectedIndex = 0;
            DdlPlantTo.SelectedIndex = 0;
            EnableDisableHeaderControls(true);
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    private void ClearLineItems()
    {
        /// <summary>
        /// This method is used to clear all the line item records.
        /// </summary>
        try
        {
            TxtMaterialCode.Text = "";
            DdlValuationType.Items.Clear();
            TxtBatch.Text = "0";
            TxtQuantity.Text = "0";
            TxtValue.Text = "0";
            HidUpdateGridRecord.Value = "";
            HidMaterialId.Value = "";
            txtMaterialName.Text = "";
            HidUOM.Value = "";
            txtUOM.Text = "";
            txtCurrentStock.Text = "0";
            imgBtnBatchNo.Visible = true;
            EnableDisableLineitemControls(true);
            btnAddLine.ImageUrl = "../Images/btnAddLinegreen.png";
        }
        catch { }
    }

    protected void GetProc_Glb_StorageLocationMovement_Details_Trans(string TransferNo)
    {
        /// <summary>
        /// This method is used to bind the line item grid of form.
        /// </summary>
        try
        {
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement_Details_Trans";
            objSqlCommand.Parameters.AddWithValue("@TransferNo", TransferNo);

            SqlDataProvider db = new SqlDataProvider();
            DataTable dt = new DataTable();
            dt = db.GetDataTableWithProc(objSqlCommand);

            if (dt.Rows.Count > 0)
            {
                int TotalRows = dt.Rows.Count;
                HidLineNo.Value = (Convert.ToInt32(dt.Rows[TotalRows - 1]["LineNo"].ToString()) + 10).ToString();
            }
            else
            {
                HidLineNo.Value = "10";
            }
            ViewState["LineItem"] = dt;
            gvChipsMovement.DataSource = dt;
            gvChipsMovement.DataBind();
            dt = null;

            string sql = "select AutoId from [Proc_Glb_StorageLocationMovement_Details_Trans] where AutoId=0";
            dt = com.executeSqlQry(sql);
            ViewState["ForDelete"] = dt;
            dt = null;
        }
        catch { }
    }

    public DataTable Get_AllStorageLocationMovement(string SearchType, string SearchText)
    {
        /// <summary>
        /// This method is used to get all the storage location movement.
        /// </summary>
        /// 
        SqlCommand objSqlCommand = new SqlCommand();
        objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement";
        objSqlCommand.Parameters.AddWithValue("@SearchType", SearchType);
        objSqlCommand.Parameters.AddWithValue("@SearchText", SearchText);
        objSqlCommand.Parameters.AddWithValue("@Type", "CM");

        SqlDataProvider db = new SqlDataProvider();
        return db.GetDataTableWithProc(objSqlCommand);
    }

    private void BindHeaderAndGridRecords(string TransferId)
    {
        /// <summary>
        /// This method is used bind all the header records and line items in grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            dt = Get_Proc_Glb_StorageLocationMovement_Header_ById(TransferId);
            if (dt.Rows.Count > 0)
            {
                txtVoucherNo.Text = dt.Rows[0]["TransferNo"].ToString();
                TxtYear.Text = dt.Rows[0]["Year"].ToString();
                TxtVoucherDate.Text = dt.Rows[0]["TransferDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                DdlPlantFrom.SelectedValue = dt.Rows[0]["PlantFrom"].ToString();
                DdlPlantTo.SelectedValue = dt.Rows[0]["PlantTo"].ToString();
                ddlStorageLocationFrom.SelectedValue = dt.Rows[0]["FromStorageLocation"].ToString();
                ddlStorageLocationTo.SelectedValue = dt.Rows[0]["ToStorageLocation"].ToString();

                #region Bind Line Items

                GetProc_Glb_StorageLocationMovement_Details_Trans(txtVoucherNo.Text.Trim());

                #endregion

                dt = null;
            }
        }
        catch { }
    }

    public DataTable Get_Proc_Glb_StorageLocationMovement_Header_ById(string TransferId)
    {
        /// <summary>
        /// This method is used to get the header records from database.
        /// </summary>
        SqlCommand objSqlCommand = new SqlCommand();
        objSqlCommand.CommandText = "Sp_Get_Proc_Glb_StorageLocationMovement_Header_ById";
        objSqlCommand.Parameters.AddWithValue("@TransferId", TransferId);

        SqlDataProvider db = new SqlDataProvider();
        return db.GetDataTableWithProc(objSqlCommand);
    }

    protected void FillAllBatch(string Searchtext, string storagelocationid, string plant, string ValuationTypeid, string materialcode)
    {
        /// <summary>
        /// This method is used to get all the batch and fill in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            string sql = @"select BatchNo from Proc_GoodsReceipt_OtherDetails_Trans where Plant='" + plant + "' and";
            sql += " StorageLocation='" + GetStorageLocationCodeById(storagelocationid) + "' and MaterialCode='"
                                      + materialcode + "' and ValuationType='" + ValuationTypeid
                                      + "' and activestatus=1 and (BatchNo like '%" + Searchtext + "%' or BatchNo like '%" + Searchtext + "%')";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    public string GetStorageLocationCodeById(string id)
    {
        /// <summary>
        /// This method is used to get the storage location code by id.
        /// </summary>
        try
        {
            string str = @"select StorageLocCode from Prod_StorageLocation_Mst where autoid='" + id + "'";
            DataTable dtstr = com.executeSqlQry(str);
            if (dtstr != null && dtstr.Rows.Count > 0)
            {
                return dtstr.Rows[0]["StorageLocCode"].ToString();
            }
        }
        catch { }
        return "";
    }

    private bool IsSameStroageLoc(string plantfrom, string plantto, string StorageFrom, string StorageTo)
    {
        /// <summary>
        /// This method is used to check the both selected storage location are same or not.
        /// </summary>
        if (plantfrom == plantto)
        {
            if (StorageFrom == StorageTo)
            {
                return true;
            }
        }
        return false;
    }

    private bool IsNotBatchIndicator(string materialcode)
    {
        /// <summary>
        /// This method is used to check the batch indicator of selected material.
        /// </summary>
        /// 
        string str = "select BatchIndicator from Proc_MaterialMaster where MaterialCode='" + materialcode + "'";
        bool IsBatchIndicator = false;
        DataTable dtstr = com.executeSqlQry(str);
        if (dtstr != null && dtstr.Rows.Count > 0)
        {
            if (dtstr.Rows[0]["BatchIndicator"].ToString() == "True")
            {
                IsBatchIndicator = true;
            }
        }
        return IsBatchIndicator;
    }

    public bool IsQuantityValid(double availablequantity, double inputquantity, double AddedQuantity)
    {
        /// <summary>
        /// This method is used to check weither quantity is valid or not.
        /// </summary>
        /// 
        if ((inputquantity + AddedQuantity) > availablequantity)
            return false;
        else return true;
    }

    protected void BindMaterialInformation(string MaterialAutoId)
    {
        /// <summary>
        /// This method is used to get material information depend upon the material selection.
        /// </summary>
        try
        {
            txtUOM.Text = "";
            string sql = @"select MaterialDesc,B.Code,B.AutoId  from Proc_MaterialMaster as A inner join Proc_UOM_Master as B on A.UOMId = B.AutoId
                          where A.AutoId ='" + MaterialAutoId + "'";

            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                HidUOM.Value = dt.Rows[0]["AutoId"].ToString();
                txtUOM.Text = dt.Rows[0]["Code"].ToString();
            }
            dt = null;
        }
        catch { }
    }

    private double CheckForQuantity_InStock(string materialid, string storagelocationid, string plant, string ValuationTypeid)
    {
        /// <summary>
        /// This method is used to check the quantity in stock.
        /// </summary>
        double TotalQuantityOnStock = 0.0;
        string str = @"select SUM(ValuatedQuantity) as TotalQuantity from Proc_MasterValuationStk
                        where MaterialCodeId='" + materialid + "' and StorageLocationID='" + storagelocationid + "' and Plant='" + plant + "' and ValuationType='" + ValuationTypeid + "'";
        DataTable dtquantity = com.executeSqlQry(str);
        if (dtquantity != null && dtquantity.Rows.Count > 0)
        {
            TotalQuantityOnStock = com.STRToDBL(dtquantity.Rows[0]["TotalQuantity"].ToString());
        }
        return TotalQuantityOnStock;
    }

    protected void EnableDisableHeaderControls(bool type)
    {
        try
        {
            ddlStorageLocationFrom.Enabled = type;
            ddlStorageLocationTo.Enabled = type;

            imgBtnStorageLocationFrom.Enabled = type;
            imgBtnStorageLocationTo.Enabled = type;
            DdlPlantFrom.Enabled = type;
            DdlPlantTo.Enabled = type;
        }
        catch { }
    }

    protected void EnableDisableLineitemControls(bool type)
    {
        try
        {
            TxtMaterialCode.Enabled = type;
            DdlValuationType.Enabled = type;
            imgBtnMaterialCode.Enabled = type;
            imgBtnBatchNo.Enabled = type;
        }
        catch { }
    }

    #endregion
    
}