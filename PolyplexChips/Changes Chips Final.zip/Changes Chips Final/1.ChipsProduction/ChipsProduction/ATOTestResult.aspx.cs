﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Data;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================

        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "ATO Test Result";

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();

                #region Change Color and Readonly Fields

                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                txtYear.Attributes.Add("style", "background:lightgray");
                txtVoucherDate.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");
                //txtBatchNo.Attributes.Add("style", "background:lightgray");

                txtVoucherNo.Attributes.Add("readonly", "true");
                txtYear.Attributes.Add("readonly", "true");
                txtVoucherDate.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");
                //txtBatchNo.Attributes.Add("readonly", "true");

                #endregion

                txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>
        try
        {
            ClearHeader();

            txtSearchList.Text = "";
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllATOTestResultList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary>
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearHeader();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllATOTestResultList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllATOTestResultList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }
    
    protected void imgBtnBatchNo_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to populate the batch popup for output section.
        /// </summary>
        try
        {
            txtSearchFromPopup.Text = "";
            HidPopUpType.Value = "BatchNo";
            lPopUpHeader.Text = "Batch Master";
            lSearch.Text = "Search By Batch: ";
            FillAllBatch("");
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used to select the selected record and fill its respective control(s) in all the popups.
        /// </summary>
        try
        {
            GridView gvPopUpGrid = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvPopUpGrid.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvPopUpGrid.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                if (HidPopUpType.Value == "BatchNo")
                {
                    txtBatchNo.Text = gvPopUpGrid.Rows[gvPopUpGrid.SelectedIndex].Cells[1].Text;
                }
            }
        }
        catch { }
    }

    protected void gvPopUpGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /// <summary>
        /// This event is used to hide the id field in popup grid for all the popups.
        /// </summary>
        try
        {
            if (e.Row.RowType != DataControlRowType.EmptyDataRow)
            {
                e.Row.Cells[1].Style.Add("display", "none");
            }
        }
        catch { }
    }

    protected void btnSearchInPopUp_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used to search the entered record in popup grid for all the popups.
        /// </summary>
        try
        {
            if (HidPopUpType.Value == "BatchNo")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void gvPopUpGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in popup grid for all the popups.
        /// </summary>
        try
        {
            gvPopUpGrid.PageIndex = e.NewPageIndex;
            if (HidPopUpType.Value == "BatchNo")
            {
                FillAllBatch(txtSearchFromPopup.Text.Trim());
            }
            txtSearchFromPopup.Focus();
            ModalPopupExtender2.Show();
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>

        try
        {
            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();
            if (txtVoucherDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtVoucherDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            cmd.Parameters.Add("@BatchNo", SqlDbType.Int).Value = com.STRToInt(txtBatchNo.Text.Trim());
            cmd.Parameters.Add("@MoistureContent", SqlDbType.Float).Value = com.STRToDBL(txtMoistureContent.Text.Trim());
            cmd.Parameters.Add("@Purity", SqlDbType.Float).Value = com.STRToDBL(txtPurity.Text.Trim());
            cmd.Parameters.Add("@SolubilityInMEG", SqlDbType.VarChar).Value = txtSolubilityinMEG.Text.Trim();
            cmd.Parameters.Add("@Appearance", SqlDbType.VarChar).Value = txtAppearance.Text.Trim();

            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewVoucherNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewVoucherNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblChATOTestResult";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewVoucherNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Voucher No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Voucher No", "VoucherNo"));
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "ATOR" + financialYear + inv_series.ToString().PadLeft(5, '0');

        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {

            string sql = @"select  MAX(Series) from tblChATOTestResult where [VoucherYear]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }
        return piseries;
    }

    protected void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

            FillFinancialYear();
            txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
                        
            txtBatchNo.Text = "0";
            txtSolubilityinMEG.Text = "";
            txtMoistureContent.Text = "0";
            txtPurity.Text = "0";
            txtAppearance.Text = "";
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }    

    protected void FillAllBatch(string Searchtext)
    {
        /// <summary>
        /// This method is used to get all the batch and fill in popup grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();

            //            string sql = @"select autoid,(StorageLocCode +' - '+ Location) as CodeName from Prod_StorageLocation_Mst where
            //                           PlantId ='" + ddlPlant.SelectedValue + "' and Status =1 and StorageLocCode like '%" + Searchtext + "%'";

            string sql = @"";
            dt = com.executeSqlQry(sql);

            if (dt.Rows.Count > 0)
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();

                gvPopUpGrid.AutoGenerateColumns = true;
                gvPopUpGrid.AllowPaging = true;
                gvPopUpGrid.DataSource = dt;

                if (gvPopUpGrid.PageIndex > (dt.Rows.Count / gvPopUpGrid.PageSize))
                {
                    gvPopUpGrid.SetPageIndex(0);
                }
                gvPopUpGrid.DataBind();
            }
            else
            {
                lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound;
                gvPopUpGrid.AllowPaging = false;
                gvPopUpGrid.DataSource = "";
                gvPopUpGrid.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblTotalRecordsPopUp.Text = objcommonmessage.NoRecordFound + ex.Message;
            gvPopUpGrid.AllowPaging = false;
            gvPopUpGrid.DataSource = "";
            gvPopUpGrid.DataBind();
        }
    }

    private void GetAllATOTestResultList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the voucher list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]  
		                    ,[VoucherNo]
		                    ,[VoucherYear]
		                    ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
		                    ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]     
                      FROM [tblChATOTestResult] as A where [VoucherNo] like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    private void BindHeaderRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [VoucherNo]
                          ,[VoucherYear]
                          ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
	                      ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                          ,[BatchNo]
                          ,[MoistureContent]
                          ,[Purity]
                          ,[SolubilityInMEG]
                          ,[Appearance]
                      FROM [tblChATOTestResult] as A where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                txtVoucherDate.Text = dt.Rows[0]["VoucherDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                txtVoucherNo.Text = dt.Rows[0]["VoucherNo"].ToString();

                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();

                txtBatchNo.Text = dt.Rows[0]["BatchNo"].ToString();
                txtSolubilityinMEG.Text = dt.Rows[0]["SolubilityInMEG"].ToString();
                txtMoistureContent.Text = dt.Rows[0]["MoistureContent"].ToString();
                txtPurity.Text = dt.Rows[0]["Purity"].ToString();
                txtAppearance.Text = dt.Rows[0]["Appearance"].ToString();
                dt = null;
            }
        }
        catch { }
    }

    #endregion
}