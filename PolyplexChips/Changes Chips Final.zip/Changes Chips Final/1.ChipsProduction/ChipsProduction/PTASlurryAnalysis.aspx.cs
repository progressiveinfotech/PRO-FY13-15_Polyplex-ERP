﻿/*
 Module Name: Chips Production
 Developer Name: Satish Pal
 Date Creation: 14-Jun-13
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Sales_PerformaInvoice : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Common com = new Common();
    Common_mst objCommon_mst = new Common_mst();
    Common_Message objcommonmessage = new Common_Message();
    string ErrorStatus, RecordNo;
    Connection objConnectionClass = new Connection();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        //Code to disable the save btn to avoid double click
        ImgBtnSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(ImgBtnSave, null) + ";");
        //========================================
        if (!IsPostBack)
        {
            try
            {
                Label lblPageHeader = (Label)Master.FindControl("lbl_PageHeader");
                lblPageHeader.Text = "PTA Slurry Analysis";

                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
                txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

                FillFinancialYear();
                BindSearchList();

                string CurrentTime = DateTime.Now.ToString("HH:mm");
                string[] TimeIndex = CurrentTime.Split(':');
                txtTimeHr.Text = TimeIndex[0];
                txtTimeMin.Text = TimeIndex[1];

                #region Change Color and Readonly Fields

                txtVoucherNo.Attributes.Add("style", "background:lightgray");
                txtYear.Attributes.Add("style", "background:lightgray");
                txtVoucherDate.Attributes.Add("style", "background:lightgray");
                txtPostingDate.Attributes.Add("style", "background:lightgray");

                txtVoucherNo.Attributes.Add("readonly", "true");
                txtYear.Attributes.Add("readonly", "true");
                txtVoucherDate.Attributes.Add("readonly", "true");
                txtPostingDate.Attributes.Add("readonly", "true");

                #endregion

                txtVoucherNo.Text = AutogenerateNo(txtYear.Text);
            }
            catch { }
        }

        ImageButton btnAdd = (ImageButton)Master.FindControl("btnAdd");
        btnAdd.CausesValidation = false;
        btnAdd.Click += new ImageClickEventHandler(btnAdd_Click);

        ImageButton imgbtnSearch = (ImageButton)Master.FindControl("imgbtnSearch");
        imgbtnSearch.CausesValidation = false;
        imgbtnSearch.Click += new ImageClickEventHandler(imgbtnSearch_Click);

    }

    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to create new entry from the form.
        /// </summary>
        try
        {
            ClearHeader();

            txtSearchList.Text = "";
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            ddlSearch.SelectedIndex = 0;
            txtSearch.Text = "";
        }
        catch { }
    }

    protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to search all vouchers created by this form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            txtSearchList.Text = "";

            GetAllPTASlurryAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void gvSearchList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /// <summary>
        /// This event is used for select the existing voucher from all saved voucher list.
        /// </summary>
        try
        {
            GridView gvSearchList = (GridView)sender;
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            gvSearchList.SelectedIndex = row.RowIndex;

            if (e.CommandName == "select")
            {
                foreach (GridViewRow oldrow in gvSearchList.Rows)
                {
                    ImageButton imgbutton = (ImageButton)oldrow.FindControl("ImageButton1");
                    imgbutton.ImageUrl = "~/Images/chkbxuncheck.png";
                }
                ImageButton img = (ImageButton)row.FindControl("ImageButton1");
                img.ImageUrl = "~/Images/chkbxcheck.png";

                ClearHeader();

                HidAutoId.Value = Convert.ToString(e.CommandArgument);
                BindHeaderRecords(HidAutoId.Value);
                ImgBtnSave.ImageUrl = "../Images/btn_update.png";
            }
        }
        catch { }
    }

    protected void gvSearchList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        /// <summary>
        /// This event is used for indexing in all voucher list grid.
        /// </summary>
        try
        {
            gvSearchList.PageIndex = e.NewPageIndex;
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");

            GetAllPTASlurryAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearch.Text.Trim());
            lSearchList.Text = "Search By " + ddlSearch.SelectedItem.ToString() + ": ";
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void btnSearchlist_Click(object sender, EventArgs e)
    {
        /// <summary>
        /// This event is used for search the entered voucher in all voucher list grid.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            GetAllPTASlurryAnalysisList(ddlSearch.SelectedValue.ToString(), txtSearchList.Text.Trim());
            txtSearchList.Focus();
            ModalPopupExtender1.Show();
        }
        catch { }
    }

    protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
    {
        /// <summary>
        /// This event is used to save all records in database.
        /// </summary>

        if (txtTimeHr.Text == "" || txtTimeMin.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Time is mandatory.", 125, 300);
            return;
        }
        if (com.STRToInt(txtTimeHr.Text.Trim()) > 23)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Hrs in time cannot be greater than 23.", 125, 300);
            return;
        }
        if (com.STRToInt(txtTimeMin.Text.Trim()) > 59)
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Mins in time cannot be greater than 59.", 125, 300);
            return;
        }
        if (txtRemarks.Text == "")
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, "Remarks is mandatory.", 125, 300);
            return;
        }
        try
        {
            objConnectionClass.OpenConnection();
            SqlCommand cmd;
            cmd = new SqlCommand();
            cmd.Connection = objConnectionClass.PolypexSqlConnection;
            cmd.CommandTimeout = 60;
            cmd.CommandType = CommandType.StoredProcedure;

            #region All Parameters

            if (HidAutoId.Value == "0")
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = 0;
            }
            else
            {
                cmd.Parameters.Add("@AutoId", SqlDbType.Int).Value = com.STRToInt(HidAutoId.Value);
            }
            cmd.Parameters.Add("@VoucherYear", SqlDbType.VarChar).Value = txtYear.Text.Trim();
            if (txtVoucherDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtVoucherDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@VoucherDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtPostingDate.Text.Trim() != "")
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DateTime.ParseExact(txtPostingDate.Text.Trim(), objCommon_mst.DateFormat, System.Globalization.CultureInfo.InvariantCulture).ToString();
            }
            else
            {
                cmd.Parameters.Add("@PostingDate", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (txtTimeHr.Text.Trim().Length < 2)
            {
                int uy = txtTimeHr.Text.Trim().Length;
                txtTimeHr.Text = uy == 0 ? "00" : "0" + txtTimeHr.Text.Trim();
            }
            if (txtTimeMin.Text.Trim().Length < 2)
            {
                int uy = txtTimeMin.Text.Trim().Length;
                txtTimeMin.Text = uy == 0 ? "00" : "0" + txtTimeMin.Text.Trim();
            }

            cmd.Parameters.Add("@SampleTime", SqlDbType.VarChar).Value = txtTimeHr.Text.Trim() + ":" + txtTimeMin.Text.Trim(); ;
            
            cmd.Parameters.Add("@Moisture", SqlDbType.Float).Value = com.STRToDBL(txtMoisture.Text.Trim());
            cmd.Parameters.Add("@MoleRatio", SqlDbType.Float).Value = com.STRToDBL(txtMoleRatio.Text.Trim());
            cmd.Parameters.Add("@BulkDensity", SqlDbType.Float).Value = com.STRToDBL(txtBulkDensity.Text.Trim());

            cmd.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = txtRemarks.Text.Trim();
            cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@ModifiedBy", SqlDbType.Int).Value = com.STRToInt(Session["UserId"].ToString());
            cmd.Parameters.Add("@AFlag", SqlDbType.Bit).Value = chkActive.Checked;

            cmd.Parameters.Add(new SqlParameter("@ErrorStatus", SqlDbType.VarChar, 10));
            cmd.Parameters["@ErrorStatus"].Direction = ParameterDirection.Output;

            cmd.Parameters.Add("@NewVoucherNo", SqlDbType.VarChar, 30);
            cmd.Parameters["@NewVoucherNo"].Direction = ParameterDirection.Output;

            cmd.CommandText = "SP_InsertUpdate_In_Chips_tblChSlurryAnalysis";
            cmd.ExecuteNonQuery();

            ErrorStatus = cmd.Parameters["@ErrorStatus"].Value.ToString();
            RecordNo = cmd.Parameters["@NewVoucherNo"].Value.ToString();

            if (ErrorStatus == "0")
            {
                if (RecordNo != "0")
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved + ". Voucher No. is:" + RecordNo, 125, 300);
                }
                else
                {
                    MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordSaved, 125, 300);
                }
                #region Clear All records after save

                ClearHeader();

                DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
                ddlSearch.SelectedIndex = 0;
                TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
                txtSearch.Text = "";

                #endregion
            }
            else
            {
                MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
            }
            RecordNo = "";
            ErrorStatus = "";

            #endregion
        }
        catch
        {
            MyMessageBoxInfo.Show(MyMessageBox.MessageType.Info, objcommonmessage.RecordNotSaved, 125, 300);
        }
        finally
        {
            objConnectionClass.CloseConnection();
        }
    }

    #endregion

    #region***************************************Functions***************************************

    protected void FillFinancialYear()    
    {
        /// <summary>
        /// This method is used to get financial year.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string OrganizationId = ConfigurationManager.AppSettings["OrganizationId"].ToString();
            dt = objCommon_mst.Get_FinancialYear(OrganizationId);
            if (dt.Rows.Count > 0)
            {
                if (com.STRToNum(dt.Rows[0]["FinancialStartMonth"].ToString()) > 1)
                {
                    string EndFinancialYear = dt.Rows[0]["FinancialEndYear"].ToString().Substring(2);
                    string startfinancialyear = dt.Rows[0]["FinancialStartYear"].ToString().Substring(2);
                    txtYear.Text = (startfinancialyear + "-" + EndFinancialYear);
                }
                else
                {
                    txtYear.Text = dt.Rows[0]["FinancialStartYear"].ToString();
                }
            }
        }
        catch { }
    }

    protected void BindSearchList()
    {
        /// <summary>
        /// This method is used to get search list type of form.
        /// </summary>
        try
        {
            DropDownList ddlSearch = (DropDownList)Master.FindControl("ddlSearch");
            ddlSearch.Items.Add(new ListItem("Voucher No", "VoucherNo"));
        }
        catch { }
    }

    protected string AutogenerateNo(string financialYear)
    {
        /// <summary>
        /// This method is used to get the autogenerated no.
        /// </summary>
        int inv_series;
        string inv_no = "";
        try
        {
            inv_series = getSeries(financialYear);
            inv_no = "PTAS" + financialYear + inv_series.ToString().PadLeft(5, '0');

        }
        catch { }
        return inv_no;
    }

    public int getSeries(string fin_yr)
    {
        /// <summary>
        /// This method is used to get the series .
        /// </summary>
        int piseries = 1;
        try
        {

            string sql = @"select  MAX(Series) from tblCHSlurryAnalysis where [VoucherYear]='" + fin_yr + "'";
            DataTable dt = com.executeSqlQry(sql);
            if (dt.Rows.Count > 0)
            {
                piseries = int.Parse(dt.Rows[0][0].ToString()) + 1;
            }
            else
            {
                piseries = 1;
            }
        }
        catch { }
        return piseries;
    }

    protected void ClearHeader()
    {
        /// <summary>
        /// This method is used to clear all the header records.
        /// </summary>
        try
        {
            HidAutoId.Value = "0";
            txtVoucherDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);
            txtPostingDate.Text = DateTime.Now.ToString(objCommon_mst.DateFormat);

            FillFinancialYear();
            txtVoucherNo.Text = AutogenerateNo(txtYear.Text);

            string CurrentTime = DateTime.Now.ToString("HH:mm");
            string[] TimeIndex = CurrentTime.Split(':');
            txtTimeHr.Text = TimeIndex[0];
            txtTimeMin.Text = TimeIndex[1];

            txtMoisture.Text = "0";
            txtMoleRatio.Text = "0";
            txtBulkDensity.Text = "0";
            txtRemarks.Text = "";
            chkActive.Checked = true;
            ImgBtnSave.ImageUrl = "../Images/btnSave.png";
        }
        catch { }
    }

    private void GetAllPTASlurryAnalysisList(string ddlSearchValue, string txtSearchValue)
    {
        /// <summary>
        /// This method is used to get all the voucher list.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]  
		                    ,[VoucherNo]
		                    ,[VoucherYear]
		                    ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
		                    ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]     
                      FROM [tblChSlurryAnalysis] as A where [VoucherNo] like '%" + txtSearchValue + "%' order by AutoId desc";

            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                gvSearchList.DataSource = dt;
                gvSearchList.AllowPaging = true;
                gvSearchList.DataBind();
                lblTotalRecords.Text = objcommonmessage.TotalRecord + dt.Rows.Count.ToString();
            }
            else
            {
                lblTotalRecords.Text = objcommonmessage.NoRecordFound;
                gvSearchList.AllowPaging = false;
                gvSearchList.DataSource = "";
                gvSearchList.DataBind();
            }
            dt = null;
        }
        catch { }
    }

    private void BindHeaderRecords(string AutoId)
    {
        /// <summary>
        /// This method is used to bind all the controls depend upon the selected voucher no in all voucher list grid.
        /// </summary>
        try
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [AutoId]  
		                    ,[VoucherNo]
		                    ,[VoucherYear]
		                    ,CONVERT(VARCHAR(11), [VoucherDate], 101) as [VoucherDate]
		                    ,CONVERT(VARCHAR(11), [PostingDate], 101) as [PostingDate]
                          ,[SampleTime]
                          ,[Moisture]
                          ,[MoleRatio]
                          ,[BulkDensity]
                          ,[Remarks]
                          ,[AFlag]
                      FROM [tblCHSlurryAnalysis] as A where [AutoId] = '" + AutoId + "'";
            dt = com.executeSqlQry(query);
            if (dt.Rows.Count > 0)
            {
                txtVoucherDate.Text = dt.Rows[0]["VoucherDate"].ToString();
                txtPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                txtVoucherNo.Text = dt.Rows[0]["VoucherNo"].ToString();

                txtYear.Text = dt.Rows[0]["VoucherYear"].ToString();
                if (dt.Rows[0]["SampleTime"].ToString().Contains(":"))
                {
                    string time = dt.Rows[0]["SampleTime"].ToString();
                    string[] timearr = time.Split(':');
                    txtTimeHr.Text = timearr[0];
                    txtTimeMin.Text = timearr[1];
                }

                txtMoisture.Text = dt.Rows[0]["Moisture"].ToString();
                txtMoleRatio.Text = dt.Rows[0]["MoleRatio"].ToString();
                txtBulkDensity.Text = dt.Rows[0]["BulkDensity"].ToString();               
                txtRemarks.Text = dt.Rows[0]["Remarks"].ToString();

                if (dt.Rows[0]["AFlag"].ToString() == "True")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
                dt = null;
            }
        }
        catch { }
    }

    #endregion

}