﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class HomePage : System.Web.UI.Page
{
    #region***************************************Variables***************************************

    Home objHome = new Home();
    DynControl obj = new DynControl();
    Common com = new Common();

    #endregion

    #region***************************************Events***************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
           if (Session["UserID"] == null)
            {
                try
                {
                    Response.Redirect("../SessionExpired.aspx?name=Home", false);
                }
                catch (Exception ex) { }
            }
            else
            {
                TRMasters.Attributes.Add("style", "display:none");
                TRListing.Attributes.Add("style", "display:none");
                TRFormPrint.Attributes.Add("style", "display:none");
                TRUserMgmt.Attributes.Add("style", "display:none");
                TRGeneral.Attributes.Add("style", "display:none");
                TRProduction.Attributes.Add("style", "display:none");
                TRApproval.Attributes.Add("style", "display:none");
                TRGeneralSection.Attributes.Add("style", "display:none");

                div_in_trans.Visible = false;
                div_in_formpri.Visible = false;
                div_in_reports.Visible = false;
                div_in_query.Visible = false;
                div_in_listing.Visible = false;
                div_in_myusermanagement.Visible = false;
                div_in_master.Visible = false;
                div_in_general.Visible = false;
                div_in_customer.Visible = false;
                div_in_production.Visible = false;
                div_in_approval.Visible = false;
                div_in_generalsection.Visible = false;                

                AccordionPane1.Visible = false;
                AccordionPane2.Visible = false;
                AccordionPane3.Visible = false;
                AccordionPane4.Visible = false;
                AccordionPane5.Visible = false;
                AccordionPane6.Visible = false;
                AccordionPane7.Visible = false;
                AccordionPane8.Visible = false;

                if (Session["Environment"] != null && Session["LocationName"] != null && Session["UserName"] != null && Session["UserID"] != null)
                {
                    if (Session["Environment"].ToString() == "-Select-")
                    {
                        lbl_Environment.Visible = false;
                    }
                    else
                    {
                        lbl_Environment.Visible = true;
                        lbl_Environment.Text ="Environment: "+ Session["Environment"].ToString();
                    }
                    lbl_location.Text = Session["LocationName"].ToString();
                    lblName.Text = Session["UserName"].ToString();
                    HidUserId.Value = Session["UserID"].ToString();
                }
                //commented by shrikant 17-may-13
                //else
                //{
                //    Response.Redirect("../SessionExpired.aspx", false);
                //}

                #region Get Module and SubModule by User

                DataTable dt = new DataTable();
                //dt = objHome.Get_ModuleAndSubmoduleByUserId(HidUserId.Value);
                string Query = @"SELECT distinct SubModuleName, ModuleName FROM Com_Module_Mst WHERE ModuleFormID IN (SELECT distinct ModuleFormID from
                                 Com_Group_Module_Mapping WHERE GROUPID IN (select GroupID from Com_UserGroupMapping_Mst WHERE UserID ='"+HidUserId.Value+"'))";

                dt = com.executeSqlQry(Query);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        putInMenu(dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["ModuleName"].ToString());
                    }
                }
                #endregion
            }            
        }
        catch (Exception ex) { }
    }

    protected void lnk_sales_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Sales";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Sales");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_FA_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Financial Accounting";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Financial Accounting");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_procurement_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Procurement";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Procurement");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_production_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Production";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Production");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_chipsproduction_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Chips Production";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("ChipsProduction");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_admin_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Admin";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Admin");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_approval_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "Approval";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("Approval");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }

    protected void lnk_general_Click(object sender, EventArgs e)
    {
        try
        {
            lbl_sub_header.Text = "General";
            DataTable dt = GetSubmoduleFormURLByModuleAndUserId("GeneralSection");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Panel pnl = getpanel(dt.Rows[i]["SubModuleName"].ToString());
                    obj.CreatesubMenu(ref pnl, dt.Rows[i]["FormURL"].ToString(), dt.Rows[i]["SubModuleName"].ToString(), dt.Rows[i]["formname"].ToString());
                }
            }
            //commented by shrikant 17-may-13
            //if (dt == null)
            //{
            //    Response.Redirect("../SessionExpired.aspx", false);
            //}
        }
        catch (Exception ex) { }
    }    

    protected void lnk_logout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("LoginPage.aspx",false);
    }

    #endregion

    #region***************************************Methods***************************************

    private DataTable GetSubmoduleFormURLByModuleAndUserId(string ModuleName)
    {
        DataTable dt = new DataTable();
        try
        {
            
            //dt = objHome.Get_SubmoduleFormURLByModuleAndUserId(ModuleName, HidUserId.Value);
            string Query = @"SELECT FormName, SubModuleName, FormURL,* FROM Com_Module_Mst WHERE ModuleFormID IN (SELECT distinct ModuleFormID from
                             Com_Group_Module_Mapping WHERE GROUPID in (select GroupID from Com_UserGroupMapping_Mst WHERE UserID ='"+HidUserId.Value +"') )";
            Query += " and ModuleName ='" + ModuleName + "' and ActiveStatus = 1 Order by Com_Module_Mst.FormName";

            dt = com.executeSqlQry(Query);
            return dt;
        }
        catch
        {
            return dt = null;
        }
    }

    public void putInMenu(string moduleType, string header)
    {
        try
        {
            if (header == "Sales")
            {
                obj.CreateMenu(ref Pnl_sales, moduleType, header);
                AccordionPane1.Visible = true;
            }
            if (header == "Procurement")
            {
                obj.CreateMenu(ref Pnl_procuremnt, moduleType, header);
                AccordionPane3.Visible = true;
            }
            if (header == "Financial Accounting")
            {
                obj.CreateMenu(ref Pnl_Finan, moduleType, header);
                AccordionPane2.Visible = true;
            }
            if (header == "Production")
            {
                obj.CreateMenu(ref Pnl_production, moduleType, header);
                AccordionPane4.Visible = true;
            }
            if (header == "Admin")
            {
                obj.CreateMenu(ref Pnl_admin, moduleType, header);
                AccordionPane5.Visible = true;
            }
            if (header == "Approval")
            {
                obj.CreateMenu(ref Pnl_approval, moduleType, header);
                AccordionPane6.Visible = true;
            }
            if (header == "GeneralSection")
            {
                obj.CreateMenu(ref Pnl_general, moduleType, header);
                AccordionPane7.Visible = true;
            }
            if (header == "ChipsProduction")
            {
                obj.CreateMenu(ref Pnl_chipsproduction, moduleType, header);
                AccordionPane8.Visible = true;
            }
        }
        catch (Exception ex)
        {
        }

    }

    protected Panel getpanel(string ModuleType)
    {
        if (ModuleType == "Master")
        {
            TRMasters.Attributes.Add("style", "display:block");
            div_in_master.Visible = true;
            return pnl_in_master;
        }
        if (ModuleType == "Transaction")
        {
            TRMasters.Attributes.Add("style", "display:block");
            div_in_trans.Visible = true;
            return pnl_in_trans;
        }
        if (ModuleType == "Listing")
        {
            TRListing.Attributes.Add("style", "display:block");
            div_in_listing.Visible = true;
            return pnl_in_listing;
        }
        if (ModuleType == "Reports")
        {
            TRListing.Attributes.Add("style", "display:block");
            div_in_reports.Visible = true;
            return pnl_in_reports;
        }
        if (ModuleType == "Form Print")
        {
            TRFormPrint.Attributes.Add("style", "display:block");
            div_in_formpri.Visible = true;
            return pnl_in_formpri;
        }        
        if (ModuleType == "Query")
        {
            TRFormPrint.Attributes.Add("style", "display:block");
            div_in_query.Visible = true;
            return pnl_in_query;
        } 
        if (ModuleType == "My User Management")
        {
            TRUserMgmt.Attributes.Add("style", "display:block");
            div_in_myusermanagement.Visible = true;
            return pnl_in_myusermanagement;
        }        
        if (ModuleType == "General")
        {
            TRGeneral.Attributes.Add("style", "display:block");
            div_in_general.Visible = true;
            return pnl_in_general;
        }
        if (ModuleType == "Customer")
        {
            TRGeneral.Attributes.Add("style", "display:block");
            div_in_customer.Visible = true;
            return pnl_in_customer;
        }
        if (ModuleType == "Production")
        {
            TRProduction.Attributes.Add("style", "display:block");
            div_in_production.Visible = true;
            return pnl_in_production;
        }
        if (ModuleType == "Sales")
        {
            TRProduction.Attributes.Add("style", "display:block");
            div_in_sales.Visible = true;
            return pnl_in_sales;
        }
        if (ModuleType == "Forms For Approval")
        {
            TRApproval.Attributes.Add("style", "display:block");
            div_in_approval.Visible = true;
            return pnl_in_approval;
        }
        if (ModuleType == "General Activities")
        {
            TRGeneralSection.Attributes.Add("style", "display:block");
            div_in_generalsection.Visible = true;
            return pnl_in_generalsection;
        } 
        return null;
    }

    #endregion
}